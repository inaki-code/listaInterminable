import { Pipe, PipeTransform } from '@angular/core';
import { Product } from '../../interfaces/product';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(array: Product[], texto: string): Product[] {

    if (!texto) {
      return array;
    }
    else {
      let filter = array.filter( item => item.nombre.toUpperCase().includes(texto.toUpperCase()) );
      //console.log(filter);
      return filter
    }

  }

}

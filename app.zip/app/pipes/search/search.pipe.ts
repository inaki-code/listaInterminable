import { Pipe, PipeTransform } from '@angular/core';
import { User } from '../../interfaces/user';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(array: User[], texto: string): User[] {

    if (!texto) {
      return array;
    }
    else {
      let search = array.filter( item => item.email.toUpperCase().includes(texto.toUpperCase()) );
      console.log(search);
      return search;
    }

  }

}

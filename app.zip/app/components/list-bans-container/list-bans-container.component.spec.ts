import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListBansContainerComponent } from './list-bans-container.component';

describe('ListBansContainerComponent', () => {
  let component: ListBansContainerComponent;
  let fixture: ComponentFixture<ListBansContainerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListBansContainerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ListBansContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

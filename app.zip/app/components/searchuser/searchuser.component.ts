import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { FormControl } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { User } from '../../interfaces/user';
import { ApiService } from '../../services/api/api.service';
import { finalize } from 'rxjs';
import { CallComponentsService } from '../../services/call-components/call-components.service';
import { SessionService } from '../../services/session/session.service';
import { AgregarService } from '../../services/agregar/agregar.service';

// JQUERY
declare var $:any;

@Component({
  selector: 'searchuser',
  templateUrl: './searchuser.component.html',
  styleUrls: ['./searchuser.component.css']
})
export class SearchuserComponent implements OnInit {

  inputFocused: boolean = false;
  focus: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  searchString: string = '';
  users: User[] = [];
  usersSearched: User[] = [];
  id: any;
  usersNoAgregables: BehaviorSubject<number[]> = new BehaviorSubject<number[]>( Array() );
  arrayInventado: number[] = [];
  email: BehaviorSubject<string> = new BehaviorSubject<string>('');

  constructor(private api: ApiService, private call: CallComponentsService, private session: SessionService, private agregar: AgregarService) {}

  ngOnInit(): void {

    $('#usuario').click(function(event: any){
      event.stopPropagation();
      alert('stop propagation');
    });

    $('.item').click(function(event: any){
      console.log('item');
    });

    this.api.getUsers().subscribe(( res: any ) => {
      this.users = res.users;
    });
    this.session.id.subscribe((res: any) => {
      this.id = res;
    });
    this.agregar.usersNoAgregables.subscribe(res => {
      this.usersNoAgregables.next(res);
      console.log(res);
    });

    for (let i = 0; i < 1000; i++) {
      this.arrayInventado.push(i);
    }

  }

  focused() {
    this.focus.next(true);
  }

  notFocused() {
    this.focus.next(false);
  }

  buscar(evento: any) {
    // Cada vez que se ejecuta el método borramos la info
    this.usersSearched = [];
    // Y recogemos lo que el usuario busca
    this.searchString = evento.target.value;

    for (let u of this.users) {

      if ( !(u.id == this.id) && u.email.includes(this.searchString) ) {
        this.usersSearched.push(u);
      }

    }

  }

  goToProfile(id: number) {
    //console.log(this.email);
    //this.call.callProfile.emit(this.email.toString());

    //alert(id);
    this.call.goToProfile.next(id);

  }

  solicitudAmistad(userAgregado: number, event: any) {

    this.focused();

    event.stopPropagation();

    alert('has enviado tu petición de amistad');
    this.api.createAgregar(this.id, userAgregado).pipe(finalize( () => {

      // Ponemos la petición en las peticiones pendientes
      let peticionesHechas: number[] = this.agregar.peticionesHechas.value;
      peticionesHechas.push(userAgregado);
      this.agregar.peticionesHechas.next(peticionesHechas);

      // Incluir al usuario que hacemos la petición en usuarios no agregables
      let noAgregables: number[] = this.usersNoAgregables.value;
      noAgregables.push(userAgregado);
      this.usersNoAgregables.next(noAgregables);

    })).subscribe();

  }

}

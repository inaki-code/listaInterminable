import { Component, OnInit, HostListener, ElementRef} from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { User } from '../../interfaces/user';
import { ApiService } from '../../services/api/api.service';
import { finalize, debounceTime } from 'rxjs';
import { CallComponentsService } from '../../services/call-components/call-components.service';
import { SessionService } from '../../services/session/session.service';
import { AgregarService } from '../../services/agregar/agregar.service';


// JQUERY
declare var $:any;

@Component({
  selector: 'searchuser',
  templateUrl: './searchuser.component.html',
  styleUrls: ['./searchuser.component.css']
})
export class SearchuserComponent implements OnInit {

  inputFocused: boolean = false;
  focus: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  searchString: BehaviorSubject<string> = new BehaviorSubject<string>('');
  users: BehaviorSubject<any> = new BehaviorSubject(new Array());
  id: any;
  usersNoAgregables: BehaviorSubject<number[]> = new BehaviorSubject<number[]>( Array() );
  arrayInventado: number[] = [];
  email: BehaviorSubject<string> = new BehaviorSubject<string>('');
  status: BehaviorSubject<string> = new BehaviorSubject<string>('');
  searchUser: FormGroup;


  constructor(private api: ApiService, private call: CallComponentsService, private session: SessionService, private agregar: AgregarService, private fb: FormBuilder, private eRef: ElementRef) {
    this.searchUser = this.fb.group({
      search: []
    });
  }

  // Cerrar la modal cuando clickaos fuera del componente
  @HostListener('document:click', ['$event'])
  clickout(event: any) {
    if(this.eRef.nativeElement.contains(event.target)) {
      this.focus.next(true);
    } else {
      this.focus.next(false);
    }
  }

  ngOnInit(): void {

    this.searchUser.controls['search'].valueChanges
    .pipe( debounceTime(500) ).subscribe(res => {
      this.searchString.next(res);
      //console.log(res);
    });
    // Recogemos solo los usuarios normales para que no te salgan los admins
    this.api.getUsers().subscribe(( res: any ) => {

      let users: User[] = [];

      for(let u of res.users) {
        if ( this.id != u.id && u.status == 'user') {
          users.push(u);
        }
      }

      this.users.next(users);
    });
    this.session.id.subscribe((res: any) => {
      this.id = res;
    });
    this.agregar.usersNoAgregables.subscribe(res => {
      this.usersNoAgregables.next(res);
    });

    this.session.status.subscribe(res => {
      this.status.next(res);
    });

    for (let i = 0; i < 1000; i++) {
      this.arrayInventado.push(i);
    }

  }

  focused() {
    this.focus.next(true);
  }

  notFocused() {
    this.focus.next(false);
  }

  goToProfile(id: number) {
    this.call.goToProfile.next(id);
  }

  solicitudAmistad(userAgregado: number, event: any) {

    event.stopPropagation();

    alert('has enviado tu petición de amistad');
    this.api.createAgregar(this.id, userAgregado).pipe(finalize( () => {

      // Ponemos la petición en las peticiones pendientes
      let peticionesHechas: number[] = this.agregar.peticionesHechas.value;
      peticionesHechas.push(userAgregado);
      this.agregar.peticionesHechas.next(peticionesHechas);

      // Incluir al usuario que hacemos la petición en usuarios no agregables
      let noAgregables: number[] = this.usersNoAgregables.value;
      noAgregables.push(userAgregado);
      this.usersNoAgregables.next(noAgregables);

    })).subscribe();

  }

}

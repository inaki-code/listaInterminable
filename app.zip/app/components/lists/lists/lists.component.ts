import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CallComponentsService } from '../../../services/call-components/call-components.service';

declare var $:any;

@Component({
  selector: 'lists',
  templateUrl: './lists.component.html',
  styleUrls: ['./lists.component.css']
})
export class ListsComponent implements OnInit {

  constructor( private call: CallComponentsService) { }

  ngOnInit(): void {

    $('#exampleModal').on('hidden.bs.modal', () => {
      this.call.callListsModal.next(false);
    });

    this.listsModalOpen();

  }

  listsModalOpen() {
    $('#exampleModal').modal('show');
  }

  listsModalClose() {
    $('#exampleModal').modal('hide');
  }

  iListModalOpen() {

    this.listsModalClose();
    // Darle tiempo a la modal de listas que se cierre
    // Sino tendré 2 modales abiertas a la vez y no las podré cerrar
    setTimeout( () => {
      this.call.callIListModal.emit(true);
    }, 100 );

  }

  cListModalOpen() {

    this.listsModalClose();
    // Darle tiempo a la modal de listas que se cierre
    // Sino tendré 2 modales abiertas a la vez y no las podré cerrar
    setTimeout( () => {
      this.call.callCListModal.emit(true);
    }, 100 );

  }


}

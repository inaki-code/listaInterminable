import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Component, OnInit } from '@angular/core';
import { Product } from '../../../interfaces/product';
import { ApiService } from '../../../services/api/api.service';
import { CallComponentsService } from '../../../services/call-components/call-components.service';
import { FormGroup, FormBuilder} from '@angular/forms';
import { debounceTime, finalize } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';
import { IncluirService } from '../../../services/inlcluir/incluir.service';
import { List } from '../../../interfaces/list';
import { SessionService } from '../../../services/session/session.service';
import { ProductService } from '../../../services/product/product.service';
import { Incluir } from '../../../interfaces/incluir';

// JQUERY
declare var $:any;

@Component({
  selector: 'drag-drop',
  templateUrl: './drag-drop.component.html',
  styleUrls: ['./drag-drop.component.css']
})
export class DragDropComponent implements OnInit {

  public visibleProducts: BehaviorSubject<number[]> = new BehaviorSubject<number[]>(Array());
  public listedProducts:BehaviorSubject<any> = new BehaviorSubject(Array());
  public products:BehaviorSubject<any> = new BehaviorSubject(Array());
  public searchProduct: FormGroup;
  public listedProductsFilter: BehaviorSubject<string> = new BehaviorSubject('');
  public noListedProductsFilter: BehaviorSubject<string> = new BehaviorSubject('');
  public list: BehaviorSubject<List> = new BehaviorSubject({
    id: -1,
    nombre: '',
    tipo: '',
    usuarios: '',
    propietarios: '',
    id_usuario: -1,
    likes: ''
  });
  public rol: BehaviorSubject<string> = new BehaviorSubject('');


  public incluidos: BehaviorSubject<number[]> = new BehaviorSubject(Array());
  public noIncluidos: BehaviorSubject<number[]> = new BehaviorSubject(Array());


  constructor(private api: ApiService, private call: CallComponentsService, private fb: FormBuilder, private incluir: IncluirService, private session: SessionService, private productService: ProductService) {
    this.searchProduct = this.fb.group({
      searchListed: [],
      searchNoListed: []
    });
  }

  ngOnInit(): void {

    this.suscriptions();

    console.log(this.incluidos.value);
    console.log(this.noIncluidos.value);

  }

  dropped_product($event: CdkDragDrop<BehaviorSubject<Product[]>>, list: string) {

    console.log(this.listedProducts.value);
    console.log(this.products.value);

    if ($event.previousContainer === $event.container) {
      moveItemInArray(
        $event.container.data.value,
        $event.previousIndex,
        $event.currentIndex
      );
    }
    else {
      transferArrayItem(
        $event.previousContainer.data.value,
        $event.container.data.value,
        $event.previousIndex,
        $event.currentIndex
      );

      console.log(this.incluidos.value);
      console.log(this.noIncluidos.value);

      this.searchProduct.reset();

      let product: Product = $event.container.data.value[$event.currentIndex];

      switch (list) {
        case 'products':

          if (this.list.value.tipo == 'totalitaria' && this.rol.value == 'propietario') {
            this.api.createIncluir(this.call.List.value.id, product.id, 1).pipe(finalize( () => {

              console.log(this.listedProducts.value);
              console.log(this.products.value);
              console.log(product);

              // Añadir productos incluidos
              let prodIncluidos = this.incluidos.value;
              prodIncluidos.push(product.id);
              this.incluidos.next(prodIncluidos);

            })).subscribe(res => {
              if (res != null) {

                console.log(res);

              }
            });
          }
          else {
            this.api.createIncluir(this.call.List.value.id, product.id, 0).pipe(finalize( () => {

              console.log(this.listedProducts.value);
              console.log(this.products.value);
              console.log(product);

              // Añadir productos no incluidos
              let prodNoIncluidos = this.noIncluidos.value;
              prodNoIncluidos.push(product.id);
              this.noIncluidos.next(prodNoIncluidos);

            })).subscribe(res => {
              if (res != null) {
                console.log(res);
              }
            });
          }


          break;
        case 'listedProducts':
          this.api.removeIncluir(this.call.List.value.id, product.id).pipe(finalize( () => {

            console.log(this.listedProducts.value);
            console.log(this.products.value);
            console.log(product);

            // Eliminar productos incluidos o no incluidos
            if ( this.incluidos.value.includes(product.id) ) {

              let prodIncluidos = this.incluidos.value;
              let index: number = prodIncluidos.indexOf(product.id);
              prodIncluidos.splice(index, 1);
              this.incluidos.next(prodIncluidos);

            }
            else {

              let prodNoIncluidos = this.noIncluidos.value;
              let index: number = prodNoIncluidos.indexOf(product.id);
              prodNoIncluidos.splice(index, 1);
              this.noIncluidos.next(prodNoIncluidos);

            }




          })).subscribe(res => {
            if (res != null) {
              console.log(res);
            }
          });
          break;
      }

    }

  }

  getRol() {

    console.log(this.call.idpropietarios.value);
    console.log(this.session.id);
    console.log(this.list.value.id_usuario);

    if ( this.call.idpropietarios.value.includes( parseInt(this.session.id.toString()) ) || this.list.value.id_usuario == parseInt(this.session.id.toString()) ) {
      this.rol.next('propietario');
    }
    else {
      this.rol.next('usuario');
    }

  }

  suscriptions() {

    this.searchProduct.controls['searchListed'].valueChanges
    .pipe(
      debounceTime(500)
    )
    .subscribe(res => this.listedProductsFilter.next(res));

    this.searchProduct.controls['searchNoListed'].valueChanges
    .pipe(
      debounceTime(500)
    )
    .subscribe(res => this.noListedProductsFilter.next(res));

    this.incluir.listedProducts.subscribe(res => {
      this.listedProducts.next(res);
      console.log(res);
    });

    this.incluir.products.subscribe(res => {
      this.products.next(res);
      console.log(res);
    });

    this.call.List.subscribe(res => {
      this.list.next(res);
    });

    this.call.rol.subscribe(res => {
      this.rol.next(res);
    });

    this.productService.visibleProducts.subscribe(res => {

      let productosVisibles: number[] = []

      for (let producto of res) {
        productosVisibles.push(producto.id);
      }

      this.visibleProducts.next(productosVisibles);

    });

    this.incluir.incluir.subscribe(res => {

      let aceptados: number[] = [];
      let noAceptados: number[] = [];;

      for (let i of res) {
        if (i.aceptado == 1 && i.id_lista == this.call.List.value.id) {
          aceptados.push( i.id_producto );
        }
        else {
          if (i.id_lista == this.call.List.value.id) {
            noAceptados.push( i.id_producto );
          }

        }
      }

      this.incluidos.next(aceptados);
      this.noIncluidos.next(noAceptados);

      console.log(res);
      console.log(this.incluidos.value);
      console.log(this.noIncluidos.value);

    });

    console.log(this.rol.value);

  }

  aceptarProducto(idlist: number, idproduct: number) {

    let incluir: Incluir = {
      id_lista: idlist,
      id_producto: idproduct,
      aceptado: 1
    }

    this.api.modifyIncluir(idlist, idproduct, incluir).pipe(finalize(() => {

      // Añadir producto incluido
      let prodIncluidos = this.incluidos.value;
      prodIncluidos.push(idproduct);
      this.incluidos.next(prodIncluidos);
      // Eliminar producto no incluido
      let prodNoIncluidos = this.noIncluidos.value;
      let index: number = prodNoIncluidos.indexOf(idproduct);
      prodNoIncluidos.splice(index, 1);
      this.noIncluidos.next(prodNoIncluidos);

    })).subscribe(res => {
      if (res != null) {
        console.log(res);


      }
    });

  }



}

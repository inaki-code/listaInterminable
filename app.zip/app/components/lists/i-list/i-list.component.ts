import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SessionService } from '../../../services/session/session.service';
import { User } from '../../../interfaces/user';
import { List } from '../../../interfaces/list';
import { ApiService } from '../../../services/api/api.service';
import { CallComponentsService } from '../../../services/call-components/call-components.service';
import { finalize } from 'rxjs';
import { ListService } from '../../../services/list/list.service';

declare var $:any;

@Component({
  selector: 'i-list',
  templateUrl: './i-list.component.html',
  styleUrls: ['./i-list.component.css']
})
export class IListComponent implements OnInit {

  public id: number = -1;
  // Formulario de registro
  public iListForm: FormGroup;
  // URL de la foto
  url: string = '';

  constructor(private fb: FormBuilder, private session: SessionService, private api: ApiService, private call: CallComponentsService, private list: ListService) {
    this.iListForm = this.fb.group({
      nombre: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25)]],
      foto: ['']
    })
  }

  ngOnInit(): void {

    this.session.id.subscribe(res => {
        this.id = res;
    });

    // Avisar al servicio que cerramos la modal
    $('#Modal').on('hidden.bs.modal', () => {
      this.call.callIListModal.emit(false);
    });

    this.iListModalOpen();

  }

  iListModalOpen() {
    $('#Modal').modal('show');
  }

  iListModalClose() {
    $('#Modal').modal('hide');
  }

  iListSubmit() {

    let nombre: string = this.iListForm.controls['nombre'].value;
    let foto: any = this.url;

    //this.list.submitListaIndividual(nombre, foto);

    this.api.createList( nombre, 'individual', foto, this.id.toString(), this.id.toString(), this.id, '[]' ).pipe(finalize( () => {

      let lists: List[] = this.list.visibleLists.value;

      lists.push({
        'foto': foto,
        'id_usuario': this.id,
        'nombre': nombre,
        'propietarios': this.id.toString(),
        'tipo': 'individual',
        'usuarios': this.id.toString(),
        'id': -1,
        'likes': '[]'
      });

      this.list.visibleLists.next(lists);
      this.list.getListas();
      this.iListModalClose();

    })).subscribe(( res: any ) => {
      console.log(res);
    });

  }

  selectFile(event: any) {
    if (event.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event:any) => {
        this.url = event.target.result;
        console.log(this.url);
      }
    }
  }

}

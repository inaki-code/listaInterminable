import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SessionService } from '../../../services/session/session.service';
import { CallComponentsService } from '../../../services/call-components/call-components.service';

declare var $:any;

@Component({
  selector: 'c-list',
  templateUrl: './c-list.component.html',
  styleUrls: ['./c-list.component.css']
})
export class CListComponent implements OnInit {

  public id: number = -1;
  // Formulario de registro
  public cListForm: FormGroup;
  // URL de la foto
  url: string = '';

  constructor(private fb: FormBuilder, private session: SessionService, private call: CallComponentsService) {
    this.cListForm = this.fb.group({
      nombre: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25)]],
      foto: ['']
    })
  }

  ngOnInit(): void {
    this.session.id.subscribe(res => {
      this.id = res;
    });

    // Avisar al servicio que cerramos la modal
    $('#Modal').on('hidden.bs.modal', () => {
      this.call.callCListModal.emit(false);
    });

    this.cListModalOpen();
  }

  cListModalOpen() {
    $('#Modal').modal('show');
  }

  cListModalClose() {
    $('#Modal').modal('hide');
  }

  aListModalOpen() {

    this.cListModalClose();
    // Darle tiempo a la modal de listas que se cierre
    // Sino tendré 2 modales abiertas a la vez y no las podré cerrar
    setTimeout( () => {
      this.call.callAListModal.emit(true);
    }, 500 );
  }

  tListModalOpen() {

    this.cListModalClose();
    // Darle tiempo a la modal de listas que se cierre
    // Sino tendré 2 modales abiertas a la vez y no las podré cerrar
    setTimeout( () => {
      this.call.callTListModal.emit(true);
    }, 500 );
  }


}

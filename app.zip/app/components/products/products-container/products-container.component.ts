import { Component, OnInit } from '@angular/core';
import { Product } from '../../../interfaces/product';
import { BehaviorSubject } from 'rxjs';
import { CallComponentsService } from '../../../services/call-components/call-components.service';
import { ProductService } from '../../../services/product/product.service';

@Component({
  selector: 'products-container',
  templateUrl: './products-container.component.html',
  styleUrls: ['./products-container.component.css']
})
export class ProductsContainerComponent implements OnInit {

  // Productos visibles por el usuario
  public visibleProducts: BehaviorSubject<Product[]> = new BehaviorSubject<Product[]>(Array());

  public seeUser: BehaviorSubject<string> = new BehaviorSubject<string>('');
  public seeProducts: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public seeProductsModal: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public seeEditProductsModal: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  constructor(private call: CallComponentsService, private product: ProductService) { }

  ngOnInit(): void {

    // Productos del usuario
    this.product.visibleProducts.subscribe(res => {
      this.visibleProducts.next(res);
    });

    // Estamos pendientes de ProductsModal
    this.call.callProductsModal.subscribe(data => {
      this.seeProductsModal.next(data);
    });

    // Estamos pendientes de los Productos
    this.call.callProducts.subscribe(data => {
      this.seeProducts.next(data);
    });

    this.call.callEditProductsModal.subscribe(data => {
      this.seeEditProductsModal.next(data);
    });
  }

  callProductsModal() {
    this.call.callProductsModal.next(true);
  }

  borrarProducto(id: number) {
    this.product.borrarProducto(id);
  }

  callEditProductsModal(product: Product) {
    this.call.callEditProductsModal.next(true);
    this.call.editProductsModal.next(product);
  }



}

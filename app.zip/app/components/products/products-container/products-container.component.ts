import { Component, OnInit } from '@angular/core';
import { Product } from '../../../interfaces/product';
import { BehaviorSubject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { CallComponentsService } from '../../../services/call-components/call-components.service';
import { ProductService } from '../../../services/product/product.service';
import { FormGroup, FormBuilder } from '@angular/forms';

// JQUERY
declare var $:any;

@Component({
  selector: 'products-container',
  templateUrl: './products-container.component.html',
  styleUrls: ['./products-container.component.css']
})
export class ProductsContainerComponent implements OnInit {

  // Productos visibles por el usuario
  public visibleProducts: BehaviorSubject<Product[]> = new BehaviorSubject<Product[]>(Array());

  public seeUser: BehaviorSubject<string> = new BehaviorSubject<string>('');
  public seeProducts: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public seeProductsModal: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public seeEditProductsModal: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  // Formulario de búsqueda
  public searchForm: FormGroup;
  public productsFilter: BehaviorSubject<string> = new BehaviorSubject('');

  constructor(private call: CallComponentsService, private product: ProductService, private fb: FormBuilder) {
    this.searchForm = this.fb.group({
      search: []
    });
  }

  ngOnInit(): void {

    $('#lista').click(function(event: any){
      event.stopPropagation();
    });

    this.searchForm.controls['search'].valueChanges
    .pipe(
      debounceTime(500)
    )
    .subscribe(res => this.productsFilter.next(res));

    // Productos del usuario
    this.product.visibleProducts.subscribe(res => {
      this.visibleProducts.next(res);
    });

    // Estamos pendientes de ProductsModal
    this.call.callProductsModal.subscribe(data => {
      this.seeProductsModal.next(data);
    });

    // Estamos pendientes de los Productos
    this.call.callProducts.subscribe(data => {
      this.seeProducts.next(data);
    });

    this.call.callEditProductsModal.subscribe(data => {
      this.seeEditProductsModal.next(data);
    });
  }

  callProductsModal() {
    this.call.callProductsModal.next(true);
  }

  borrarProducto(id: number, event: any) {

    event.stopPropagation();
    this.product.borrarProducto(id);



  }

  callEditProductsModal(product: Product) {
    this.call.callEditProductsModal.next(true);
    this.call.editProductsModal.next(product);
  }



}

export interface Agregar {

  id_user: number;
  id_useragregado: number;
  agregado: number;


}

export interface Banpeticion {

  id: number
  mensaje: string;
  id_userban: number;
  id_usuario: number;

}

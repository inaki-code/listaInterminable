export interface List {

  id: number;
  nombre: string;
  tipo: string;
  foto?: any;
  usuarios: string;
  propietarios: string;
  likes: string;
  id_usuario: number;

}

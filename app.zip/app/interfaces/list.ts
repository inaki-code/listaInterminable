export interface List {

  id: number;
  nombre: string;
  tipo: string;
  foto?: any;
  usuarios: string;
  propietarios: string;
  id_usuario: number;
  ban: number;

}

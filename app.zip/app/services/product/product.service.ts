import { Injectable } from '@angular/core';
import { Product } from '../../interfaces/product';
import { ApiService } from '../api/api.service';
import { ListService } from '../list/list.service';
import { SessionService } from '../session/session.service';
import { BehaviorSubject, finalize } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  // Productos de la BDD
  public products: BehaviorSubject<Product[]> = new BehaviorSubject<Product[]>(Array());
  //id usuario logeado
  public id: BehaviorSubject<number> = new BehaviorSubject(-1);
  // Productos visibles
  public visibleProducts: BehaviorSubject<Product[]> = new BehaviorSubject<Product[]>(Array());

  constructor(private api: ApiService, private session: SessionService) {
    // Cada vez que cambiamos el usuario resetamos los productos
    this.session.id.subscribe(res => {
      this.id.next(res);
      this.getProductos();

    });
  }

  getProductos() {

    this.api.getProducts().pipe(finalize(() => {
      let products: Product[] = [];

      for (let p of this.products.value) {
        if (p.id_usuario == this.id.value) {
          products.push(p);
        }
      }

      this.visibleProducts.next(products);
      //console.log(this.visibleProducts.value);
    })).subscribe(( res: any ) => {

      this.products.next(res.products);

    });

  }

  borrarProducto(id: number) {

    this.api.removeIncluir(-1, id).subscribe();

    this.api.removeProduct(id).pipe(finalize( () => {
      // Borramos la lista de las listas visibles del usuario
      let productos = this.visibleProducts.value;

      for (let i = 0; i < productos.length; i++) {
        if (productos[i].id == id) {
          productos.splice(i, 1);
          break;
        }
      }

      this.visibleProducts.next(productos);
    })).subscribe();

  }

  modifificarProducto(id: number, product: Product) {
    this.api.modifyProduct(id, product).subscribe(res => {
      console.log(res);
    });
  }

}

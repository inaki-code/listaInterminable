import { Injectable } from '@angular/core';
import { SessionService } from '../session/session.service';
import { List } from '../../interfaces/list';
import { User } from '../../interfaces/user';
import { BehaviorSubject, finalize } from 'rxjs';
import { ApiService } from '../api/api.service';

@Injectable({
  providedIn: 'root'
})
export class ListService {

  reload: BehaviorSubject<boolean> = new BehaviorSubject(false);
  // Listas de la BDD
  public lists: BehaviorSubject<List[]> = new BehaviorSubject<List[]>(Array());
  // id usuario logeado
  public id: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  // Listas visibles
  public visibleLists: BehaviorSubject<List[]> = new BehaviorSubject<List[]>(Array());
  // id lista eliminable
  public idRemove: BehaviorSubject<number> = new BehaviorSubject<number>(-1);

  constructor(private session: SessionService, private api: ApiService) {

    // Cada vez que cambiamos el usuario reseteamos las listas
    this.session.id.subscribe(res => {
      this.id.next(res);
      this.getListas();
    });

    // Recibir listas
    /*this.reload.subscribe(() => {

      setTimeout( ()=>{
        this.getListas();
      }, 20 * 1000 );

    });*/
  }

  getListas() {

    this.api.getLists().pipe(finalize(() => {
      let lists: List[] = [];

      for (let l of this.lists.value) {
        if (l.id_usuario == this.id.value || l.propietarios.includes( this.id.value.toString() ) || l.usuarios.includes( this.id.value.toString() ) ) {
          lists.push(l);
        }

      }
      this.visibleLists.next(lists);
      this.reload.next(true);
    })).subscribe(( res: any ) => {

      this.lists.next(res.lists);

    });

  }

}

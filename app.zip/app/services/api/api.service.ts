import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../../interfaces/user';
import { List } from '../../interfaces/list';
import { Product } from '../../interfaces/product';
import { Observable } from 'rxjs';
import { Agregar } from '../../interfaces/agregar';
import { Incluir } from '../../interfaces/incluir';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private httpClient: HttpClient) { }
  /* ------------------- */
  // --- Usuarios ---

  // ---Get

  public getUsers(): Observable<User[]> {
    return this.httpClient.get<User[]>('http://localhost/listainterminable/php/apiuser.php');
  }

  // ---Create
  public createUser(email: string, password: string, repeatPassword: string, foto: any, status: string, name: string) {

    if (repeatPassword == password) {
      return this.httpClient.post<User>('http://localhost/listainterminable/php/apiuser.php',
      {
        "email": email,
        "status": status,
        "foto": foto,
        "password": password,
        "name": name
      });
    }
    else {
      alert('las contraseñas no coninciden');
      throw Error('Las constraseñas no coinciden');
    }

  }

  // ---Modify
  public modifyUser(id: number, user: User) {
    return this.httpClient.put<User>('http://localhost/listainterminable/php/apiuser.php?id_user=' + id, user);
  }
  /* ------------------- */
  // --- Productos ---
  // ---Get

  public getProducts(): Observable<Product[]> {
    return this.httpClient.get<Product[]>('http://localhost/listainterminable/php/apiproduct.php');
  }

  // ---Create
  public createProduct(name: string, price: number, weight: string, foto: any, idUser: number) {
    return this.httpClient.post<Product>('http://localhost/listainterminable/php/apiproduct.php',
      {
        "nombre": name,
        "precio": price,
        "peso_neto": weight,
        "foto": foto,
        "id_usuario": idUser
      });
  }

  // ---Delete
  public removeProduct(id: number) {
    return this.httpClient.delete<Product>('http://localhost/listainterminable/php/apiproduct.php?id=' + id)
  }
  // ---Modify
  public modifyProduct(id: number, product: Product) {
    return this.httpClient.put<Product>('http://localhost/listainterminable/php/apiproduct.php?id=' + id, product);
  }
  /* ------------------- */
  // --- Listas ---
  // ---Get

  public getLists(): Observable<List[]> {
    return this.httpClient.get<List[]>('http://localhost/listainterminable/php/apilist.php');
  }

  // ---Create
  public createList(nombre: string, tipo: string, foto: any, usuarios: string, propietarios: string, id_usuario: number, likes: string) {
    return this.httpClient.post<List>('http://localhost/listainterminable/php/apilist.php',
      {
        "nombre": nombre,
        "tipo": tipo,
        "foto": foto,
        "usuarios": usuarios,
        "propietarios": propietarios,
        "id_usuario": id_usuario,
        "likes": likes
      });
  }

  // ---Delete
  public removeList(id: number) {
    return this.httpClient.delete<List>('http://localhost/listainterminable/php/apilist.php?id=' + id)
  }

  // ---Modify
  public modifyList(id: number, list: List) {
    return this.httpClient.put<List>('http://localhost/listainterminable/php/apilist.php?id=' + id, list);
  }
  /* ------------------- */
  // --- Agregar ---
  // ---Get

  public getAgregar(): Observable<Agregar[]> {
    return this.httpClient.get<Agregar[]>('http://localhost/listainterminable/php/apiagregar.php');
  }

  // ---Create
  public createAgregar(id_usuario: number, id_usuarioAgregado: number) {
    return this.httpClient.post<Agregar>('http://localhost/listainterminable/php/apiagregar.php',
      {
        "id_user": id_usuario,
        "id_userAgregado": id_usuarioAgregado
      });
  }

  // ---Delete
  public removeAgregar(id_user: number, id_userAgregado: number) {
    return this.httpClient.delete<Agregar>('http://localhost/listainterminable/php/apiagregar.php?id_user=' + id_user + "&id_userAgregado=" + id_userAgregado);
  }

  // ---Modify
  public modifyAgregar(id_user: number, id_userAgregado: number, agregar: Agregar) {
    return this.httpClient.put<Agregar>('http://localhost/listainterminable/php/apiagregar.php?id_user=' + id_user + "&id_userAgregado=" + id_userAgregado, agregar);
  }

  /* ------------------- */
  // --- Incluir ---
  // ---Get

  public getIncluir(): Observable<Incluir[]> {
    return this.httpClient.get<Incluir[]>('http://localhost/listainterminable/php/apiincluir.php');
  }

  // ---Create
  public createIncluir(id_list: number, id_product: number, aceptado: number) {
    return this.httpClient.post<Incluir>('http://localhost/listainterminable/php/apiincluir.php',
      {
        "id_list": id_list,
        "id_product": id_product,
        "aceptado": aceptado
      });
  }

  // ---Delete
  public removeIncluir(id_list: number, id_product:number) {
    return this.httpClient.delete<Incluir>('http://localhost/listainterminable/php/apiincluir.php?id_list=' + id_list + "&id_product=" + id_product);
  }

  // ---Modify
  public modifyIncluir(id_list: number, id_product: number, incluir: Incluir) {
    return this.httpClient.put<Agregar>('http://localhost/listainterminable/php/apiincluir.php?id_list=' + id_list + "&id_product=" + id_product, incluir);
  }


}

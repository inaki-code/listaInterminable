import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Routes, RouterModule } from '@angular/router';
import { SingupComponent } from './components/singup/singup.component';
import { HomeComponent } from './components/home/home.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { SinginComponent } from './components/singin/singin.component';
import { ListsComponent } from './components/lists/lists/lists.component';
import { CListComponent } from './components/lists/c-list/c-list.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { ProductComponent } from './components/products/product/product.component';
import { FilterPipe } from './pipes/filter/filter.pipe';
import { SearchuserComponent } from './components/searchuser/searchuser.component';
import { ListsContainerComponent } from './components/lists/lists-container/lists-container.component';
import { ProductsContainerComponent } from './components/products/products-container/products-container.component';
import { ListComponent } from './components/lists/list/list.component';
import { DragDropComponent } from './components/lists/drag-drop/drag-drop.component';
import { CDK_DRAG_CONFIG, DragDropModule } from '@angular/cdk/drag-drop';
import { SearchPipe } from './pipes/search/search.pipe';
import { FriendshipRequestComponent } from './components/friendship-request/friendship-request.component';
import { EditProductComponent } from './components/products/edit-product/edit-product.component';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { ProfileComponent } from './components/profile/profile.component';
import { BanPeticionComponent } from './components/ban-peticion/ban-peticion.component';
import { BanPeticionContainerComponent } from './components/ban-peticion-container/ban-peticion-container.component';
import { HopperPipe } from './pipes/hopper/hopper.pipe';
import { UserContainerComponent } from './components/user-container/user-container.component';
import { ListBansContainerComponent } from './components/list-bans-container/list-bans-container.component';
import { DrUserlistComponent } from './components/lists/dr-userlist/dr-userlist.component';
import { NewListModalComponent } from './components/lists/new-list-modal/new-list-modal.component';
import { GraphComponent } from './components/graph/graph.component';
import { NgChartsModule } from 'ng2-charts';

const routes: Routes = [
  { path:'', redirectTo:'/home', pathMatch: 'full' },
  { path:'home', component:HomeComponent }
];

const DragConfig = {
  dragStartThreshold: 0,
  pointerDirectionChangeThreshold: 5,
  zIndex: 10000
};

@NgModule({
  declarations: [
    AppComponent,
    SingupComponent,
    HomeComponent,
    SinginComponent,
    ListsComponent,
    CListComponent,
    NavbarComponent,
    ProductComponent,
    FilterPipe,
    SearchuserComponent,
    ListsContainerComponent,
    ProductsContainerComponent,
    ListComponent,
    DragDropComponent,
    SearchPipe,
    FriendshipRequestComponent,
    EditProductComponent,
    ProfileComponent,
    BanPeticionComponent,
    BanPeticionContainerComponent,
    HopperPipe,
    UserContainerComponent,
    ListBansContainerComponent,
    DrUserlistComponent,
    NewListModalComponent,
    GraphComponent
  ],
  imports: [
    RouterModule.forRoot(routes, {useHash: true}),
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    DragDropModule,
    ScrollingModule,
    NgChartsModule
  ],
  providers: [{ provide: CDK_DRAG_CONFIG, useValue: DragConfig }],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SessionService } from '../../../services/session/session.service';
import { List } from '../../../interfaces/list';
import { ApiService } from '../../../services/api/api.service';
import { CallComponentsService } from '../../../services/call-components/call-components.service';
import { finalize } from 'rxjs';
import { ListService } from '../../../services/list/list.service';

declare var $:any;

@Component({
  selector: 't-list',
  templateUrl: './t-list.component.html',
  styleUrls: ['./t-list.component.css']
})
export class TListComponent {

  public id: number = -1;
  // Formulario de registro
  public tListForm: FormGroup;
  // URL de la foto
  public url: string = '';
  //
  public users: any = [];
  //
  public agregados: any = [];
  //
  public propietarios: any = [];

  constructor(private fb: FormBuilder, private session: SessionService, private api: ApiService, private call: CallComponentsService, private list: ListService) {
    this.tListForm = this.fb.group({
      nombre: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25)]],
      foto: ['']
    })
  }

  ngOnInit(): void {

    this.session.id.subscribe(res => {
        this.id = res;
    });

    // Avisar al servicio que cerramos la modal
    $('#Modal').on('hidden.bs.modal', () => {
      this.call.callTListModal.emit(false);
    });

    this.tListModalOpen();

  }

  tListModalOpen() {
    $('#Modal').modal('show');
  }

  tListModalClose() {
    $('#Modal').modal('hide');
  }

  tListSubmit() {

    let nombre: string = this.tListForm.controls['nombre'].value;
    let foto: any = this.url;
    let usuarios: number[] = [];
    let propietarios: number[] = [];
    let cadenaUsuarios: string = '';
    let cadenaPropietarios: string = '';

    console.log(usuarios);
    console.log(propietarios);

    for (let u of this.users) {
      usuarios.push(u.id);
    }

    cadenaUsuarios = '[' + usuarios.toString() + ']';
    console.log(cadenaUsuarios);

    for (let u of this.propietarios) {
      propietarios.push(u.id);
    }

    cadenaPropietarios = '[' + propietarios.toString() + ']';
    console.log(cadenaPropietarios);

    this.api.createList( nombre, 'totalitaria', foto, cadenaUsuarios, cadenaPropietarios, this.id ).pipe(finalize( () => {

      let lists: List[] = this.list.visibleLists.value;

      lists.push({
        'foto': foto,
        'id_usuario': this.id,
        'nombre': nombre,
        'propietarios': cadenaPropietarios,
        'tipo': 'anarquica',
        'usuarios': cadenaUsuarios,
        'id': -1,
        'ban': 0
      });

      console.log(cadenaUsuarios);
      console.log(cadenaPropietarios);

      this.list.visibleLists.next(lists);
      console.log(lists);
      this.list.getListas();
      this.tListModalClose();


    })).subscribe(( res: any ) => {
      console.log(res);
      this.ngOnInit();
    });


  }

  selectFile(event: any) {
    if (event.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event:any) => {
        this.url = event.target.result;
        console.log(this.url);
      }
    }
  }

  addUsers(users: any, userstipo: string) {

    switch (userstipo) {
      case 'users':
        this.users = users;
        console.log(users);
        break;
      case 'propietarios':
        this.propietarios = users;
        console.log(users);
        break;
      case 'agregados':
        this.agregados = users;
        console.log(users);
        break;
    }

  }

}

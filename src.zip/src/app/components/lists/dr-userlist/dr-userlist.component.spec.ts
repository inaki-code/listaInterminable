import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DrUserlistComponent } from './dr-userlist.component';

describe('DrUserlistComponent', () => {
  let component: DrUserlistComponent;
  let fixture: ComponentFixture<DrUserlistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DrUserlistComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DrUserlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, Input, OnInit, Output, AfterViewChecked } from '@angular/core';
import { FormGroup, FormBuilder} from '@angular/forms';
import { BehaviorSubject, debounceTime } from 'rxjs';
import { User } from '../../../interfaces/user';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { AgregarService } from '../../../services/agregar/agregar.service';
import { SessionService } from '../../../services/session/session.service';
import { CallComponentsService } from '../../../services/call-components/call-components.service';
import { List } from '../../../interfaces/list';
import { ApiService } from '../../../services/api/api.service';
import { PertenecerService } from '../../../services/pertenecer/pertenecer.service';
import { Pertenecer } from '../../../interfaces/pertenecer';

// JQUERY
declare var $:any;

@Component({
  selector: 'dr-userlist',
  templateUrl: './dr-userlist.component.html',
  styleUrls: ['./dr-userlist.component.css']
})
export class DrUserlistComponent {

  @Input()
  public newList: boolean = true;
  public searchUser: FormGroup;
  public list: BehaviorSubject<List> = new BehaviorSubject({
    id: -1, nombre: '', tipo: '', id_usuario: -1, ban: 0
  });
  @Output()
  public propietarios: BehaviorSubject<any> = new BehaviorSubject(Array());
  @Output()
  public usuarios: BehaviorSubject<any> = new BehaviorSubject(Array());
  @Output()
  public agregados: BehaviorSubject<any> = new BehaviorSubject(Array());
  public idUsuarios: BehaviorSubject<number[]> = new BehaviorSubject(Array());
  public idPropietarios: BehaviorSubject<number[]> = new BehaviorSubject(Array());
  public idAgregados: BehaviorSubject<number[]> = new BehaviorSubject(Array());
  public usersSearch: BehaviorSubject<string> = new BehaviorSubject('');
  public propietariosSearch: BehaviorSubject<string> = new BehaviorSubject('');
  public agregadosSearch: BehaviorSubject<string> = new BehaviorSubject('');
  public foto: any = '';
  public email: string = '';
  public id: BehaviorSubject<number> = new BehaviorSubject(-1);
  public usuarioPropietario: BehaviorSubject<User> = new BehaviorSubject({
    'id': -1, 'email': '', 'foto': '', 'token': '', 'status': '', 'name': '', 'loggedin': 0, 'ban': 0
  });
  public rol: BehaviorSubject<string> = new BehaviorSubject('');
  public lastMovedUserIndex:BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  public lastMovedUser:BehaviorSubject<User> = new BehaviorSubject<User>({
    'id': -1, 'email': '', 'foto': '', 'token': '', 'status': '', 'name': '', 'loggedin': 0, 'ban': 0
  });

  constructor(private fb: FormBuilder, private session: SessionService, private call: CallComponentsService, private api: ApiService, private pertenecer: PertenecerService) {
    this.searchUser = this.fb.group({
      searchUser: [],
      searchPropietario: [],
      searchAgregado: []
    });
  }

  ngOnInit(): void {

    this.subscriptions();

    console.log(this.agregados.value);
    console.log(this.propietarios.value);
    console.log(this.usuarios.value);

    console.log(this.call.List.value);
    console.log(this.rol.value);

  }

  ngAfterViewChecked(): void {
    $('[data-toggle="tooltip"]').tooltip();
  }

  dropped_user($event: CdkDragDrop<BehaviorSubject<User[]>>, list: string) {

    if ($event.previousContainer === $event.container) {
      moveItemInArray(
        $event.container.data.value,
        this.lastMovedUserIndex.value,
        $event.currentIndex
      );
    }
    else {
      transferArrayItem(
        $event.previousContainer.data.value,
        $event.container.data.value,
        this.lastMovedUserIndex.value,
        $event.currentIndex
      );

      this.searchUser.reset();

      /*console.log(this.agregados.value);
      console.log(this.propietarios.value);
      console.log(this.usuarios.value);*/

      this.call.agregados.next(this.agregados.value);
      this.call.propietarios.next(this.propietarios.value);
      this.call.usuarios.next(this.usuarios.value);


      if (!this.newList) {
        /*console.log($event.previousContainer.id);
        console.log($event.container.id);*/
        console.log($event.previousContainer.id);



        switch (list) {

          // Nos dejan un usuario en propietarios
          case 'propietarios':

            switch ($event.previousContainer.id) {

              // El usuario movido viene del cdk de agregados
              case 'cdk-drop-list-4':

                this.api.createPertenecer(this.list.value.id, this.lastMovedUser.value.id, 'propietario').subscribe(res => {
                  console.log(res);
                });

                break;
              // El usuario movido vienen del cdk de usuarios
              case 'cdk-drop-list-3':

                let idsPertenecer: Pertenecer[] = this.pertenecer.pertenecer.value.filter(p => p.id_user == this.lastMovedUser.value.id && p.id_list == this.call.List.value.id);
                let idPertenecer: number = idsPertenecer[0].id;

                this.api.modifyPertenecer(idPertenecer, 'propietario').subscribe(res => {
                  console.log(res);
                });

                break;

            }

            break;
          // Nos dejan un usuario en usuarios
          case 'usuarios':

            switch ($event.previousContainer.id) {

              // El usuario movido viene del cdk de agregados
              case 'cdk-drop-list-4':

                this.api.createPertenecer(this.list.value.id, this.lastMovedUser.value.id, 'usuario').subscribe(res => {
                  console.log(res);
                });

                break;
              // El usuario movido vienen del cdk de propietarios
              case 'cdk-drop-list-2':

                let idsPertenecer: Pertenecer[] = this.pertenecer.pertenecer.value.filter(p => p.id_user == this.lastMovedUser.value.id && p.id_list == this.call.List.value.id);
                let idPertenecer: number = idsPertenecer[0].id;

                this.api.modifyPertenecer(idPertenecer, 'usuario').subscribe(res => {
                  console.log(res);
                });

                break;

            }

            break;
          // Nos dejan un usuario en agregados
          case 'agregados':

            let idsPertenecer: Pertenecer[] = this.pertenecer.pertenecer.value.filter(p => p.id_user == this.lastMovedUser.value.id && p.id_list == this.call.List.value.id);
            let idPertenecer: number = idsPertenecer[0].id;

            this.api.removePertenecer(idPertenecer).subscribe(res => {
              console.log(res);
            });


            break;

        }

      }

    }

  }

  subscriptions() {
    this.searchUser.controls['searchUser'].valueChanges
    .pipe(
      debounceTime(500)
    )
    .subscribe(res => this.usersSearch.next(res));

    this.searchUser.controls['searchPropietario'].valueChanges
    .pipe(
      debounceTime(500)
    )
    .subscribe(res => this.propietariosSearch.next(res));

    this.searchUser.controls['searchAgregado'].valueChanges
    .pipe(
      debounceTime(500)
    )
    .subscribe(res => this.agregadosSearch.next(res));

    this.session.email.subscribe(res => {
      this.email = res;
    });

    this.session.foto.subscribe(res => {
      this.foto = res;
    });

    this.call.List.subscribe(res => {
      this.list.next(res);
    });

    this.session.id.subscribe(res => {
      this.id.next(res);
    });

    this.call.rol.subscribe(res => {
      this.rol.next(res);
    });

    this.call.agregados.subscribe(res => {
      this.agregados.next(res);
      console.log(res);
    });

    this.call.usuarios.subscribe(res => {
      this.usuarios.next(res);
      console.log(res);
    });

    this.call.propietarios.subscribe(res => {
      this.propietarios.next(res);
      console.log(res);
    });

    if (this.newList) {
      let users: User[] = this.session.users.value.filter(user => user.id == this.id.value);
      let user = users[0];
      this.usuarioPropietario.next(user);
    }
    else {
      this.call.usuarioPropietario.subscribe(res => {
        this.usuarioPropietario.next(res);
        console.log(res);
      });
    }


    // Rol dentro de la lista
    if (this.newList) {
      this.rol.next('propietario');
    }
    else {
      let users: User[] = this.call.propietarios.value.filter(user => user.id == this.id.value);
      console.log(this.call.propietarios.value);
      if (this.session.status.value == 'admin' || users.length > 0 || this.list.value.id_usuario == this.id.value) {
        this.rol.next('propietario');
      }
      else {
        this.rol.next('usuario');
      }
    }

    //this.getUsers();

  }

  itemStartDrag(u: User, list: string) {

    let index: number = -1;
    let user: User = {id: -1, email: '', status: '', loggedin: 0, name: '', foto: '', token: '', ban: 0};

    switch (list) {
      case 'propietarios':

        for (let i = 0; i < this.propietarios.value.length; i++) {
          if (this.propietarios.value[i].id == u.id) {
            index = i;
            user = this.propietarios.value[i];
            break;
          }
        }

        break;

      case 'usuarios':

        for (let i = 0; i < this.usuarios.value.length; i++) {
          if (this.usuarios.value[i].id == u.id) {
            index = i;
            user = this.usuarios.value[i];
            break;
          }
        }

        break;

        case 'agregados':

        for (let i = 0; i < this.agregados.value.length; i++) {
          if (this.agregados.value[i].id == u.id) {
            index = i;
            user = this.agregados.value[i];
            break;
          }
        }

        break;
    }

    this.lastMovedUserIndex.next(index);
    this.lastMovedUser.next(user);

  }

}

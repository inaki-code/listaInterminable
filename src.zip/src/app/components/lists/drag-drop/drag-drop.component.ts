import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Component, OnInit, AfterViewChecked } from '@angular/core';
import { Product } from '../../../interfaces/product';
import { ApiService } from '../../../services/api/api.service';
import { CallComponentsService } from '../../../services/call-components/call-components.service';
import { FormGroup, FormBuilder} from '@angular/forms';
import { debounceTime, finalize } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';
import { IncluirService } from '../../../services/inlcluir/incluir.service';
import { List } from '../../../interfaces/list';
import { SessionService } from '../../../services/session/session.service';
import { ProductService } from '../../../services/product/product.service';
import { Incluir } from '../../../interfaces/incluir';
import { User } from '../../../interfaces/user';
import Swal from 'sweetalert2';
import { ComprarService } from '../../../services/comprar/comprar.service';
import { Comprar } from '../../../interfaces/comprar';

// JQUERY
declare var $:any;

@Component({
  selector: 'drag-drop',
  templateUrl: './drag-drop.component.html',
  styleUrls: ['./drag-drop.component.css']
})
export class DragDropComponent implements OnInit, AfterViewChecked {

  public visibleProducts: BehaviorSubject<number[]> = new BehaviorSubject<number[]>(Array());
  public listedProducts:BehaviorSubject<any> = new BehaviorSubject(Array());
  public products:BehaviorSubject<any> = new BehaviorSubject(Array());
  public searchProduct: FormGroup;
  public listedProductsFilter: BehaviorSubject<string> = new BehaviorSubject('');
  public noListedProductsFilter: BehaviorSubject<string> = new BehaviorSubject('');
  public list: BehaviorSubject<List> = new BehaviorSubject({ id: -1, nombre: '', tipo: '', id_usuario: -1, ban: 0 });
  public lastMovedProductIndex:BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  public rol: BehaviorSubject<string> = new BehaviorSubject('');
  public listedProductsPrice:BehaviorSubject<number> = new BehaviorSubject(0);
  public usuariosLista: BehaviorSubject<number> = new BehaviorSubject(0);
  public ppp:BehaviorSubject<number> = new BehaviorSubject(0);


  public incluidos: BehaviorSubject<number[]> = new BehaviorSubject(Array());
  public noIncluidos: BehaviorSubject<number[]> = new BehaviorSubject(Array());


  constructor(private api: ApiService, private call: CallComponentsService, private fb: FormBuilder, private incluir: IncluirService, public session: SessionService, private productService: ProductService, private comprar: ComprarService) {

    this.searchProduct = this.fb.group({
      searchListed: [],
      searchNoListed: []
    });
  }

  ngOnInit(): void {

    this.suscriptions();

    /*console.log(this.incluidos.value);
    console.log(this.noIncluidos.value);*/

  }

  ngAfterViewChecked(): void {
    $('[data-toggle="tooltip"]').tooltip();
  }

  dropped_product($event: CdkDragDrop<BehaviorSubject<Product[]>>, list: string) {

    /*console.log(this.listedProducts.value);
    console.log(this.products.value);*/
    //console.log($event);

    if ($event.previousContainer === $event.container) {
      moveItemInArray(
        $event.container.data.value,
        //
        this.lastMovedProductIndex.value,
        //
        $event.currentIndex
      );
    }
    else {
      transferArrayItem(
        $event.previousContainer.data.value,
        $event.container.data.value,
        //
        this.lastMovedProductIndex.value,
        //
        $event.currentIndex
      );

      /*console.log(this.incluidos.value);
      console.log(this.noIncluidos.value);*/

      let product: Product = $event.container.data.value[$event.currentIndex];
      //console.log(product);

      switch (list) {
        case 'products':

          this.listedProductsPrice.next(this.listedProductsPrice.value + parseInt(product.precio.toString()));
          this.ppp.next( this.listedProductsPrice.value / this.usuariosLista.value);

          if (this.list.value.tipo == 'totalitaria' && this.rol.value == 'propietario') {
            this.api.createIncluir(this.call.List.value.id, product.id, 1).pipe(finalize( () => {

              /*console.log(this.listedProducts.value);
              console.log(this.products.value);*/

              // Añadir productos incluidos
              let prodIncluidos = this.incluidos.value;
              prodIncluidos.push(product.id);
              this.incluidos.next(prodIncluidos);

            })).subscribe(res => {
              if (res != null) {
                console.log(res);
              }
            });
          }
          else {
            this.api.createIncluir(this.call.List.value.id, product.id, 0).pipe(finalize( () => {

              /*console.log(this.listedProducts.value);
              console.log(this.products.value);
              console.log(product);*/

              // Añadir productos no incluidos
              let prodNoIncluidos = this.noIncluidos.value;
              prodNoIncluidos.push(product.id);
              this.noIncluidos.next(prodNoIncluidos);

            })).subscribe(res => {
              if (res != null) {
                console.log(res);
              }
            });
          }


          break;
        case 'listedProducts':

          this.listedProductsPrice.next(this.listedProductsPrice.value - parseInt(product.precio.toString()));
          this.ppp.next( this.listedProductsPrice.value / this.usuariosLista.value);

          this.api.removeIncluir(this.call.List.value.id, product.id).pipe(finalize( () => {

            /*console.log(this.listedProducts.value);
            console.log(this.products.value);
            console.log(product);*/

            // Eliminar productos incluidos o no incluidos
            if ( this.incluidos.value.includes(product.id) ) {

              let prodIncluidos = this.incluidos.value;
              let index: number = prodIncluidos.indexOf(product.id);
              prodIncluidos.splice(index, 1);
              this.incluidos.next(prodIncluidos);

            }
            else {

              let prodNoIncluidos = this.noIncluidos.value;
              let index: number = prodNoIncluidos.indexOf(product.id);
              prodNoIncluidos.splice(index, 1);
              this.noIncluidos.next(prodNoIncluidos);

            }




          })).subscribe(res => {
            if (res != null) {
              console.log(res);
            }
          });
          break;
      }

    }

    this.searchProduct.reset();

  }

  getRol() {

    let propietarios: User[] = this.call.propietarios.value.filter(user => user.id == this.session.id.value);

    //console.log(this.call.propietarios.value);
    if (this.session.status.value == 'admin' || propietarios.length > 0 || this.list.value.id_usuario == this.session.id.value) {
      this.rol.next('propietario');
    }
    else {

      let usuarios: User[] = this.call.usuarios.value.filter(user => user.id == this.session.id.value);
      if (usuarios.length > 0) {
        this.rol.next('usuario');
      }
      else {
        this.rol.next('random');
      }

    }

  }

  suscriptions() {

    this.searchProduct.controls['searchListed'].valueChanges
    .pipe(
      debounceTime(500)
    )
    .subscribe(res => this.listedProductsFilter.next(res));

    this.searchProduct.controls['searchNoListed'].valueChanges
    .pipe(
      debounceTime(500)
    )
    .subscribe(res => this.noListedProductsFilter.next(res));

    this.incluir.listedProducts.subscribe(res => {

      this.listedProducts.next(res);

      let totalPrice: number = 0;
      for (let p of res ) {
        totalPrice = totalPrice + parseInt(p.precio.toString());
      }

      this.listedProductsPrice.next(totalPrice);
      this.ppp.next(totalPrice / this.usuariosLista.value);

      if (res != null) {
        console.log(res);
      }

      console.log(this.listedProducts.value);
    });

    this.incluir.products.subscribe(res => {
      this.products.next(res);
      if (res != null) {
        console.log(res);
      }
    });

    this.call.List.subscribe(res => {
      this.list.next(res);
    });

    this.call.rol.subscribe(res => {
      this.rol.next(res);
    });

    this.call.usuariosLista.subscribe(res => {
      this.usuariosLista.next(res);
    })

    this.productService.visibleProducts.subscribe(res => {

      let productosVisibles: number[] = []

      for (let producto of res) {
        productosVisibles.push(producto.id);
      }

      this.visibleProducts.next(productosVisibles);

    });

    this.incluir.incluir.subscribe(res => {

      let aceptados: number[] = [];
      let noAceptados: number[] = [];;

      for (let i of res) {
        if (i.aceptado == 1 && i.id_lista == this.call.List.value.id) {
          aceptados.push( i.id_producto );
        }
        else {
          if (i.id_lista == this.call.List.value.id) {
            noAceptados.push( i.id_producto );
          }

        }
      }

      this.incluidos.next(aceptados);
      this.noIncluidos.next(noAceptados);

      /*console.log(this.incluidos.value);
      console.log(res);*/
      /*console.log(this.incluidos.value);
      console.log(this.noIncluidos.value);*/

    });

    this.getRol();
    //console.log(this.rol.value);

  }

  aceptarProducto(idlist: number, idproduct: number) {

    let incluir: Incluir = {
      id_lista: idlist,
      id_producto: idproduct,
      aceptado: 1
    }

    this.api.modifyIncluir(idlist, idproduct, incluir).pipe(finalize(() => {

      // Añadir producto incluido
      let prodIncluidos = this.incluidos.value;
      prodIncluidos.push(idproduct);
      this.incluidos.next(prodIncluidos);
      // Eliminar producto no incluido
      let prodNoIncluidos = this.noIncluidos.value;
      let index: number = prodNoIncluidos.indexOf(idproduct);
      prodNoIncluidos.splice(index, 1);
      this.noIncluidos.next(prodNoIncluidos);

    })).subscribe(res => {
      if (res != null) {
        console.log(res);
      }
    });

  }

  itemStartDrag(p: Product, list: string) {

    let index: number = -1;

    switch (list) {
      case 'products':

        for (let i = 0; i < this.products.value.length; i++) {
          if (this.products.value[i].id == p.id) {
            index = i;
            break;
          }
        }

        break;

      case 'listedProducts':

        for (let i = 0; i < this.listedProducts.value.length; i++) {
          if (this.listedProducts.value[i].id == p.id) {
            index = i;
            break;
          }
        }

        break;
    }

    this.lastMovedProductIndex.next(index);

  }

  submitComprar() {

    let n = new Date();
    let date: string = n.toLocaleString("ja-JP");

    if (this.ppp.value <= 0) {
      Swal.fire('Error!', 'No se añadirán compras de 0€', 'error');
    }
    else {
      this.api.createComprar(this.session.id.value, this.call.List.value.nombre, this.ppp.value).subscribe(res => {
        if (res != null) {
          console.log(res);
        }
      });

      let compras: Comprar[] = this.comprar.userCompras.value;
      let ultimaCompra: Comprar = {id: -1, id_usuario: this.session.id.value, nombre_lista: this.call.List.value.nombre, precio: this.ppp.value, fecha: date};
      compras.push(ultimaCompra);
      this.comprar.userCompras.next(compras);

      let msj = 'Se añadió una compra de ' + this.ppp.value + '€ de la lista ' + this.call.List.value.nombre
      Swal.fire('Compra añadida', msj, 'success');
    }

  }






}

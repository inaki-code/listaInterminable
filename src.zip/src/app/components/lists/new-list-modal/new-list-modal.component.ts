import { Component, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SessionService } from '../../../services/session/session.service';
import { List } from '../../../interfaces/list';
import { ApiService } from '../../../services/api/api.service';
import { CallComponentsService } from '../../../services/call-components/call-components.service';
import { BehaviorSubject, finalize } from 'rxjs';
import { ListService } from '../../../services/list/list.service';
import { AgregarService } from '../../../services/agregar/agregar.service';
import { User } from '../../../interfaces/user';
import { PertenecerService } from '../../../services/pertenecer/pertenecer.service';
import { Pertenecer } from '../../../interfaces/pertenecer';

declare var $:any;

@Component({
  selector: 'new-list-modal',
  templateUrl: './new-list-modal.component.html',
  styleUrls: ['./new-list-modal.component.css']
})
export class NewListModalComponent {

  public tipo: BehaviorSubject<string> = new BehaviorSubject<string>('');
  public id: number = -1;
  // Formulario de registro
  public newListForm: FormGroup;
  // URL de la foto
  public url: string = '';
  //
  public users: any = [];
  //
  public agregados: any = [];
  //
  public propietarios: any = [];
  public nextId: BehaviorSubject<number> = new BehaviorSubject<number>(-1);

  constructor(private fb: FormBuilder, private session: SessionService, private api: ApiService, private call: CallComponentsService, private list: ListService, private pertenecer: PertenecerService) {
    this.newListForm = this.fb.group({
      nombre: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25)]],
      foto: ['']
    });
  }

  ngOnInit(): void {

    this.call.List.next({
      id: -1, nombre: '', tipo: '', id_usuario: -1, ban: 0
    });

    this.call.rol.next('propietario');

    this.call.newListModaltype.subscribe(res => {
      this.tipo.next(res);
    });

    this.session.id.subscribe(res => {
      this.id = res;
    });

    // Avisar al servicio que cerramos la modal
    $('#Modal').on('hidden.bs.modal', () => {
      this.call.callNewListModal.emit(false);
    });

    this.newListModalOpen();

  }

  newListModalOpen() {
    $('#Modal').modal('show');
  }

  newListModalClose() {
    $('#Modal').modal('hide');
  }

  selectFile(event: any) {
    if (event.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event:any) => {
        this.url = event.target.result;
        //console.log(this.url);
      }
    }
  }

  newListSubmit() {

    let nombre: string = this.newListForm.controls['nombre'].value;
    let foto: any = this.url;
    let usuarios: number[] = [];
    let propietarios: number[] = [];
    let newPertenecer: Pertenecer[] = new Array();

    for (let u of this.users) {
      usuarios.push(u.id);
    }

    for (let u of this.propietarios) {
      propietarios.push(u.id);
    }

    this.api.nextId().pipe(finalize( () => {
      this.api.createList( nombre, this.tipo.value, foto, this.id ).pipe(finalize( () => {

        for (let p of propietarios) {
          this.api.createPertenecer(this.nextId.value, p, 'propietario').subscribe(res => {
            if (res != null) {
              console.log(res);
            }
          });

          let per: Pertenecer = {id: -1, id_list: this.nextId.value, id_user: p, rol: 'propietario' };
          newPertenecer.push(per);

        }

        for (let u of usuarios) {
          this.api.createPertenecer(this.nextId.value, u, 'usuario').pipe(finalize(() => {
            this.pertenecer.getPertenecer();
          })).subscribe(res => {
            if (res != null) {
              console.log(res);
            }
          });

          let per: Pertenecer = {id: -1, id_list: this.nextId.value, id_user: u, rol: 'usuario' };
          newPertenecer.push(per);

        }

        let Perteneceres: Pertenecer[] = this.pertenecer.pertenecer.value;

        for (let p of newPertenecer) {
          Perteneceres.push(p);
        }

        this.pertenecer.pertenecer.next(Perteneceres);

        this.list.getListas();
        //this.pertenecer.getPertenecer();
        this.call.List.next({id: 10, nombre: '', tipo: '', id_usuario: -1, ban: 0});

        this.newListModalClose();

        /*console.log(propietarios);
        console.log(usuarios);*/



      })).subscribe(( res: any ) => {
        if (res != null) {
          console.log(res);
        }
      });
    })).subscribe(( res: any ) => {
      let id = parseInt(res.AUTO_INCREMENT);
      this.nextId.next(id);
      //console.log(res);

    });

  }

  addUsers(users: any, userstipo: string) {

    switch (userstipo) {
      case 'users':
        this.users = users;
        //console.log(users);
        break;
      case 'propietarios':
        this.propietarios = users;
        //console.log(users);
        break;
      case 'agregados':
        this.agregados = users;
        //console.log(users);
        break;
    }

  }


}

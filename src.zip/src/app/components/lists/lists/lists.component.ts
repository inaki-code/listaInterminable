import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CallComponentsService } from '../../../services/call-components/call-components.service';

declare var $:any;

@Component({
  selector: 'lists',
  templateUrl: './lists.component.html',
  styleUrls: ['./lists.component.css']
})
export class ListsComponent implements OnInit {

  constructor( private call: CallComponentsService) { }

  ngOnInit(): void {

    $('#exampleModal').on('hidden.bs.modal', () => {
      this.call.callListsModal.next(false);
    });

    this.listsModalOpen();

  }

  listsModalOpen() {
    $('#exampleModal').modal('show');
  }

  listsModalClose() {
    $('#exampleModal').modal('hide');
  }

  cListModalOpen() {

    this.listsModalClose();
    this.call.callCListModal.emit(true);

  }

  newListModalOpen(tipo: string) {

    this.listsModalClose();
    this.call.newListModaltype.next(tipo);
    this.call.callNewListModal.emit(true);

  }


}

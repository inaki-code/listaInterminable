import { Component, OnInit } from '@angular/core';
import { BehaviorSubject, finalize } from 'rxjs';
import { User } from '../../../interfaces/user';
import { List } from '../../../interfaces/list';
import { ApiService } from '../../../services/api/api.service';
import { CallComponentsService } from '../../../services/call-components/call-components.service';
import { SessionService } from '../../../services/session/session.service';
import { ListService } from '../../../services/list/list.service';
import { IncluirService } from '../../../services/inlcluir/incluir.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { debounceTime } from 'rxjs/operators';
import { LikesService } from '../../../services/likes/likes.service';
import { LocalLikes } from '../../../interfaces/local-likes';
import { Likes } from '../../../interfaces/likes';
import { Incluir } from '../../../interfaces/incluir';
import { Listpeticion } from '../../../interfaces/listpeticion';
import { ListpeticionesService } from '../../../services/listpeticiones/listpeticiones.service';
import { PertenecerService } from '../../../services/pertenecer/pertenecer.service';
import { Pertenecer } from '../../../interfaces/pertenecer';

// JQUERY
declare var $:any;

@Component({
  selector: 'lists-container',
  templateUrl: './lists-container.component.html',
  styleUrls: ['./lists-container.component.css']
})
export class ListsContainerComponent implements OnInit {

  // Listas de la BDD
  public lists: BehaviorSubject<List[]> = new BehaviorSubject<List[]>(Array());
  // Listas visibles
  public visibleLists: BehaviorSubject<List[]> = new BehaviorSubject<List[]>(Array());
  // id usuario logeado
  public id: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  public status: BehaviorSubject<string> = new BehaviorSubject<string>('');
  public banned: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  // Componentes modales
  public seeLists: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);
  public seeListsModal: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public seeIListModal: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public seeCListModal: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public seeAListModal: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public seeTListModal: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public seeNewListModal: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public seeList: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  // Formulario de búsqueda
  public searchForm: FormGroup;
  public listsFilter: BehaviorSubject<string> = new BehaviorSubject('');
  // Likes
  public list_like: BehaviorSubject<LocalLikes[]> = new BehaviorSubject<LocalLikes[]>( new Array() );
  public idListsUserLikes: BehaviorSubject<number[]> = new BehaviorSubject<number[]>( new Array() );


  constructor(private api: ApiService, private call: CallComponentsService, public session: SessionService, private list: ListService, private incluir: IncluirService, private fb: FormBuilder, public likes: LikesService, private listpeticion: ListpeticionesService, private pertenecer: PertenecerService) {
    this.searchForm = this.fb.group({
      search: []
    });

    this.likes.list_like.subscribe(res => {
      this.list_like.next(res);
      //console.log(res);
    });

    this.likes.idListsUserLikes.subscribe(res => {

      if (res.length > 0) {
        this.idListsUserLikes.next(res);
        //console.log(res);
      }

    });

  }

  ngOnInit(): void {

    this.searchForm.controls['search'].valueChanges
    .pipe(
      debounceTime(500)
    )
    .subscribe(res => this.listsFilter.next(res));

    this.session.id.subscribe(res => {
      this.id.next(res);
    });

    this.status.subscribe(res => {
      console.log(res);
    });

    this.session.status.subscribe(res => {
      this.status.next(res);

      switch (res) {
        case 'admin':
          this.list.lists.subscribe(res => {
            this.visibleLists.next(res);
            console.log(res);
          });
          break;
        case 'user':
          this.list.visibleLists.subscribe(res => {
            this.visibleLists.next(res);
            console.log(res);
          });
          break;
      }
    });

    this.session.banned.subscribe(res => {
      this.banned.next(res);
    })

    // Estamos pendientes de las Listas
    this.call.callLists.subscribe(data => {
      this.seeLists.next(data);
    });
    // Estamos pendientes de la modal de las Listas
    this.call.callListsModal.subscribe(data => {
      this.seeListsModal.next(data);
    });
    // Estamos pendientes de ClistModal
    this.call.callCListModal.subscribe(data => {
      this.seeCListModal.next(data);
    });
    this.call.callNewListModal.subscribe(data => {
      this.seeNewListModal.next(data);
    })
    // Estamos pendientes de La lista clickable
    this.call.callList.subscribe(data => {
      this.seeList.next(data);

      if (data > -1) {
        for (let l of this.lists.value) {
          if (l.id == data) {
            this.call.List.next(l);

            break;
          }
        }
      }

    });

  }

  borrarLista(list: List) {

    this.call.List.next(list);

    alert('se borrará la lista');

    let incluir: Incluir[] = this.incluir.incluir.value.filter(incl => incl.id_lista == list.id);
    let listpeticiones: Listpeticion[] = this.listpeticion.listBansPeticion.value.filter(peticion => peticion.id_list == list.id);
    let likes: Likes[] = this.likes.likes.value.filter(like => like.id_list == list.id);
    let pertenecer: Pertenecer[] = this.pertenecer.pertenecer.value.filter(pertenecer => pertenecer.id_list == list.id);
    //console.log(pertenecer);

    /*this.api.removeLike(-1, list.id).subscribe(res => {
      console.log(res);
    });*/

    for (let i of incluir) {
      this.api.removeIncluir(i.id_lista, i.id_producto).subscribe(res => {
        console.log(res);
      });
    }

    setTimeout(() => {}, 1000 );

    for (let x of likes) {
      this.api.removeLike(x.id_user, x.id_list).subscribe(res => {
        console.log(res);
      });
    }

    setTimeout(() => {}, 1000 );

    for (let l of listpeticiones) {
      this.api.removeListPeticion(l.id).subscribe(res => {
        console.log(res);
      });
    }

    setTimeout(() => {}, 1000 );

    for (let p of pertenecer) {
      this.api.removePertenecer(p.id).subscribe(res => {
        console.log(res);
      });
    }

    setTimeout(() => {}, 1000 );

    this.api.removeList(list.id).pipe(finalize(() => {
      // Borramos la lista de las listas visibles del usuario
      let listas: List[] = this.list.visibleLists.value;

      for (let i = 0; i < listas.length; i++) {
        if (listas[i].id == list.id) {
          listas.splice(i, 1);
          break;
        }
      }

      this.list.visibleLists.next(listas);

    })).subscribe( res => {
      console.log(res);
    });



  }

  callListsModal() {
    this.call.callListsModal.next(true);
  }


  getList(id: number) {

    this.call.callLists.next(false);
    this.call.callList.next(id);

    for (let l of this.visibleLists.value) {
      if (l.id == id) {
        this.call.List.next(l);
        break;
      }
    }

  }

  like(list: List, iduser: number, event: any) {

    event.stopPropagation();

    this.api.createLike(iduser, list.id).subscribe(res => {
      if (res != null) {
        console.log(res);
      }
    });

    let exists: boolean = false;

    for ( let l of this.list_like.value ) {
      if ( l.id_list == list.id ) {

        l.likes.push(parseInt(this.id.value.toString()));
        exists = true;

        break;

      }
    }

    if ( !exists ) {
      let listLike: LocalLikes = {id_list: list.id, likes: [parseInt(this.id.value.toString())]};
      let newlistLike: LocalLikes[] = this.list_like.value;
      newlistLike.push(listLike);
      this.list_like.next(newlistLike);
    }

    //this.list.lists.next(lists);

    let idListsUserLikes: number[] = this.likes.idListsUserLikes.value;
    idListsUserLikes.push(list.id);
    this.likes.idListsUserLikes.next(idListsUserLikes);

    console.log(this.list_like.value);

  }

  quitarLike(list: List, iduser: number, event: any) {

    event.stopPropagation();

    this.api.removeLike(iduser, list.id).subscribe(res => {
      if (res != null) {
        console.log(res);
      }
    });

    for ( let x = 0; x < this.list_like.value.length; x++ ) {
      if ( list.id == this.list_like.value[x].id_list ) {

        if (this.list_like.value[x].likes.length == 1) {
          this.list_like.value.splice(x, 1);
          //console.log(this.list_like.value);
        }
        else {
          let index: number = this.list_like.value[x].likes.indexOf( parseInt(this.id.value.toString()) );
          //console.log(index);
          let newListLikes: LocalLikes[] = this.list_like.value;
          newListLikes[x].likes.splice(index, 1);
          this.list_like.next(newListLikes);

          /*console.log(this.list_like.value[x].likes);
          console.log(this.id.value);
          console.log(this.list_like.value);*/
        }

        break;
      }
    }

    let idListsUserLikes: number[] = this.likes.idListsUserLikes.value;

    let index: number = idListsUserLikes.indexOf(list.id);
    idListsUserLikes.splice(index, 1);

    this.likes.idListsUserLikes.next(idListsUserLikes);

  }

  getListLikes(id_list: number): number {

    for (let l of this.list_like.value) {

      if (l.id_list == id_list) {
        return l.likes.length;
      }

    }

    return 0;


  }

  login() {
    this.seeLists.next(true);
  }

  logout() {
    this.seeLists.next(false);
  }




}

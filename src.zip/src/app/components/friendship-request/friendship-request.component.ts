import { Component, OnInit } from '@angular/core';
import { AgregarService } from '../../services/agregar/agregar.service';
import { User } from '../../interfaces/user';
import { SessionService } from '../../services/session/session.service';
import { ApiService } from '../../services/api/api.service';
import { BehaviorSubject, finalize } from 'rxjs';
import { Agregar } from '../../interfaces/agregar';

// JQUERY
declare var $:any;

@Component({
  selector: 'friendship-request',
  templateUrl: './friendship-request.component.html',
  styleUrls: ['./friendship-request.component.css']
})
export class FriendshipRequestComponent implements OnInit {

  id: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  peticiones: number[] = [];
  amigos: number[] = [];
  peticionesHechas: number[] = [];
  userPressPeticiones: boolean = true;
  userPressAmigos: boolean = false;
  userPressPendientes: boolean = false;
  usersPeticion: BehaviorSubject<User[]> = new BehaviorSubject(Array());
  usersAmigos: BehaviorSubject<User[]> = new BehaviorSubject(Array());
  usersPendientes: BehaviorSubject<User[]> = new BehaviorSubject(Array());


  constructor(private agregar: AgregarService, private session: SessionService, private api: ApiService) {

  }

  ngOnInit(): void {

    // Para que el dropdown se comporte como una modal
    $('.dropdown-menu').click(function(event: any){
      event.stopPropagation();
    });

    // Obtener las peticiones que nos han hecho otros usuarios
    this.agregar.peticiones.subscribe(res => {

      this.peticiones = res;

      let users: User[] = [];

      for (let u of this.session.users.value) {
        if ( this.peticiones.includes(u.id) ) {
          users.push(u);
        }
      }

      this.usersPeticion.next(users);

    });

    // Obtener los usuarios que ya tenemos agregados
    this.agregar.amigos.subscribe(res => {
      this.amigos = res;

      let users: User[] = [];

      for (let u of this.session.users.value) {
        if ( this.amigos.includes(u.id) ) {
          users.push(u);
        }
      }

      this.usersAmigos.next(users);
    });

    // Obtener las peticiones que hemos hecho y que no nos han aceptado todavía
    this.agregar.peticionesHechas.subscribe(res => {
      this.peticionesHechas = res;

      let users: User[] = [];

      for (let u of this.session.users.value) {
        if ( this.peticionesHechas.includes(u.id) ) {
          users.push(u);
        }
      }

      this.usersPendientes.next(users);
    });

    this.session.id.subscribe(res => {
      this.id.next(res);
    });



  }

  getPeticiones() {
    this.userPressPeticiones = true;
    this.userPressAmigos = false;
    this.userPressPendientes = false;
  }

  getAmigos() {
    this.userPressPeticiones = false;
    this.userPressAmigos = true;
    this.userPressPendientes = false;
  }

  getPendientes() {
    this.userPressPeticiones = false;
    this.userPressAmigos = false;
    this.userPressPendientes = true;
  }

  rechazarPeticion(id_userRechazado: number) {
    this.api.removeAgregar(id_userRechazado, this.id.value).pipe(finalize( () => {

      let users: User[] = this.usersPeticion.value;
      // Rechazar la petición que hicimos a un usuario
      for (let i = 0; i < users.length; i++) {
        if (users[i].id == id_userRechazado) {
          users.splice(i, 1);

          break;
        }
      }

      this.usersPeticion.next(users);

    })).subscribe();
  }

  eliminarPeticion(id_user: number) {
    this.api.removeAgregar(this.id.value, id_user).pipe(finalize( () => {

      let users: User[] = this.usersPendientes.value;
      // Eliminar la peticion que hicimos a un usuario
      for (let i = 0; i < users.length; i++) {
        if (users[i].id == id_user) {
          users.splice(i, 1);

          break;
        }
      }

      this.usersPendientes.next(users);

      // Servicio de usuarios, sacamos al usuario de usuarios no agregables
      let noAgregables: number[] = this.agregar.usersNoAgregables.value;
      for (let i = 0; i < noAgregables.length; i++) {
        if (noAgregables[i] == id_user) {
          noAgregables.splice(i, 1);

          break;
        }
      }

      this.agregar.usersNoAgregables.next(noAgregables);

    })).subscribe();
  }

  aceptarPeticion(id_user: number) {

    let list: Agregar = {
      'id_user': id_user,
      'id_useragregado': this.id.value,
      'agregado': 1
    }

    this.api.modifyAgregar(id_user, this.id.value, list).pipe(finalize( () => {

      let amigos: User[] = this.usersAmigos.value;
      // Añadir usuario a la lista de amigos
      for (let u of this.session.users.value) {
        if (u.id == id_user) {
          amigos.push(u);

          break;
        }
      }

      this.usersAmigos.next(amigos);

      let peticiones: User[] = this.usersPeticion.value;
      // Eliminar al usuario de peticiones
      for (let i = 0; i < peticiones.length; i++) {
        if (peticiones[i].id == id_user) {
          peticiones.splice(i, 1);

          break;
        }
      }

      this.usersPeticion.next(peticiones);

    })).subscribe();
  }

  eliminarAmigo(id_amigo: number) {

    this.api.removeAgregar(id_amigo, this.id.value).pipe(finalize( () => {

      let users: User[] = this.usersAmigos.value;
      // Eliminar el amigo cuando el usuario registrado aceptó la petición
      for (let i = 0; i < users.length; i++) {
        if (users[i].id == id_amigo) {
          users.splice(i, 1);

          break;
        }
      }

      this.usersAmigos.next(users);

    })).subscribe();

    this.api.removeAgregar(this.id.value, id_amigo).pipe(finalize( () => {

      let users: User[] = this.usersAmigos.value;
      // Eliminar el amigo cuando el usuario registrado envió la petición y fue aceptada
      for (let i = 0; i < users.length; i++) {
        if (users[i].id == id_amigo) {
          users.splice(i, 1);

          break;
        }
      }

      this.usersAmigos.next(users);

    })).subscribe();



  }



}

import { Component, OnInit, AfterViewChecked } from '@angular/core';
import { CallComponentsService } from '../../services/call-components/call-components.service';
import { BehaviorSubject } from 'rxjs';
import { ApiService } from '../../services/api/api.service';
import { Banpeticion } from '../../interfaces/banpeticion';
import { User } from '../../interfaces/user';
import { SessionService } from '../../services/session/session.service';
import { BanpeticionService } from '../../services/banpeticion/banpeticion.service';

// JQUERY
declare var $:any;

@Component({
  selector: 'ban-peticion-container',
  templateUrl: './ban-peticion-container.component.html',
  styleUrls: ['./ban-peticion-container.component.css']
})
export class BanPeticionContainerComponent implements OnInit, AfterViewChecked {

  public seeBanContainer: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public banPeticiones: BehaviorSubject<Banpeticion[]> = new BehaviorSubject<Banpeticion[]>( new Array() );
  public usuarios: BehaviorSubject<User[]> = new BehaviorSubject<User[]>( new Array() );
  public usuariosBaneados: BehaviorSubject<User[]> = new BehaviorSubject<User[]>( new Array() );

  constructor(private call: CallComponentsService, private api: ApiService, private session: SessionService, private banpeticion: BanpeticionService) {

  }

  ngOnInit(): void {
    this.call.callBanContainer.subscribe(res => {
      this.seeBanContainer.next(res);
    });

    this.banpeticion.userBanPeticion.subscribe(res => {
      this.banPeticiones.next(res);
      console.log(res);
    });

    this.banpeticion.usuarios.subscribe(res => {
      this.usuarios.next(res);
    });

    this.banpeticion.usuariosBaneados.subscribe(res => {
      this.usuariosBaneados.next(res);
    });

  }


  ngAfterViewChecked(): void {
    $('[data-toggle="tooltip"]').tooltip();
  }

  goToProfile(id: number) {
    $('[data-toggle="tooltip"]').tooltip('hide');

    this.call.goToProfile.next(id);
  }

  eliminarPeticion(id: number) {
    $('[data-toggle="tooltip"]').tooltip('hide');
    this.api.removeBanPeticion(id, 1).subscribe(res => {

      if (res == null) {

        let banpeticiones: Banpeticion[] = new Array();

        for (let b of this.banPeticiones.value) {
          if (b.id != id) {
            banpeticiones.push(b);
          }
        }

        this.banpeticion.userBanPeticion.next(banpeticiones);

      }

    });
  }

  banearUsuario(id_userban: number) {
    $('[data-toggle="tooltip"]').tooltip('hide');

    let totalUsers: User[] = [];
    let baneados: User[] = this.usuariosBaneados.value;

    let user: User = {
      id: -1,
      email: '',
      status: '',
      loggedin: 0,
      name: '',
      foto: '',
      token: '',
      ban: 0
    };

    for (let u of this.session.users.value) {

      if (u.id == id_userban) {
        user = u;
        user.ban = 1;
      }
      else {
        totalUsers.push(u);
      }

    }

    console.log(user);

    totalUsers.push(user);
    baneados.push(user);

    this.api.modifyUser(id_userban, user, 0).subscribe(res => {
      console.log(res);
    });

    this.session.users.next(totalUsers);
    this.usuariosBaneados.next(baneados);
    //console.log(totalUsers);
  }

  disban(id: number) {

    let deleteIndex: number = -1;
    let baneados: User[] = this.usuariosBaneados.value;
    let user: User = {
      id: -1,
      email: '',
      status: '',
      loggedin: 0,
      name: '',
      foto: '',
      token: '',
      ban: 1
    };

    for (let u of this.usuariosBaneados.value) {

      deleteIndex++;

      if (u.id == id) {
        user = u;
        user.ban = 0;
        break;
      }

    }

    baneados.splice(deleteIndex, 1);
    this.banpeticion.usuariosBaneados.next(baneados);

    this.api.modifyUser(id, user, 0).subscribe(res => {
      console.log(res);
    });


  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BanPeticionContainerComponent } from './ban-peticion-container.component';

describe('BanPeticionContainerComponent', () => {
  let component: BanPeticionContainerComponent;
  let fixture: ComponentFixture<BanPeticionContainerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BanPeticionContainerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BanPeticionContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

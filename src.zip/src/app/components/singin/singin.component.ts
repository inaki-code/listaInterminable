import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from '../../services/api/api.service';
import { SessionService } from '../../services/session/session.service';
import { BehaviorSubject } from 'rxjs';
import { User } from '../../interfaces/user';
import CryptoJS from 'crypto-js';
import { Router } from '@angular/router';

//JQUERY
declare var $:any;

@Component({
  selector: 'singin',
  templateUrl: './singin.component.html',
  styleUrls: ['./singin.component.css']
})
export class SinginComponent implements OnInit {

  // Usuarios registrados
  public users: BehaviorSubject<User[]> = new BehaviorSubject<User[]>([]);
  // Formulario de registro
  public singinForm: FormGroup;
  // Cerrar modal de login
  @Output() singinModal = new EventEmitter<boolean>(true);

  constructor ( private fb: FormBuilder, private api: ApiService, private session: SessionService, private router: Router) {
    this.singinForm = this.fb.group({
      email: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(75), Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(25)]]
    });
  }

  ngOnInit(): void {

    this.getUsers();

    // Avisar al componente navbar cuando se cierre la modal del login
    $('#exampleModal').on('hidden.bs.modal', () => {
      this.singinModal.emit(false);
    });
    // Abrir modal
    this.singinModalOpen();

  }

  getUsers() {
    // GET usuarios existentes
    this.api.getUsers().subscribe(( res: any ) => {

      // Para poder utilizar la funcion login se sessionService
      this.session.users.next(res.users);
      // Para poder crear el usuario en la BDD
      this.users.next(res.users);

    });
  }

  singinModalOpen() {
    $('#exampleModal').modal('show');

    this.getUsers();
  }

  singinModalClose() {
    $('#exampleModal').modal('hide');
  }

  singinSubmit() {

    let email: string = this.singinForm.controls['email'].value;
    let password: string = this.singinForm.controls['password'].value;

    let userExists: boolean = false;
    // Contraseña que introduce el usuario
    let passwordHash: string = CryptoJS.SHA1(password).toString();

    // Comprobar el usuario y la contraseña
    for (let u of this.users.value) {

      console.log(u);
      if (u.email == email && u.password == passwordHash) {
        userExists = true;
        break;
      }

    }

    if (userExists) {
      this.session.login(email);
      this.singinModalClose();
    }
    else {
      alert('No existe la pareja usuario / contraseña');
    }


  }



}


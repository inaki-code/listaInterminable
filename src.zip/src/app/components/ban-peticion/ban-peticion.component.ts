import { Component, Input } from '@angular/core';
import { CallComponentsService } from '../../services/call-components/call-components.service';
import { BehaviorSubject, finalize } from 'rxjs';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from '../../services/api/api.service';
import { SessionService } from '../../services/session/session.service';
import { Banpeticion } from '../../interfaces/banpeticion';
import { BanpeticionService } from '../../services/banpeticion/banpeticion.service';
import { Listpeticion } from '../../interfaces/listpeticion';
import { ListpeticionesService } from '../../services/listpeticiones/listpeticiones.service';

// JQUERY
declare var $:any;

@Component({
  selector: 'ban-peticion',
  templateUrl: './ban-peticion.component.html',
  styleUrls: ['./ban-peticion.component.css']
})
export class BanPeticionComponent {

  @Input()
  formtype: string = ''
  public id: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  public idUserBaned: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  public emailUserBaned: BehaviorSubject<string> = new BehaviorSubject<string>('');
  public listName: BehaviorSubject<string> = new BehaviorSubject<string>('');
  // Formulario de registro
  public banForm: FormGroup;
  public nextId: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  public listBanNextId: BehaviorSubject<number> = new BehaviorSubject<number>(-1);

  constructor(private call: CallComponentsService, private fb: FormBuilder, private api: ApiService, private session: SessionService, private banpeticion: BanpeticionService, private listpeticion: ListpeticionesService) {
    this.banForm = this.fb.group({
      mensaje: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]],
    });
  }

  ngOnInit(): void {
    // Avisar al servicio que cerramos la modal
    $('#Modal').on('hidden.bs.modal', () => {
      this.call.callBanModal.emit(false);
    });

    this.call.id.subscribe(res => {
      this.id.next(res);
    });

    this.call.callUserProfile.subscribe(res => {
      this.idUserBaned.next(res.id);
      this.emailUserBaned.next(res.email);
    });

    this.call.List.subscribe(res => {
      this.listName.next(res.nombre);
    });

    this.banModalOpen();
  }

  banModalOpen() {
    $('#Modal').modal('show');
  }

  banModalClose() {
    $('#Modal').modal('hide');
  }

  submitBanPeticion() {

    this.api.BanNextId().pipe(finalize( () => {

      let banPeticion: Banpeticion = {id: -1, mensaje: '', id_userban: -1, id_usuario: -1};
      banPeticion.id = this.nextId.value;
      banPeticion.mensaje = this.banForm.controls['mensaje'].value;
      banPeticion.id_userban = this.call.callProfile.value;
      banPeticion.id_usuario = this.session.id.value;

      let banPeticiones: Banpeticion[] = this.banpeticion.userBanPeticion.value;
      banPeticiones.push(banPeticion);

      this.banpeticion.userBanPeticion.next(banPeticiones);

      this.api.createBanpeticion(this.banForm.controls['mensaje'].value , this.call.callProfile.value, this.session.id.value).subscribe(res => {
        console.log(res);
      });

      this.banModalClose();

    })).subscribe(( res: any ) => {

      this.nextId.next(res.auto_increment);

    });


  }

  submitListPeticion() {

    this.api.BanListNextId().pipe(finalize( () => {

      let listPeticion: Listpeticion = {id: -1, id_user: -1, id_list: -1, mensaje: ''};
      listPeticion.id = this.listBanNextId.value;
      listPeticion.mensaje = this.banForm.controls['mensaje'].value;
      listPeticion.id_user = this.session.id.value;
      listPeticion.id_list = this.call.List.value.id;

      let listPeticiones: Listpeticion[] = this.listpeticion.listBansPeticion.value;
      listPeticiones.push(listPeticion);

      this.listpeticion.listBansPeticion.next(listPeticiones);

      this.api.createListpeticion(this.banForm.controls['mensaje'].value , this.session.id.value, this.call.List.value.id).subscribe(res => {
        console.log(res);
      });

      this.banModalClose();

    })).subscribe(( res: any) => {

      this.listBanNextId.next(res.auto_increment);

    });

  }

}

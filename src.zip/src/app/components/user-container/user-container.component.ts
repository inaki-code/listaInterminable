import { Component } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CallComponentsService } from '../../services/call-components/call-components.service';
import { User } from '../../interfaces/user';
import { SessionService } from '../../services/session/session.service';
import { ApiService } from '../../services/api/api.service';
import { ProductService } from '../../services/product/product.service';
import { Product } from '../../interfaces/product';
import { ListService } from '../../services/list/list.service';
import { List } from '../../interfaces/list';
import { Likes } from '../../interfaces/likes';
import { LikesService } from '../../services/likes/likes.service';
import { PertenecerService } from '../../services/pertenecer/pertenecer.service';
import { Pertenecer } from '../../interfaces/pertenecer';
import { ListpeticionesService } from '../../services/listpeticiones/listpeticiones.service';
import { Listpeticion } from '../../interfaces/listpeticion';
import { ComprarService } from '../../services/comprar/comprar.service';
import Swal from 'sweetalert2';
import { FormBuilder, FormGroup } from '@angular/forms';
import { debounceTime } from 'rxjs/operators';

@Component({
  selector: 'user-container',
  templateUrl: './user-container.component.html',
  styleUrls: ['./user-container.component.css']
})
export class UserContainerComponent {

  public seeBanContainer: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public users: BehaviorSubject<User[]> = new BehaviorSubject( new Array() );
  // Formulario de búsqueda
  public searchForm: FormGroup;
  public usersFilter: BehaviorSubject<string> = new BehaviorSubject('');

  constructor(private call: CallComponentsService, private session: SessionService, private api: ApiService, private products: ProductService, private list: ListService, private like: LikesService, private pertenecer: PertenecerService, private listPeticion: ListpeticionesService, private fb: FormBuilder) {
    this.searchForm = this.fb.group({
      search: []
    });
  }

  ngOnInit(): void {
    this.searchForm.controls['search'].valueChanges
    .pipe(
      debounceTime(500)
    )
    .subscribe(res => this.usersFilter.next(res));

    this.call.callUserContainer.subscribe(res => {
      this.seeBanContainer.next(res);
    });

    this.session.users.subscribe(res => {
      this.users.next(res);
      //console.log(res);
    });
  }

  borrarUser(id: number, event: any) {
    event.stopPropagation();

    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: "btn btn-success",
        cancelButton: "btn btn-danger"
      },
      buttonsStyling: false
    });
    swalWithBootstrapButtons.fire({
      title: "Estás segur@?",
      text: "No podrás recuperar la información del usuario!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Sí, bórralo!",
      cancelButtonText: "No, cancelar!",
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {

        let users = this.users.value;

        for (let i = 0; i < users.length; i++) {
          if (users[i].id == id) {
            users.splice(i, 1);
            break;
          }
        }

        this.session.users.next(users);

        let userProducts: Product[] = this.products.products.value.filter(prod => prod.id_usuario == id);
        let userLists: List[] = this.list.lists.value.filter(list => list.id_usuario == id);
        let userLikes: Likes[] = this.like.likes.value.filter(like => like.id_user == id);
        let listasPertenecer: Pertenecer[] = this.pertenecer.pertenecer.value.filter(pertenecer => pertenecer.id_user == id);
        let listPeticiones: Listpeticion[] = this.listPeticion.listBansPeticion.value.filter(listP => listP.id_user == id);

        setTimeout(() => {
          this.api.removeComprar(id).subscribe(res => {
            if (res != null) {
              console.log(res);
            }
          });
        }, 500);

        setTimeout(() => {
          this.api.removeAgregar(id, -1).subscribe(res => {
            if (res != null) {
              console.log(res);
            }
          });
        },500);

        setTimeout(() => {
          this.api.removeBanPeticion(id, 0).subscribe(res => {
            if (res != null) {
              console.log(res);
            }
          });
        },500);

        setTimeout(() => {
          // Peticiones de listas baneadas que ha mandado el usuario
          for (let l of listPeticiones ) {
            this.api.removeListPeticion(l.id, 1).subscribe(res => {
              if (res != null) {
                console.log(res);
              }
            });
          }
        },500);

        setTimeout(() => {
          // Peticiones de listas baneadas que le han baneado al usuario
          for (let l of userLists) {
            this.api.removeListPeticion(l.id, 0).subscribe(res => {
              if (res != null) {
                console.log(res);
              }
            });
          }
        },500);

        setTimeout(() => {
          for (let p of userProducts) {
            this.api.removeIncluir(-1, p.id).subscribe(res => {
              if (res != null) {
                console.log(res);
              }
            });
          }
        }, 500);

        setTimeout(() => {
          for (let l of userLists) {
            this.api.removeLike(-1, l.id).subscribe(res => {
              if (res != null) {
                console.log(res);
              }
            });
          }
        }, 500);

        setTimeout(() => {
          for (let p of listasPertenecer) {
            this.api.removePertenecer(p.id, 1).subscribe(res => {
              if (res != null) {
                console.log(res);
              }
            });
          }
        }, 500);

        setTimeout(() => {
          for (let l of userLists) {
            this.api.removePertenecer(l.id, 0).subscribe(res => {
              if (res != null) {
                console.log(res);
              }
            });
          }
        }, 500);

        setTimeout(() => {
          for (let p of userProducts) {
            this.api.removeProduct(p.id).subscribe(res => {
              if (res != null) {
                console.log(res);
              }
            });
          }
        }, 500);

        setTimeout(() => {
          this.api.RemoveUser(id).subscribe(res => {
            if (res != null) {
              console.log(res);
            }
          });
        }, 500);

        setTimeout(() => {
          for (let l of userLists) {
            this.api.removeList(l.id).subscribe(res => {
              if (res != null) {
                console.log(res);
              }
            });
          }
        }, 500);

        swalWithBootstrapButtons.fire({
          title: "Borrado!",
          text: "El usuario ha sido borrado.",
          icon: "success"
        });
      } else if (
        /* Read more about handling dismissals below */
        result.dismiss === Swal.DismissReason.cancel
      ) {
        swalWithBootstrapButtons.fire({
          title: "Cancelled",
          text: "El usuario NO ha sido borrado",
          icon: "error"
        });
      }
    });



  }

  goToProfile(id: number) {
    this.call.goToProfile.next(id);
  }

  callSingUp() {
    this.call.callSingUp.emit(true);
  }



}

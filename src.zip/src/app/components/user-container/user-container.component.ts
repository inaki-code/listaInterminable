import { Component } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CallComponentsService } from '../../services/call-components/call-components.service';
import { User } from '../../interfaces/user';
import { SessionService } from '../../services/session/session.service';
import { ApiService } from '../../services/api/api.service';
import { ProductService } from '../../services/product/product.service';
import { Product } from '../../interfaces/product';
import { ListService } from '../../services/list/list.service';
import { List } from '../../interfaces/list';

@Component({
  selector: 'user-container',
  templateUrl: './user-container.component.html',
  styleUrls: ['./user-container.component.css']
})
export class UserContainerComponent {

  public seeBanContainer: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public users: BehaviorSubject<User[]> = new BehaviorSubject( new Array() );

  constructor(private call: CallComponentsService, private session: SessionService, private api: ApiService, private products: ProductService, private list: ListService) {

  }

  ngOnInit(): void {
    this.call.callUserContainer.subscribe(res => {
      this.seeBanContainer.next(res);
    });

    this.session.users.subscribe(res => {
      this.users.next(res);
      //console.log(res);
    });
  }

  borrarUser(id: number, event: any) {
    event.stopPropagation();

    let userProducts: Product[] = this.products.products.value.filter(prod => prod.id_usuario == id);
    let userLists: List[] = this.list.lists.value.filter(list => list.id_usuario == id);

    this.api.removeAgregar(id, -1).subscribe(res => {
      if (res != null) {
        console.log(res);
      }
    });

    this.api.removeBanPeticion(id, 0).subscribe(res => {
      console.log(res);
    });

    for (let p of userProducts) {
      this.api.removeIncluir(-1, p.id).subscribe(res => {
        console.log(res);
      });
    }

    for (let p of userProducts) {
      this.api.removeProduct(p.id).subscribe(res => {
        console.log(res);
      });
    }

    for (let l of userLists) {
      this.api.removeList(l.id).subscribe(res => {
        console.log(res);
      });
    }



    this.api.RemoveUser(id).subscribe(res => {
      if (res != null) {
        console.log(res);
      }
    });
  }

  goToProfile(id: number) {
    this.call.goToProfile.next(id);
  }



}

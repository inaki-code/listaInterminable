import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../../interfaces/user';
import { ApiService } from '../../services/api/api.service';
import { SessionService } from '../../services/session/session.service';
import { BehaviorSubject } from 'rxjs';
import Swal from 'sweetalert2';

// JQUERY
declare var $:any;

@Component({
  selector: 'singup',
  templateUrl: './singup.component.html',
  styleUrls: ['./singup.component.css']
})
export class SingupComponent implements OnInit {

  // Usuarios registrados
  public users: User[] = [];
  // Formulario de registro
  public singupForm: FormGroup;
  // URL de la foto
  url: string = '';
  //
  public status: BehaviorSubject<string> = new BehaviorSubject<string>('');
  // Cerrar correctamente modal de sing up
  @Output()
  singupModal = new EventEmitter<boolean>(true);

  constructor ( private fb: FormBuilder, private router: Router, private api: ApiService, private session: SessionService) {
    this.singupForm = this.fb.group({
      email: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(30), Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(25)]],
      repeatPassword: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(25)]],
      completeName: ['', [Validators.minLength(2), Validators.maxLength(40)]],
      image: [''],
      status: ['']
    });

  }

  ngOnInit(): void {
    // Avisar al componente navbar cuando se cierre la modal de sing up
    $('#exampleModal').on('hidden.bs.modal', () => {
      this.singupModal.emit(false);
    });

    // GET usuarios existentes
    this.api.getUsers().subscribe(( res: any ) => {

      this.users = res.users;

    });

    this.singupModalOpen();

    this.singupForm.controls['status'].setValue('user');

    this.session.status.subscribe(res => {
      this.status.next(res);
    });
  }

  singupModalOpen() {
    $('#exampleModal').modal('show');
  }

  singupModalClose() {
    $('#exampleModal').modal('hide');
  }

  singupSubmit() {
    // Recoger valores del formulario
    //console.log(this.singupForm);
    let email: string = this.singupForm.controls['email'].value;
    let password: string = this.singupForm.controls['password'].value;
    let repeatPassword: string = this.singupForm.controls['repeatPassword'].value;
    let completeName: string = this.singupForm.controls['completeName'].value;
    let status: string = this.singupForm.controls['status'].value;
    let foto: any = this.url;

    // Informar al usuario si el registro ha sido satisfactorio
    if (password == repeatPassword) {

      let userExists: boolean = false;

      // Saber si el usuario existe
      for (let u of this.users) {

        if (u.email == email) {
          userExists = true;
          break;
        }

      }
      // Crear usuario o no
      if ( userExists ) {
        let msj = 'El email ' + email + ' ya ha sido registrado, por favor, introduzca otro';
        this.errorModal(msj);
      }
      else {
        // Crear usuario
        this.api.createUser(email, password, repeatPassword, foto, status, completeName).subscribe(( res: any ) => {
          if (res != null) {
            console.log(res);
          }
        });

        let msj = 'El usuario ' + email + ' ha sido registrado correctamente';
        Swal.fire('Buen trabajo!', msj, 'success');

        this.errorModal(msj);
        this.singupModalClose();


      }

    }
    else {
      this.errorModal('Las contraseñas no coinciden');
    }

}

  selectFile(event: any) {
    if (event.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event:any) => {
        this.url = event.target.result;
        //console.log(this.url);
      }
    }
  }

  errorModal(mensaje: string) {
    Swal.fire('Error!', mensaje, 'error');
  }

}






import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators, } from '@angular/forms';
import { ApiService } from '../../../services/api/api.service';
import { BehaviorSubject, finalize} from 'rxjs';
import { User } from '../../../interfaces/user';
import { CallComponentsService } from '../../../services/call-components/call-components.service';
import { SessionService } from '../../../services/session/session.service';
import { ProductService } from '../../../services/product/product.service';
import { Product } from '../../../interfaces/product';

// JQUERY
declare var $:any;

@Component({
  selector: 'product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  // Usuarios registrados
  //public users: User[] = [];
  // Formulario para introducir productos
  public productForm: FormGroup;
  // URL de la foto
  url: string = '';
  id: BehaviorSubject<number> = new BehaviorSubject(-1);

  constructor ( private fb: FormBuilder, private api: ApiService, private call: CallComponentsService, private session: SessionService, private product: ProductService) {
    this.productForm = this.fb.group({
      nombre: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25)]],
      precio: ['', [Validators.maxLength(10), Validators.maxLength(4)]],
      pesoNeto: ['', [Validators.maxLength(4)]],
      image: ['']
    });

  }

  ngOnInit(): void {

    // GET usuarios existentes
    /*this.api.getUsers().subscribe(( res: any ) => {
      this.users = res.users;
    });*/

    this.session.id.subscribe( res => {
      this.id.next(res);
    })

    // Avisar al componente navbar cuando se cierre la modal de productos
    $('#exampleModal').on('hidden.bs.modal', () => {
      this.call.callProductsModal.emit(false);
    });

    this.productModalOpen();

  }

  productModalOpen() {
    $('#exampleModal').modal('show');
  }

  productModalClose() {
    $('#exampleModal').modal('hide');
  }

  productSubmit() {
    // Recoger valores del formulario
    let nombre: string = this.productForm.controls['nombre'].value;
    let precio: number = this.productForm.controls['precio'].value;
    let pesoNeto: string = this.productForm.controls['pesoNeto'].value;
    let image: string = this.url;

    // Crear producto
    this.api.createProduct(nombre, precio, pesoNeto, image, this.id.value).pipe(finalize( () => {

      let products: Product[] = this.product.visibleProducts.value;

      products.push({
        'nombre': nombre,
        'precio': precio,
        'peso_neto': pesoNeto,
        'foto': image,
        'id_usuario': this.id.value,
        'id' : -1
      });

      this.product.visibleProducts.next(products);
      this.product.getProductos();

      this.productModalClose();

    })).subscribe(( res: any ) => {
      console.log(res);
    });

  }

  selectFile(event: any) {
    if (event.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event:any) => {
        this.url = event.target.result;
        console.log(this.url);
      }
    }
  }

}

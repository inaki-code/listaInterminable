import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators, } from '@angular/forms';
import { ApiService } from '../../../services/api/api.service';
import { BehaviorSubject, finalize} from 'rxjs';
import { User } from '../../../interfaces/user';
import { CallComponentsService } from '../../../services/call-components/call-components.service';
import { SessionService } from '../../../services/session/session.service';
import { ProductService } from '../../../services/product/product.service';
import { Product } from '../../../interfaces/product';

// JQUERY
declare var $:any;

@Component({
  selector: 'edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent implements OnInit {

  // Usuarios registrados
  //public users: User[] = [];
  // Formulario para introducir productos
  public productForm: FormGroup;
  // URL de la foto
  url: string = '';
  id: BehaviorSubject<number> = new BehaviorSubject(-1);
  productToEdit: Product = this.call.editProductsModal.value;

  constructor ( private fb: FormBuilder, private api: ApiService, private call: CallComponentsService, private session: SessionService, private product: ProductService) {
    this.productForm = this.fb.group({
      nombre: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25)]],
      precio: ['', [Validators.maxLength(10)]],
      pesoNeto: ['', [Validators.maxLength(10)]],
      image: ['']
    });

  }

  ngOnInit(): void {

    //console.log(this.productToEdit);

    this.session.id.subscribe( res => {
      this.id.next(res);
    })

    // Avisar al componente navbar cuando se cierre la modal de editar productos
    $('#exampleModal').on('hidden.bs.modal', () => {
      this.call.callEditProductsModal.emit(false);
    });

    this.editProductModalOpen();

    this.productForm.controls['nombre'].setValue(this.productToEdit.nombre);
    this.productForm.controls['precio'].setValue(this.productToEdit.precio);
    this.productForm.controls['pesoNeto'].setValue(this.productToEdit.peso_neto);
    this.url = this.productToEdit.foto;

  }

  editProductModalOpen() {
    $('#exampleModal').modal('show');
  }

  editProductModalClose() {
    $('#exampleModal').modal('hide');
  }

  editProductSubmit() {
    // Recoger valores del formulario
    let nombre: string = this.productForm.controls['nombre'].value;
    let precio: number = this.productForm.controls['precio'].value;
    let pesoNeto: string = this.productForm.controls['pesoNeto'].value;
    let image: string = this.url;

    let modifiedProduct: Product = {
      'nombre': nombre,
      'precio': precio,
      'peso_neto': pesoNeto,
      'foto': image,
      'id_usuario': this.id.value,
      'id': this.productToEdit.id
    };

    // Editar Productos
    this.api.modifyProduct(this.productToEdit.id, modifiedProduct).pipe(finalize( () => {

      let products: Product[] = this.product.visibleProducts.value;

      for (let i = 0; i < products.length; i++) {
        if (products[i].id == this.productToEdit.id) {
          products[i] = modifiedProduct;

          break;
        }
      }

      this.product.visibleProducts.next(products);
      this.product.getProductos();

      this.editProductModalClose();

    })).subscribe(( res: any ) => {
      if (res != null) {
        console.log(res);
      }
    });

  }

  selectFile(event: any) {
    if (event.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event:any) => {
        this.url = event.target.result;
      }
    }
  }

}

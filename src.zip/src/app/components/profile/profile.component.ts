import { Component, OnInit, AfterViewChecked } from '@angular/core';
import { User } from '../../interfaces/user';
import { BehaviorSubject, finalize } from 'rxjs';
import { ApiService } from '../../services/api/api.service';
import { SessionService } from '../../services/session/session.service';
import { CallComponentsService } from '../../services/call-components/call-components.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { List } from '../../interfaces/list';
import { AgregarService } from '../../services/agregar/agregar.service';
import { LikesService } from '../../services/likes/likes.service';
import { ListService } from '../../services/list/list.service';
import { LocalLikes } from '../../interfaces/local-likes';


// JQUERY
declare var $:any;

@Component({
  selector: 'profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit, AfterViewChecked {

  // id usuario logeado
  public id: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  // Usuario propietario del perfil
  public user: BehaviorSubject<User> = new BehaviorSubject<User>({
    'id': -1,
    'email': '',
    'token': '',
    'status': '',
    'name': '',
    'foto': '',
    'password': '',
    'loggedin': 0,
    'ban': 0
  });
  public seeProfile: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  public seeBanModal: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  // Formulario del perfil
  public profileForm: FormGroup;
  // status
  public status: BehaviorSubject<string> = new BehaviorSubject<string>('');
  public url: string = '';
  public lists: BehaviorSubject<List[]> = new BehaviorSubject<List[]>(new Array());
  public likes: BehaviorSubject<List[]> = new BehaviorSubject<List[]>(new Array());
  public userProfileLikes: BehaviorSubject<List[]> = new BehaviorSubject<List[]>(new Array());
  public idListsUserLikes: BehaviorSubject<number[]> = new BehaviorSubject<number[]>(new Array());
  public list_like: BehaviorSubject<LocalLikes[]> = new BehaviorSubject<LocalLikes[]>(new Array());

  constructor(private api: ApiService, private session: SessionService, private call: CallComponentsService, private fb: FormBuilder, private like: LikesService, public agregar: AgregarService, private list: ListService) {
    this.profileForm = this.fb.group({
      email: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(50), Validators.email]],
      password: ['', [Validators.minLength(8), Validators.maxLength(25)]],
      repeatPassword: ['', [Validators.minLength(8), Validators.maxLength(25)]],
      completeName: ['', [Validators.minLength(2), Validators.maxLength(25)]],
      image: [''],
      status: ['']
    });

  }

  ngOnInit(): void {

    this.like.list_like.subscribe(res => {
      this.list_like.next(res);
    });

    this.list.lists.subscribe(res => {
      this.lists.next(res);
    });

    this.like.idListsUserLikes.subscribe(res => {
      this.idListsUserLikes.next(res);
    });

    this.like.idListsUserLikes.subscribe(res => {

      let listsLiked: List[] = new Array();

      for ( let l of this.lists.value ) {
        if ( res.includes(l.id) ) {
          listsLiked.push(l);
        }
      }

      this.likes.next(listsLiked);
    });

    this.session.id.subscribe(res => {
      this.id.next(res);
    });

    this.call.callProfile.subscribe(res => {

      this.seeProfile.next(res);
      //console.log(res);

      let listsLiked: number[] = new Array();

      //console.log(this.like.list_like.value);

      for ( let l of this.like.list_like.value ) {
        if ( l.likes.includes( parseInt(res.toString()) ) ) {
          listsLiked.push(l.id_list);
        }
      }

      //console.log(listsLiked);

      let lists: List[] = new Array();

      for (let l of listsLiked) {
        for (let x of this.lists.value) {
          if (l == x.id) {
            lists.push(x);
            break;
          }
        }
      }

      this.userProfileLikes.next(lists);
      //console.log(lists);

    });

    this.call.callBanModal.subscribe(res => {
      this.seeBanModal.next(res);
    });

    this.call.callUserProfile.subscribe(res => {
      this.user.next(res);

      // Infomación del perfil
      if (res.id > 0) {
        this.profileForm.controls['email'].setValue(res.email);
        this.profileForm.controls['completeName'].setValue(res.name);
        this.url = res.foto;

        if (this.status.value == 'admin') {
          this.profileForm.controls['status'].setValue('admin');
        }
        else {
          this.profileForm.controls['status'].setValue('user');
        }

      }

    });

    this.session.status.subscribe(res => {
      this.status.next(res);
    });

  }

  ngAfterViewChecked(): void {
    $('[data-toggle="tooltip"]').tooltip();
  }

  solicitudAmistad(userAgregado: number) {

    alert('has enviado tu petición de amistad');
    this.api.createAgregar(this.id.value, userAgregado).pipe(finalize( () => {

      // Ponemos la petición en las peticiones pendientes
      let peticionesHechas: number[] = this.agregar.peticionesHechas.value;
      peticionesHechas.push(userAgregado);
      this.agregar.peticionesHechas.next(peticionesHechas);

      // Incluir al usuario que hacemos la petición en usuarios no agregables
      let noAgregables: number[] = this.agregar.usersNoAgregables.value;
      noAgregables.push(userAgregado);
      this.agregar.usersNoAgregables.next(noAgregables);

    })).subscribe();

  }

  selectFile(event: any) {
    if (event.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event:any) => {

        this.user.value.foto = event.target.result;
        this.url = event.target.result
        //console.log(this.user.value);

      }
    }
  }

  profileSubmit() {

    let user: User = {
      'id': this.user.value.id,
      'email': this.profileForm.controls['email'].value,
      'token': this.user.value.token,
      'status': this.profileForm.controls['status'].value,
      'name': this.profileForm.controls['completeName'].value,
      'foto': this.url,
      'password': this.user.value.password,
      'loggedin': this.user.value.loggedin,
      'ban': 0
    };

    this.session.foto.next(this.url);

    if (this.profileForm.controls['password'].value == '' && this.profileForm.controls['repeatPassword'].value == '') {

      //console.log(user);

      this.api.modifyUser(this.user.value.id, user, 0).subscribe(res => {
        if (res != null) {
          console.log(res);
        }
      });

    }
    else {

      if (this.profileForm.controls['password'].value == this.profileForm.controls['repeatPassword'].value) {

        user.password = this.profileForm.controls['password'].value;

        this.api.modifyUser(this.user.value.id, user, 1).subscribe(res => {
          if (res != null) {
          console.log(res);
        }
        });

      }
      else {
        alert('Las contraseñas no coinciden');
      }

    }

  }

  goToList(list: List) {

    this.call.callLists.next(false);
    this.call.callProducts.next(false);
    this.call.callProfile.next(-1);

    this.call.List.next(list);
    this.call.callList.next(list.id);
  }

  openBanModal() {
    this.call.callBanModal.emit(true);
  }

  quitarLike(event: any, list: List) {

    event.stopPropagation();

    // Eliminar like en el servidor
    this.api.removeLike(this.id.value, list.id).subscribe(res => {
      if (res != null) {
        console.log(res);
      }
    });

    // Contabilizar Like
    for ( let x = 0; x < this.like.list_like.value.length; x++ ) {

      /*console.log(this.like.list_like.value[x].id_list);
      console.log(list.id);*/

      if ( list.id == this.like.list_like.value[x].id_list ) {

        if (this.like.list_like.value[x].likes.length == 1) {
          let newListLike: LocalLikes[] = this.like.list_like.value;
          newListLike.splice(x, 1);

          //console.log(newListLike);
          this.like.list_like.next(newListLike);
        }
        else {

          let index: number = this.like.list_like.value[x].likes.indexOf( parseInt(this.id.value.toString()) );
          //console.log(index);
          let newListLikes: LocalLikes[] = this.like.list_like.value;
          newListLikes[x].likes.splice(index, 1);
          this.like.list_like.next(newListLikes);

          /*console.log(this.like.list_like.value[x].likes);
          console.log(this.id.value);
          console.log(this.like.list_like.value);*/
        }

      }
    }

    // Se elimina lista likeada en el html
    let index: number = this.likes.value.indexOf(list);
    let newLikes: List[] = this.likes.value;
    newLikes.splice(index, 1);

    this.likes.next(newLikes);

    index = this.like.idListsUserLikes.value.indexOf(list.id);
    let likesNew: number[] = this.like.idListsUserLikes.value;
    likesNew.splice(index, 1);

    this.like.idListsUserLikes.next(likesNew);

  }

  darLike(list: List, iduser: number, event: any) {

    event.stopPropagation();

    this.api.createLike(iduser, list.id).subscribe(res => {
      if (res != null) {
        console.log(res);
      }
    });

    let exists: boolean = false;

    for ( let l of this.list_like.value ) {
      if ( l.id_list == list.id ) {

        l.likes.push(parseInt(this.id.value.toString()));
        exists = true;

        break;

      }
    }

    if ( !exists ) {
      let listLike: LocalLikes = {id_list: list.id, likes: [parseInt(this.id.value.toString())]};
      let newlistLike: LocalLikes[] = this.list_like.value;
      newlistLike.push(listLike);
      this.list_like.next(newlistLike);
    }

    //this.list.lists.next(lists);

    let idListsUserLikes: number[] = this.idListsUserLikes.value;
    idListsUserLikes.push(list.id);
    this.like.idListsUserLikes.next(idListsUserLikes);

    //console.log(this.list_like.value);

  }



}

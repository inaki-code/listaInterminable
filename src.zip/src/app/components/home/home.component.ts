import { Component, OnInit, Output } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { SessionService } from '../../services/session/session.service';

declare var $:any;

@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  // id usuario logeado
  public id: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  public loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  constructor(private session: SessionService) {

  }


  ngOnInit(): void {

    // Para que el dropdown se comporte como una modal
    $('.dropdown-menu').click(function(event: any){
      event.stopPropagation();
    });

    this.session.id.subscribe(res => {

      this.id.next(res);

      /*if (res > 0) {
        console.log('Usuario nº ' + res + ' Logeado');
      }*/

    });

    this.session.isLogedIn.subscribe(res => {
      this.loggedIn.next(res);
    });

  }






}

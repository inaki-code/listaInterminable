import { Injectable } from '@angular/core';
import { BehaviorSubject, finalize } from 'rxjs';
import { ListService } from '../list/list.service';
import { CallComponentsService } from '../call-components/call-components.service';
import { ApiService } from '../api/api.service';
import { Likes } from '../../interfaces/likes';
import { SessionService } from '../session/session.service';
import { LocalLikes } from '../../interfaces/local-likes';

@Injectable({
  providedIn: 'root'
})
export class LikesService {

  reload: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public id: BehaviorSubject<number> = new BehaviorSubject<number>( -1 );
  public likes: BehaviorSubject<Likes[]> = new BehaviorSubject<Likes[]>( new Array() );
  //public idListLikes: BehaviorSubject<number[]> = new BehaviorSubject<number[]>( new Array() );
  public list_like: BehaviorSubject<LocalLikes[]> = new BehaviorSubject<LocalLikes[]>(new Array());
  //public listedLikes: BehaviorSubject<number[]> = new BehaviorSubject<number[]>( new Array() );
  public idListsUserLikes: BehaviorSubject<number[]> = new BehaviorSubject<number[]>( new Array() );

  constructor(private api: ApiService, private session: SessionService) {

    this.getLikes();

    this.session.id.subscribe(res => {
      this.id.next(res);

      this.getLikes();
    });

    // Recibir likes
    /*this.reload.subscribe(() => {

      setTimeout( ()=>{
        this.getLikes();
      }, 20 * 1000 );

    });*/

  }

  getLikes() {

    this.api.getLikes().subscribe(( res: any ) => {

      this.likes.next(res.likes);
      //console.log(res.likes);

      let numLikes: LocalLikes[] = [];
      //let idLikes: number[] = new Array();
      let idsContados: number[] = new Array();
      let listsUserLikes: number[] = new Array();

      for (let l of this.likes.value) {

        if ( !idsContados.includes(l.id_list) ) {

          let idUsers: number[] = [];

          for (let x of this.likes.value) {

            if (l.id_list == x.id_list) {
              idUsers.push(parseInt(x.id_user.toString()));
            }

          }

          numLikes.push({'id_list': l.id_list, 'likes': idUsers});

          idsContados.push(l.id_list);
        }

        if (l.id_user == this.id.value ) {
          listsUserLikes.push(l.id_list);
        }
      }

      this.idListsUserLikes.next(listsUserLikes);
      //console.log(listsUserLikes);

      //this.listedLikes.next(idsContados);

      this.list_like.next(numLikes);
      //console.log(this.list_like.value);
      //console.log(numLikes);

      this.reload.next(true);


    });

  }


}

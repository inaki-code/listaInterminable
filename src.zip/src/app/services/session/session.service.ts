import { Injectable, EventEmitter, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../api/api.service';
import { User } from '../../interfaces/user';
import { BehaviorSubject, Subject, finalize } from 'rxjs';
import { ListService } from '../list/list.service';

declare var $:any;

@Injectable({
  providedIn: 'root'
})
export class SessionService {

  // Usuarios registrados
  public users: BehaviorSubject<User[]> = new BehaviorSubject<User[]>( Array() );

  email: Subject<string> = new BehaviorSubject<string>('');
  status: BehaviorSubject<string> = new BehaviorSubject<string>('');
  token: BehaviorSubject<any> = new BehaviorSubject<any>(sessionStorage.getItem('token'));
  id: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  isLogedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  foto: BehaviorSubject<any> = new BehaviorSubject<any>(null);

  constructor(private api: ApiService) {
    // GET usuarios existentes
    this.api.getUsers().pipe(finalize( () => {

      if (sessionStorage.getItem('token') != null) {
        for (let u of this.users.value) {

          if (u.token == this.token.value) {
            this.login(u.email);

            break;
          }

        }
      }
    })).subscribe(( res: any ) => {
      this.users.next(res.users);
    });


  }

  login(email: string) {
    for (let u of this.users.value) {

      if (u.email == email) {
        // Almacenamos información del usuario logeado
        sessionStorage.setItem('token', u.token);
        this.isLogedIn.next(true);
        this.id.next(u.id);
        this.status.next(u.status);
        //console.log(u);
        this.email.next(email);
        this.foto.next(u.foto);
        break;
      }

    }

  }

  logout() {

    sessionStorage.removeItem('token');
    this.email.next('');
    this.status.next('');
    this.isLogedIn.next(false);
    this.token.next(null);
    this.id.next(-1);
    this.foto.next(null);

  }


}

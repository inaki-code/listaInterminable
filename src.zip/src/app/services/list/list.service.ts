import { Injectable } from '@angular/core';
import { SessionService } from '../session/session.service';
import { List } from '../../interfaces/list';
import { User } from '../../interfaces/user';
import { BehaviorSubject, finalize } from 'rxjs';
import { ApiService } from '../api/api.service';
import { PertenecerService } from '../pertenecer/pertenecer.service';
import { Pertenecer } from '../../interfaces/pertenecer';
import { CallComponentsService } from '../call-components/call-components.service';

@Injectable({
  providedIn: 'root'
})
export class ListService {

  reload: BehaviorSubject<boolean> = new BehaviorSubject(false);
  // Listas de la BDD
  public lists: BehaviorSubject<List[]> = new BehaviorSubject<List[]>(Array());
  // id usuario logeado
  public id: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  // Listas visibles
  public visibleLists: BehaviorSubject<List[]> = new BehaviorSubject<List[]>(Array());
  // id lista eliminable
  public idRemove: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  /*public propietarios: BehaviorSubject<User[]> = new BehaviorSubject<User[]>(Array());
  public usuarios: BehaviorSubject<User[]> = new BehaviorSubject<User[]>(Array());*/
  public pertenecer: BehaviorSubject<Pertenecer[]> = new BehaviorSubject<Pertenecer[]>(new Array());

  constructor(private session: SessionService, private api: ApiService, private call: CallComponentsService, private apipertenecer: PertenecerService) {

    this.apipertenecer.pertenecer.subscribe(res => {
      this.pertenecer.next(res);
      //console.log(res);
    });

    // Cada vez que cambiamos el usuario reseteamos las listas
    this.session.id.subscribe(res => {
      this.id.next(res);
      this.getListas();
    });

    // Recibir listas
    /*this.reload.subscribe(() => {

      setTimeout( ()=>{
        this.getListas();
      }, 20 * 1000 );

    });*/
  }

  getListas()  {

    let status: string = '';

    this.session.status.subscribe(res => {
      status = res;
    });

    this.api.getLists().pipe(finalize(() => {
      let lists: List[] = [];

      for (let l of this.lists.value) {

        let pertenecer: Pertenecer[] = this.pertenecer.value.filter(p => p.id_list == l.id);
        let idpropietarios: number[] = [];
        let idusuarios: number[] = [];

        for (let p of pertenecer) {
          if (p.rol == 'propietario') {
            idpropietarios.push(p.id_user);
          }
          else {
            idusuarios.push(p.id_user);
          }
        }

        if (l.id_usuario == this.id.value || idpropietarios.includes( this.id.value ) || idusuarios.includes( this.id.value ) ) {
          lists.push(l);
        }
      }

      // Solo actualizar las listas visibles para los usuarios normales ya que los administradores ven todas
      if (status == 'user') {
        this.visibleLists.next(lists);
      }

      this.reload.next(true);

      //console.log(lists);

    })).subscribe(( res: any ) => {

      this.lists.next(res.lists);

    });

  }

}

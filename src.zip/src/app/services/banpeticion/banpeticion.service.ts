import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Banpeticion } from '../../interfaces/banpeticion';
import { ApiService } from '../api/api.service';
import { User } from '../../interfaces/user';
import { SessionService } from '../session/session.service';

@Injectable({
  providedIn: 'root'
})
export class BanpeticionService {

  public userBanPeticion: BehaviorSubject<Banpeticion[]> = new BehaviorSubject<Banpeticion[]>( new Array() );
  public usuarios: BehaviorSubject<User[]> = new BehaviorSubject<User[]>( new Array() );
  public usuariosBaneados: BehaviorSubject<User[]> = new BehaviorSubject<User[]>( new Array() );

  constructor(private api: ApiService, private session: SessionService) {

    this.getBanPeticiones();


  }

  getBanPeticiones() {
    this.api.getBanPeticiones().subscribe((res: any) => {

      this.userBanPeticion.next(res.banPeticiones);
      console.log(this.userBanPeticion.value);

    });

    this.session.users.subscribe(res => {

      this.usuarios.next(res);

      let baneados: User[] = [];

      for (let u of res) {
        if (u.ban == 1) {
          baneados.push(u);
        }
      }

      this.usuariosBaneados.next(baneados);



    });
  }


}

import { TestBed } from '@angular/core/testing';

import { BanpeticionService } from './banpeticion.service';

describe('BanpeticionService', () => {
  let service: BanpeticionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BanpeticionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

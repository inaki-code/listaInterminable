import { Injectable } from '@angular/core';
import { Pertenecer } from '../../interfaces/pertenecer';
import { BehaviorSubject } from 'rxjs';
import { ApiService } from '../api/api.service';

@Injectable({
  providedIn: 'root'
})
export class PertenecerService {

  public pertenecer: BehaviorSubject<Pertenecer[]> = new BehaviorSubject<Pertenecer[]>(new Array());

  constructor(public api: ApiService) {

    this.getPertenecer();

  }

  getPertenecer() {
    this.api.getPertenecer().subscribe((res: any) => {

      this.pertenecer.next(res.pertenecer);
      console.log(res.pertenecer);

    });
  }
}

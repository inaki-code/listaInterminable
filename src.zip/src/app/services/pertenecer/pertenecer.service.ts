import { Injectable } from '@angular/core';
import { Pertenecer } from '../../interfaces/pertenecer';
import { BehaviorSubject } from 'rxjs';
import { ApiService } from '../api/api.service';
import { AgregarService } from '../agregar/agregar.service';

@Injectable({
  providedIn: 'root'
})
export class PertenecerService {

  reload: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public pertenecer: BehaviorSubject<Pertenecer[]> = new BehaviorSubject<Pertenecer[]>(new Array());

  constructor(public api: ApiService) {

    // Recibir que usuarios pertenecen a que listas
    /*this.reload.subscribe(() => {

      setTimeout( ()=>{
        this.getPertenecer();
      }, 20 * 1000 );

    });*/

    this.getPertenecer();


  }

  getPertenecer() {
    this.api.getPertenecer().subscribe((res: any) => {

      this.pertenecer.next(res.pertenecer);
      //console.log(res.pertenecer);

    });
  }
}

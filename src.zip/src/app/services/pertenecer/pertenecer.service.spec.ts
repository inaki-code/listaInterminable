import { TestBed } from '@angular/core/testing';

import { PertenecerService } from './pertenecer.service';

describe('PertenecerService', () => {
  let service: PertenecerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PertenecerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { Injectable } from '@angular/core';
import { ApiService } from '../api/api.service';
import { SessionService } from '../session/session.service';
import { Comprar } from '../../interfaces/comprar';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ComprarService {

  public userCompras: BehaviorSubject<Comprar[]> = new BehaviorSubject(Array());

  constructor(private api: ApiService, private session: SessionService) {
    this.getComprar();
  }

  getComprar() {

    this.api.getComprar().subscribe((res : any) => {

      let compras: Comprar[] = [];

      for (let c of res.comprar) {
        let fecha = new Date(c.fecha);
        let anyo = new Date();
        if (c.id_usuario == this.session.id.value && anyo.getFullYear() == fecha.getFullYear()) {
          compras.push(c);
        }
      }

      this.userCompras.next(compras);

    });

  }
}

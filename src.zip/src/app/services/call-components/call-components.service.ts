import { Injectable, Output, EventEmitter } from '@angular/core';
import { BehaviorSubject, finalize } from 'rxjs';
import { List } from '../../interfaces/list';
import { Product } from '../../interfaces/product';
import { User } from '../../interfaces/user';
import { AgregarService } from '../agregar/agregar.service';
import { SessionService } from '../session/session.service';
import { PertenecerService } from '../pertenecer/pertenecer.service';
import { Pertenecer } from '../../interfaces/pertenecer';

@Injectable({
  providedIn: 'root'
})
export class CallComponentsService {

  @Output()
  callSingUp: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callNewListModal: EventEmitter<boolean> = new EventEmitter();
  @Output()
  newListModaltype: BehaviorSubject<string> = new BehaviorSubject<string>('');
  @Output()
  callListsModal: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callCListModal: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callLists: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callProducts: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callProductsModal: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callBanModal: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callBanContainer: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callListBanContainer: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callUserContainer: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callGraph: EventEmitter<boolean> = new EventEmitter();
  @Output()
  goToProfile: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  @Output()
  callProfile: BehaviorSubject<number> = new BehaviorSubject(-1);
  @Output()
  callUserProfile: BehaviorSubject<User> = new BehaviorSubject<User>({
    id: -1,
    email: '',
    password: '',
    status: '',
    loggedin: 0,
    name: '',
    foto: '',
    token: '',
    ban: 0
  });

  @Output()
  callList: EventEmitter<number> = new EventEmitter();
  @Output()
  List: BehaviorSubject<List> = new BehaviorSubject<List>({ id: -1, nombre: '', tipo: '', id_usuario: -1, ban: 0 });
  @Output()
  public usuarioPropietario: BehaviorSubject<User> = new BehaviorSubject<User>({
    id: -1,
    email: '',
    password: '',
    status: '',
    loggedin: 0,
    name: '',
    foto: '',
    token: '',
    ban: 0
  });
  @Output()
  public propietarios: BehaviorSubject<User[]> = new BehaviorSubject(Array());
  // usuarios sin privilegios de la lista
  @Output()
  public usuarios: BehaviorSubject<User[]> = new BehaviorSubject(Array());
  @Output()
  public agregados: BehaviorSubject<User[]> = new BehaviorSubject(Array());
  @Output()
  public usuariosLista: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  //
  @Output()
  public idpropietarios: BehaviorSubject<number[]> = new BehaviorSubject(Array());
  // usuarios sin privilegios de la lista
  @Output()
  public idusuarios: BehaviorSubject<number[]> = new BehaviorSubject(Array());
  @Output()
  public idagregados: BehaviorSubject<number[]> = new BehaviorSubject(Array());
  //
  @Output()
  public rol: BehaviorSubject<string> = new BehaviorSubject('');
  @Output()
  public id: BehaviorSubject<number> = new BehaviorSubject(-1);

  @Output()
  callEditProductsModal: EventEmitter<boolean> = new EventEmitter();
  @Output()
  editProductsModal: BehaviorSubject<Product> = new BehaviorSubject<Product>({
    id : -1,
    nombre: '',
    peso_neto: '',
    foto: '',
    id_usuario: -1,
    precio: 0
  });


  constructor(private agregar: AgregarService, private session: SessionService, private apipertenecer: PertenecerService ) {

    let users: BehaviorSubject<User[]> = new BehaviorSubject(Array());

    let amigos: BehaviorSubject<number[]> = new BehaviorSubject(Array());

    let pertenecer: BehaviorSubject<Pertenecer[]> = new BehaviorSubject(Array());

    this.agregar.amigos.subscribe(res => {
      amigos.next(res);
    });

    this.session.users.subscribe(res => {
      users.next(res);
    });

    this.apipertenecer.pertenecer.subscribe(res => {
      pertenecer.next(res);
      //console.log(res);
    });


    this.session.id.subscribe(res => {
      this.id.next(res);
    });

    this.List.subscribe(res => {

      let idpropietarios: number[] = [];
      let idusuarios: number[] = [];
      let idagregados: number[] = amigos.value;

      let propietarios: User[] = new Array();
      let usuarios: User[] = new Array();
      let agregados: User[] = this.session.users.value.filter(user => amigos.value.includes(user.id));

      if (res.id != -1) {
        for (let p of pertenecer.value) {

          if (p.id_list == res.id) {

            if (p.rol == 'propietario') {

              let user: User[] = this.session.users.value.filter(user => user.id == p.id_user);

              propietarios.push(user[0]);

              idpropietarios.push(p.id_user);


            }
            else {

              let user: User[] = this.session.users.value.filter(user => user.id == p.id_user);

              usuarios.push(user[0]);

              idusuarios.push(p.id_user);

            }

            for (let i = 0; i < agregados.length; i++) {
              if (p.id_user == agregados[i].id) {
                agregados.splice(i, 1);
                break;
              }
            }

          }

        }
      }

      let users: User[] = this.session.users.value.filter(user => user.id == res.id_usuario);
      let user: User = users[0];
      this.usuarioPropietario.next(user);

      this.idpropietarios.next(idpropietarios);
      this.idusuarios.next(idusuarios);
      this.idagregados.next(idagregados);

      this.propietarios.next(propietarios);
      this.usuarios.next(usuarios);
      this.agregados.next(agregados);

      this.usuariosLista.next(propietarios.length + usuarios.length + 1);

      /*console.log(propietarios);
      console.log(usuarios);
      console.log(agregados);*/

    });

    this.callProfile.subscribe(res => {

      let user: User = {
        id: -1,
        token: '',
        email: '',
        foto: '',
        status: '',
        name: '',
        loggedin: 0,
        ban: 0
      };

      for (let u of this.session.users.value) {
        if (u.id == res) {
          user = u;
          break;
        }
      }

      if (user.id > 0) {
        this.callUserProfile.next(user);
      }

    });



  }







}

import { Injectable, Output, EventEmitter, ComponentFactoryResolver } from '@angular/core';
import { BehaviorSubject, finalize } from 'rxjs';
import { List } from '../../interfaces/list';
import { Product } from '../../interfaces/product';
import { User } from '../../interfaces/user';
import { AgregarService } from '../agregar/agregar.service';
import { SessionService } from '../session/session.service';

@Injectable({
  providedIn: 'root'
})
export class CallComponentsService {

  @Output()
  callListsModal: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callIListModal: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callCListModal: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callLists: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callProducts: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callProductsModal: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callBanModal: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callBanContainer: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callListBanContainer: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callUserContainer: EventEmitter<boolean> = new EventEmitter();
  @Output()
  goToProfile: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  @Output()
  callProfile: BehaviorSubject<number> = new BehaviorSubject(-1);
  @Output()
  callUserProfile: BehaviorSubject<User> = new BehaviorSubject<User>({
    id: -1,
    email: '',
    password: '',
    status: '',
    loggedin: 0,
    name: '',
    foto: '',
    token: '',
    ban: 0
  });
  @Output()
  callAListModal: EventEmitter<boolean> = new EventEmitter();
  @Output()
  callTListModal: EventEmitter<boolean> = new EventEmitter();

  @Output()
  callList: EventEmitter<number> = new EventEmitter();
  @Output()
  List: BehaviorSubject<List> = new BehaviorSubject<List>({
    id: -1,
    nombre: '',
    tipo: '',
    usuarios: '',
    propietarios: '',
    id_usuario: -1,
    ban: 0
  });
  // propietarios de la lista
  @Output()
  public idpropietarios: BehaviorSubject<number[]> = new BehaviorSubject(Array());
  // usuarios sin privilegios de la lista
  @Output()
  public idusuarios: BehaviorSubject<number[]> = new BehaviorSubject(Array());
  @Output()
  public idagregados: BehaviorSubject<number[]> = new BehaviorSubject(Array());
  @Output()
  public rol: BehaviorSubject<string> = new BehaviorSubject('');
  @Output()
  public id: BehaviorSubject<number> = new BehaviorSubject(-1);

  @Output()
  callEditProductsModal: EventEmitter<boolean> = new EventEmitter();
  @Output()
  editProductsModal: BehaviorSubject<Product> = new BehaviorSubject<Product>({
    id : -1,
    nombre: '',
    peso_neto: '',
    foto: '',
    id_usuario: -1,
    precio: 0
  });


  constructor(private agregar: AgregarService, private session: SessionService ) {

    let users: BehaviorSubject<User[]> = new BehaviorSubject(Array());

    let amigos: BehaviorSubject<number[]> = new BehaviorSubject(Array());

    this.agregar.amigos.subscribe(res => {
      amigos.next(res);
    });

    this.session.users.subscribe(res => {
      users.next(res);
    });

    this.session.id.subscribe(res => {
      this.id.next(res);
    });

    this.List.subscribe(res => {

      if (res.tipo == 'colectiva' || res.tipo == 'anarquica' || res.tipo == 'totalitaria') {

        //console.log(res);

        let propietarios: string[] = [];
        let usuarios: string[] = [];

        let idPropietarios: number[] = [];
        let idusuarios: number[] = [];

        propietarios = res.propietarios.split(',');
        usuarios = res.usuarios.split(',');

        propietarios[0] = propietarios[0].replace('[', '');
        propietarios[ propietarios.length -1 ] = propietarios[ propietarios.length -1 ].replace(']', '');

        usuarios[0] = usuarios[0].replace('[', '');
        usuarios[ usuarios.length -1 ] = usuarios[ usuarios.length -1 ].replace(']', '');

        for (let p of propietarios) {
          idPropietarios.push( parseInt(p) );
        }

        for (let u of usuarios) {
          idusuarios.push( parseInt(u) );
        }

        console.log(amigos.value);

        let p: number[] = Array();
        let u: number[] = Array();
        let a: number[] = Array();

        for (let user of users.value) {

          if ( idPropietarios.includes( parseInt( user.id.toString() ) ) ) {

            p.push( parseInt( user.id.toString() ) );

          }
          else {
            if ( idusuarios.includes( parseInt( user.id.toString() ) ) ) {

              u.push( parseInt( user.id.toString() ) );

            }
            else {

              if ( amigos.value.includes( user.id ) ) {
                a.push( parseInt( user.id.toString() ) );
              }

            }
          }
        }

        this.idagregados.next(a);
        this.idpropietarios.next(p);
        this.idusuarios.next(u);

        console.log(a);
        console.log(p);
        console.log(u);
      }

      this.getRol();
    });

    this.callProfile.subscribe(res => {

      let user: User = {
        id: -1,
        token: '',
        email: '',
        foto: '',
        status: '',
        name: '',
        loggedin: 0,
        ban: 0
      };

      for (let u of this.session.users.value) {
        if (u.id == res) {
          user = u;
          break;
        }
      }

      if (user.id > 0) {
        this.callUserProfile.next(user);
      }

    });



  }

  getRol() {

    if (this.session.status.value == 'admin') {
      this.rol.next('propietario');
    }
    else  {
      if ( this.idpropietarios.value.includes( parseInt(this.id.value.toString()) ) || this.List.value.id_usuario == this.id.value ) {
        this.rol.next('propietario');
      }
      else {
        this.rol.next('usuario');
      }
    }

  }






}

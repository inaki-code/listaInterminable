import { TestBed } from '@angular/core/testing';

import { ListpeticionesService } from './listpeticiones.service';

describe('ListpeticionesService', () => {
  let service: ListpeticionesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ListpeticionesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

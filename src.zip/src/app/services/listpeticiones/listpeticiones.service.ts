import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { List } from '../../interfaces/list';
import { Listpeticion } from '../../interfaces/listpeticion';
import { User } from '../../interfaces/user';
import { ApiService } from '../api/api.service';
import { ListService } from '../list/list.service';

@Injectable({
  providedIn: 'root'
})
export class ListpeticionesService {

  public listBansPeticion: BehaviorSubject<Listpeticion[]> = new BehaviorSubject<Listpeticion[]>( new Array() );
  public lists: BehaviorSubject<List[]> = new BehaviorSubject<List[]>( new Array() );
  public banLists: BehaviorSubject<List[]> = new BehaviorSubject<List[]>( new Array() );

  constructor(public api: ApiService, private list: ListService) {

    this.api.getListPeticiones().subscribe((res: any) => {

      this.listBansPeticion.next(res.listPeticiones);
      console.log(this.listBansPeticion.value);

    });

    // Listas Baneadas
    this.list.lists.subscribe(res => {

      this.lists.next(res);

      let baneadas: List[] = [];

      for (let u of res) {
        if (u.ban == 1) {
          baneadas.push(u);
        }
      }

      this.banLists.next(baneadas);

    });

  }

  eliminarPeticion(id_list: number) {

    this.api.removeListPeticion(id_list).subscribe(res => {
      if (res != null) {
        console.log(res);
      }
    });

    let peticiones: Listpeticion[] = this.listBansPeticion.value;

    for (let i = 0; i < peticiones.length; i++) {
      if (peticiones[i].id == id_list) {
        peticiones.splice(i, 1);
        break;
      }
    }

    this.listBansPeticion.next(peticiones);

  }
}

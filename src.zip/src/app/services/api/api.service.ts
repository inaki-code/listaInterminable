import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../../interfaces/user';
import { List } from '../../interfaces/list';
import { Product } from '../../interfaces/product';
import { Observable } from 'rxjs';
import { Agregar } from '../../interfaces/agregar';
import { Incluir } from '../../interfaces/incluir';
import { Banpeticion } from '../../interfaces/banpeticion';
import { Listpeticion } from '../../interfaces/listpeticion';
import { Likes }from '../../interfaces/likes';
import { Pertenecer } from '../../interfaces/pertenecer';
import { Comprar } from '../../interfaces/comprar';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  server: string = 'http://192.168.1.118/api/';
  local: string = 'http://localhost/listainterminable/php/';

  constructor(private httpClient: HttpClient) { }
    /* ------------------- */
    // --- Usuarios ---
    // ---Get
    public getUsers(): Observable<User[]> {
      //return this.httpClient.get<User[]>('http://localhost/listainterminable/php/apiuser.php');
      return this.httpClient.get<User[]>(this.server + 'apiuser.php');
    }
    // ---Create
    public createUser(email: string, password: string, repeatPassword: string, foto: any, status: string, name: string) {

      if (repeatPassword == password) {
        return this.httpClient.post<User>(this.server + 'apiuser.php',
        {
          "email": email,
          "status": status,
          "foto": foto,
          "password": password,
          "name": name
        });
      }
      else {
        alert('las contraseñas no coninciden');
        throw Error('Las constraseñas no coinciden');
      }

    }
    // ---Modify
    public modifyUser(id: number, user: User, encode: number) {
      return this.httpClient.put<User>(this.server + 'apiuser.php?id_user=' + id + '&encode=' + encode, user);
    }
    // ---Delete
    public RemoveUser(id: number) {
      return this.httpClient.delete<User>(this.server + 'apiuser.php?id=' + id);
    }
    /* ------------------- */
    // --- Productos ---
    // ---Get
    public getProducts(): Observable<Product[]> {
      return this.httpClient.get<Product[]>(this.server + 'apiproduct.php');
    }
    // ---Create
    public createProduct(name: string, price: number, weight: string, foto: any, idUser: number) {
      return this.httpClient.post<Product>(this.server + 'apiproduct.php',
        {
          "nombre": name,
          "precio": price,
          "peso_neto": weight,
          "foto": foto,
          "id_usuario": idUser
        });
    }
    // ---Delete
    public removeProduct(id: number) {
      return this.httpClient.delete<Product>(this.server + 'apiproduct.php?id=' + id)
    }
    // ---Modify
    public modifyProduct(id: number, product: Product) {
      return this.httpClient.put<Product>(this.server + 'apiproduct.php?id=' + id, product);
    }
    /* ------------------- */
    // --- Listas ---
    // ---Get
    public getLists(): Observable<List[]> {
      return this.httpClient.get<List[]>(this.server + 'apilist.php?nextId=0');
    }
    // ---Create
    public createList(nombre: string, tipo: string, foto: any, id_usuario: number) {
      return this.httpClient.post<List>(this.server + 'apilist.php',
        {
          "nombre": nombre,
          "tipo": tipo,
          "foto": foto,
          "id_usuario": id_usuario
        });
    }
    // ---Delete
    public removeList(id: number) {
      return this.httpClient.delete<List>(this.server + 'apilist.php?id=' + id);
    }
    // ---Modify
    public modifyList(id: number, list: List) {
      return this.httpClient.put<List>(this.server + 'apilist.php?id=' + id, list);
    }
    // ---Next Id
    public nextId(): Observable<number> {
      return this.httpClient.get<number>(this.server + 'apilist.php?nextId=1');
    }
    /* ------------------- */
    // --- Agregar ---
    // ---Get
    public getAgregar(): Observable<Agregar[]> {
      return this.httpClient.get<Agregar[]>(this.server + 'apiagregar.php');
    }
    // ---Create
    public createAgregar(id_usuario: number, id_usuarioAgregado: number) {
      return this.httpClient.post<Agregar>(this.server + 'apiagregar.php',
        {
          "id_user": id_usuario,
          "id_userAgregado": id_usuarioAgregado
        });
    }
    // ---Delete
    public removeAgregar(id_user: number, id_userAgregado: number) {
      return this.httpClient.delete<Agregar>(this.server + 'apiagregar.php?id_user=' + id_user + "&id_userAgregado=" + id_userAgregado);
    }
    // ---Modify
    public modifyAgregar(id_user: number, id_userAgregado: number, agregar: Agregar) {
      return this.httpClient.put<Agregar>(this.server + 'apiagregar.php?id_user=' + id_user + "&id_userAgregado=" + id_userAgregado, agregar);
    }
    /* ------------------- */
    // --- Incluir ---
    // ---Get
    public getIncluir(): Observable<Incluir[]> {
      return this.httpClient.get<Incluir[]>(this.server + 'apiincluir.php');
    }
    // ---Create
    public createIncluir(id_list: number, id_product: number, aceptado: number) {
      return this.httpClient.post<Incluir>(this.server + 'apiincluir.php',
        {
          "id_list": id_list,
          "id_product": id_product,
          "aceptado": aceptado
        });
    }
    // ---Delete
    public removeIncluir(id_list: number, id_product:number) {
      return this.httpClient.delete<Incluir>(this.server + 'apiincluir.php?id_list=' + id_list + "&id_product=" + id_product);
    }
    // ---Modify
    public modifyIncluir(id_list: number, id_product: number, incluir: Incluir) {
      return this.httpClient.put<Agregar>(this.server + 'apiincluir.php?id_list=' + id_list + "&id_product=" + id_product, incluir);
    }
    /* ------------------- */
    // --- Banpeticiones ---
    // ---Get
    public getBanPeticiones(): Observable<Banpeticion[]> {
      return this.httpClient.get<Banpeticion[]>(this.server + 'apibanpeticiones.php?nextId=0');
    }
    // ---Create
    public createBanpeticion(mensaje: string, id_userban: number, id_usuario: number) {
      return this.httpClient.post<Banpeticion>(this.server + 'apibanpeticiones.php',
      {
        "mensaje": mensaje,
        "id_userban": id_userban,
        "id_usuario": id_usuario
      });
    }
    // ---Delete
    public removeBanPeticion(id: number, removeOne: number) {
      return this.httpClient.delete<Banpeticion>(this.server + 'apibanpeticiones.php?id=' + id + '&removeOne=' + removeOne);
    }
    // ---Next Id
    public BanNextId(): Observable<number> {
      return this.httpClient.get<number>(this.server + 'apibanpeticiones.php?nextId=1');
    }
    /* ------------------- */
    // --- Listpeticiones ---
    // ---Get
    public getListPeticiones(): Observable<Listpeticion[]> {
      return this.httpClient.get<Listpeticion[]>(this.server + 'apilistpeticiones.php?nextId=0');
    }
    // ---Create
    public createListpeticion(mensaje: string, id_user: number, id_list: number) {
      return this.httpClient.post<Listpeticion>(this.server + 'apilistpeticiones.php',
      {
        "mensaje": mensaje,
        "id_user": id_user,
        "id_list": id_list
      });
    }
    // ---Delete
    public removeListPeticion(id: number, removeByListId: number) {
      return this.httpClient.delete<Listpeticion>(this.server + 'apilistpeticiones.php?id=' + id + '&removeByListId=' + removeByListId);
    }
    // ---Next Id
    public BanListNextId(): Observable<number> {
      return this.httpClient.get<number>(this.server + 'apilistpeticiones.php?nextId=1');
    }
    /* ------------------- */
    // --- Likes ---
    // ---Get
    public getLikes(): Observable<Likes[]> {
      return this.httpClient.get<Likes[]>(this.server + 'apilikes.php');
    }
    // ---Create
    public createLike(id_user: number, id_list: number) {
      return this.httpClient.post<Likes>(this.server + 'apilikes.php',
      {
        "id_user": id_user,
        "id_list": id_list
      });
    }
    // ---Delete
    public removeLike(id_user: number, id_list: number) {
      return this.httpClient.delete<Likes>(this.server + 'apilikes.php?id_user=' + id_user + '&id_list=' + id_list);
    }
    /* ------------------- */
    // --- Pertenecer ---
    // ---Get
    public getPertenecer(): Observable<Pertenecer[]> {
      return this.httpClient.get<Pertenecer[]>(this.server + 'apipertenecer.php?nextId=0');
    }
    // ---Create
    public createPertenecer( id_list: number, id_user: number, rol: string) {
      return this.httpClient.post<Pertenecer>(this.server + 'apipertenecer.php',
      {
        "id_list": id_list,
        "id_user": id_user,
        "rol": rol
      });
    }
    // ---Delete
    public removePertenecer(id: number, removeByListId: number) {
      return this.httpClient.delete<Pertenecer>(this.server + 'apipertenecer.php?id=' + id + '&removeByListId=' + removeByListId);
    }
    // ---Modify
    public modifyPertenecer(id: number, rol: string) {
      let $body: any;
      return this.httpClient.put<Pertenecer>(this.server + 'apipertenecer.php?id=' + id + '&rol=' + rol, $body);
    }
    // ---Next Id
    public pertenecerNextId(): Observable<number> {
      return this.httpClient.get<number>(this.server + 'apipertenecer.php?nextId=1');
    }
    /* ------------------- */
    // --- Comprar ---
    // ---Get
    public getComprar(): Observable<Comprar[]> {
      return this.httpClient.get<Comprar[]>(this.server + 'apicomprar.php');
    }
    // ---Create
    public createComprar(id_usuario: number, nombre_lista: string, precio: number) {
      return this.httpClient.post<Comprar>(this.server + 'apicomprar.php',
      {
        "id_usuario": id_usuario,
        "nombre_lista": nombre_lista,
        "precio": precio
      });
    }
    public removeComprar(id: number) {
      return this.httpClient.delete<Comprar>(this.server + 'apicomprar.php?id=' + id);
    }
  }

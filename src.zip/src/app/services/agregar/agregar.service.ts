import { Injectable } from '@angular/core';
import { BehaviorSubject, finalize } from 'rxjs';
import { Agregar } from '../../interfaces/agregar';
import { ApiService } from '../api/api.service';
import { SessionService } from '../session/session.service';
import { User } from '../../interfaces/user';


@Injectable({
  providedIn: 'root'
})
export class AgregarService {

  reload: BehaviorSubject<boolean> = new BehaviorSubject(false);
  id: number = -1;
  agregar: Agregar[] = [];
  amigos: BehaviorSubject<number[]> = new BehaviorSubject(Array());
  peticiones: BehaviorSubject<number[]> = new BehaviorSubject(Array());
  peticionesHechas: BehaviorSubject<number[]> = new BehaviorSubject(Array());
  usersNoAgregables: BehaviorSubject<number[]> = new BehaviorSubject(Array());

  userAmigos: BehaviorSubject<User[]> = new BehaviorSubject(Array());
  userPeticiones: BehaviorSubject<User[]> = new BehaviorSubject(Array());
  userPeticionesHechas: BehaviorSubject<User[]> = new BehaviorSubject(Array());
  userUsersNoAgregables: BehaviorSubject<User[]> = new BehaviorSubject(Array());


  constructor(private api: ApiService, private session: SessionService) {

    // Recibir notificaciones de amistad
    /*this.reload.subscribe(() => {

      setTimeout( ()=>{
        this.getAgregar();
      }, 20 * 1000 );

    });*/

    this.session.id.subscribe(res => {
      this.id = res;
      this.getAgregar();
    });

  }

  getAgregar() {
    this.api.getAgregar().pipe(finalize( () => {

      let users: number[] = [];
      let usersAgregados: number[] = [];
      let peticionesHechas: number[] = [];
      let usersNoAgregables: number[] = [];

      for (let a of this.agregar) {

        if (a.agregado == 1) {
          // Usuarios a los que enviamos la petición y nos agregaron
          if (a.id_user == this.id) {
            usersAgregados.push(a.id_useragregado);
            usersNoAgregables.push(a.id_useragregado);

          }
          // Usuarios que nos enviaron una petición y los agregamos
          if (a.id_useragregado == this.id) {
            usersAgregados.push(a.id_user);
            usersNoAgregables.push(a.id_user);
          }
        }
        else {
          // Peticiones de amistad que nos llegan de otros usuarios
          if (a.id_useragregado == this.id) {
            users.push(a.id_user);
            usersNoAgregables.push(a.id_user);
          }
          // Peticiones que hemos mandado nosotros a otros usuarios
          if (a.id_user == this.id) {
            peticionesHechas.push(a.id_useragregado);
            usersNoAgregables.push(a.id_useragregado);
          }
        }

      }

      let usersPeticiones: User[] = [];
      let agregados: User[] = [];
      let userPeticionesHechas: User[] = [];
      let noAgregables: User[] = [];

      for (let u of this.session.users.value) {
        if ( users.includes(u.id) ) {
          usersPeticiones.push(u);
        }
        if ( usersAgregados.includes(u.id) ) {
          agregados.push(u);
        }
        if ( peticionesHechas.includes(u.id) ) {
          userPeticionesHechas.push(u);
        }
        if ( usersNoAgregables.includes(u.id) ) {
          noAgregables.push(u);
        }
      }

      this.amigos.next(usersAgregados);
      this.peticiones.next(users);
      this.peticionesHechas.next(peticionesHechas);
      this.usersNoAgregables.next(usersNoAgregables);

      this.userAmigos.next(agregados);

      this.userPeticiones.next(usersPeticiones);
      this.userPeticionesHechas.next(userPeticionesHechas);
      this.userUsersNoAgregables.next(noAgregables);

      this.reload.next(true);

    })).subscribe(( res: any ) => {

      this.agregar = res.agregar;
      //console.log(this.agregar);

    });
  }
}

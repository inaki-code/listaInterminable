export interface List {

  id: number;
  nombre: string;
  tipo: string;
  foto?: any;
  id_usuario: number;
  ban: number;

}

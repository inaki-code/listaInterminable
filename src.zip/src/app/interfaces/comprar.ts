export interface Comprar {
  id: number,
  id_usuario: number,
  nombre_lista: string,
  precio: number,
  fecha: string
}

export interface Likes {

  id: number;
  id_list: number;
  id_user: number;

}


export interface User {

  id: number;
  email: string;
  password?: string;
  status: string;
  loggedin: number;
  name: string;
  foto: string;
  token: string;
  ban: number;

}

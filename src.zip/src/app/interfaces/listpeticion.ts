export interface Listpeticion {

  id: number
  id_user: number;
  id_list: number;
  mensaje: string;

}

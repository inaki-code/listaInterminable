export interface Product {

  id: number;
  nombre: string;
  precio: number;
  peso_neto?: string;
  foto?: any;
  id_usuario: number;

}

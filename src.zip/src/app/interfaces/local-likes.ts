export interface LocalLikes {
  id_list: number,
  likes: number[]
}

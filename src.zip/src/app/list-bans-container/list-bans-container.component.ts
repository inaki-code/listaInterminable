import { Component, OnInit } from '@angular/core';
import { BehaviorSubject, async } from 'rxjs';
import { CallComponentsService } from '../services/call-components/call-components.service';
import { Listpeticion } from '../interfaces/listpeticion';
import { ApiService } from '../services/api/api.service';
import { List } from '../interfaces/list';
import { SessionService } from '../services/session/session.service';
import { ListService } from '../services/list/list.service';
import { User } from '../interfaces/user';

// JQUERY
declare var $:any;

@Component({
  selector: 'list-bans-container',
  templateUrl: './list-bans-container.component.html',
  styleUrls: ['./list-bans-container.component.css']
})
export class ListBansContainerComponent implements OnInit {

  public listBansPeticion: BehaviorSubject<Listpeticion[]> = new BehaviorSubject<Listpeticion[]>( new Array() );
  public seeListBansContainer: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public lists: BehaviorSubject<List[]> = new BehaviorSubject<List[]>( new Array() );
  public banLists: BehaviorSubject<List[]> = new BehaviorSubject<List[]>( new Array() );
  public usuarios: BehaviorSubject<User[]> = new BehaviorSubject<User[]>( new Array() );

  constructor(public call: CallComponentsService, public api: ApiService, private list: ListService, private session: SessionService) {
    this.call.callListBanContainer.subscribe(res => {
      this.seeListBansContainer.next(res);
    });
  }

  ngOnInit(): void {
    this.api.getListPeticiones().subscribe((res: any) => {

      this.listBansPeticion.next(res.listPeticiones);
      console.log(this.listBansPeticion.value);

    });

    this.session.users.subscribe(res => {

      this.usuarios.next(res);

    });

    // Listas Baneadas¿?¿?¿?¿?¿?¿?¿?¿?¿?¡
    this.list.lists.subscribe(res => {

      this.lists.next(res);

      let baneadas: List[] = [];

      for (let u of res) {
        if (u.ban == 1) {
          baneadas.push(u);
        }
      }

      this.banLists.next(baneadas);

    });


  }

  goToProfile(id: number) {
    $('[data-toggle="tooltip"]').tooltip('hide');

    this.call.goToProfile.next(id);
  }

  goToList(list: List) {
    $('[data-toggle="tooltip"]').tooltip('hide');

    this.call.List.next(list);
    this.call.callList.next(list.id);
  }

  eliminarPeticion(id: number) {
    this.api.removeListPeticion(id).subscribe(res => {
      if (res != null) {
        console.log(res);
      }
    });
  }

  banearLista(id: number) {

    for (let l of this.lists.value) {
      if (l.id == id) {

        let newBanList: List = l;
        l.ban = 1;

        this.api.modifyList(id, newBanList).subscribe(res => {
          if (res != null) {
            console.log(res);
          }
        });

        let banLists = this.banLists.value;
        banLists.push(l);
        this.banLists.next(banLists);
      }
    }

  }

}


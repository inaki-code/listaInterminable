import { HopperPipe } from './hopper.pipe';

describe('HopperPipe', () => {
  it('create an instance', () => {
    const pipe = new HopperPipe();
    expect(pipe).toBeTruthy();
  });
});

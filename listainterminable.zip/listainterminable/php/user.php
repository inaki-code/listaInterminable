<?php

  header("Content-Type: application/json");

  include_once 'db.php';

  class User extends DB {

    // Función para sacar todos los usuarios
    function getUsers() {

      $users = array();
      $users['users'] = array();

      $db = new DB();
      $db = $db->Connect();
      $query = $db->prepare('SELECT * FROM usuarios');
      $query->execute();

      while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
        array_push($users['users'], $row);
      }

      echo json_encode($users);

    }

    // Función para crear un usuario
    function createUser($email, $status, $foto, $password, $name) {
      try {

        $password = sha1($password);
        $token = sha1($email);

        if ($foto == '') {
          /*$foto = 'data:image/png;base64,'. base64_encode(file_get_contents('./imagenes/usuariodefault.png'));*/
          $foto = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA5gAAAKTBAMAAACOVrr5AAAAD1BMVEXp6OdYWVv///+AgIG2tbQxROr5AAAgAElEQVR42uydC1bjOgxAjcoCcNMFiLYLIAkLgJb9r2ma+CM5FChDrcSO/M6bd0Q5Q18v+li/mL07aNxRsWRRPwmFqaLCVFFhqqgwFaaKClNFhamiwlRRYSpMFRWmigpTRYWpYhAvB/yXVCxYVJgKU0WFqaLCVFFhKkwVFaaKClNFhamiwlSYKipMFRWmigpTxRGmFgO1OK2iwlRRYaqoMBWmigpziWII3umgwixTfPw4931r6TR9v/s4KczCxMdzQnFy+v4j3rUV5nJF2OPHdxyZln6YAajCXKgIe3Pu7e2neX0DhblQ8VckA8+Twlye+Ph7kt6DvirMRYl4bu3/n6Y/7RXmMsT9sf8LSqeeL+5vq+BXu+iC3rG39zgXnFqcnlm8E8qAU2HOJ+LfDWyCM/hOhSktwv58V5Qjzre9wpxB3G/ujnKMbAEVprAIj73Ncy6uU2GKinhubbbTx9KZwswv5lNLf14UppiYUy0T5VSYuUXsbf7TvClMAXHTWonTvCrM7OJZhqUztQozb8rHyp3mhAozn3horeS5mFqFmSt/t5FlOZraomAWVLI7W/kz3lG0OH13sbdznP6kMO8u4jwshzBIYd5ZPM7F8kKzU5h3FY+tne80L6gw7yfOypJoKsy/i9LXyytnhwrzLuIM18vP5xUV5j3EJbB0NBXmX8XDIliONBXmH8WlsBxoKsy/icthaZsnhfkn8bgclsMNRWH+QVwUyyEXpDD/W8TGLus0p+UnWBZao8Pe2sXR1OL0f4mwPJaXc1KY/zOAcF4iy6H3QGH+VlxEEu8qTVSYvxUPC2Vp7eteYf5OPC6WZbigKMxbReztco+7oCjMW8Uls7zQBIV5u7ixyz69wrxZXG7wkwRBCvMGERfP0gVBCvMGsbfLP0MQpDB/Fje2hNMrzBvE5TvM4DYV5k8iFsLy4jaXB3NhRTnobSnH3za1OP2luLHlnF5hltQn8sN5UZjfiX1JLJfXRbIomBtb1ukV5pfioS0M5mhoFeaCBt3/amgV5jVxY8s7vcK8KpZnZJ2hVZhXxL5ElrTGS2EycWPLPL3CXNYKir8ZWoU5FftSWbqRBYXJxEOxiun3HShMEgtmGYphOgXmxbMt+TRanGbisS0apn1RmCT2ZbN05ROFOYoHW/p5VZhexLZ4mEMfrcIsp7fyx4S7woTyox93OoU5iOcaWNoGFCYUWvm6cj1BhVn8tWSaol0zzFoUM6Zo1wyzGpZBNVcM82DrOa5MvV6YFSlmqJ6sF+bG2tpUc7VTYNhWBXNI6q23OF2XYrpxhbXCrEwxnWquFWZtijl7g/uMMKtTzFE1VwqzPsUcVHOdMCtUzLmfz6jzCDnSQGuDWaViso0yq4J5sLZq1VwVzLZSmEE11wSzVsWMqrkimNBWC9PXNVcEs17FDC0H64EJfcUwnWquZwrs0FYMc7Y5oplgnmtm6fZdrgbmsWrFHNrbVwSzbsW8nBXBxLZ2mN16YB5qZznTUNgsMKtXzGGUeiUw61fMmZ6tMAfMfgUwZ5nwmwGm/L2kbaz4z+zWAVO0w6D5iLv8H0WBNrgKmIKf6evk/1CSZ7cGmAfBIGT8oWjAIPj3IodzhnFNeZitWAgSfiSGP3F4N1LZpxnGNcVhSqnGsG77oo4XlRwQuj/Gf8UCsJf6p8CEwh93affGFbx6ehHfZVSz/uJ0K2Nih5+K7g+vkYOSOlU1exmaXe0wDzI64bXQxz0jxug5xWi+1g5TRDFd9OpVMmD0/nN8RYbmWKOuGKZI8HHCqIPowx4kpMMrQjS7umFuZFg6dhgV0gU+45ejvRUKgSqGKaCYTyGPZhi5mDaIVOEoALOrGaZA+LPbB4fpgx+ysAhE9fLys0gIVC9MgezLid0vozomLnN0pYNHfZews9XCFOj92aLBxMJGnwkTnwkSbrOrF2Z+KzsWnkLsM7KDREU9R4/3WcDOVgszv2KeYMz7oOH4MNpW0szxv/mT/i4VVSPM/FZ2RzfMeLvEaHMx+sxgePObiq5WmPk/Op/vQSB0aOI1M/KFYHnz24qmVpjZP7mnoJhjocTr45i+QzCU16N8Qv7Jwuatzimw/JVMcDWSWL2MoSwyz+m11qlofq/Z1Vmc3sh4TLqSBJIYS2BI9ta5zvxes6kSJkjkCzC0/PjQJ+Z7yHN6nxpun7lVc3xMWHUwsxdMGmdiWa4HKHZFKp0gGV6JpF5XI8zsVrYL0Y7P1wX3CSF/FwHTK5fwQcjO1gUzu5WlW4evWXIljWl2Fh45bX2QsbNVwcxuZZ8w5gtifp26CyBJBzl1dV88ytjZqmAe8oc/wYIiFUZY3w/GtssQEzmk2a+/TX0wJcIfnhYINxPKBiFlhIB9JXsI5OxsTTCzW9kt7w2JFxHWZsmKJ8jvKPkrYV1tMLNbWYCYJYjZdJ52Z22XGOG67xOxszXBzG9lg3UNKQMIOQKijCzn7j0rSNhZqAtmfiu7H9J2rDsEDde/YFdDExDr3gOZeLYimAKxLFW5QiSLPBRCxjVWU3whTCJvUBHM7MUJNCatZAJ1FwTfiZQ5SK6e+fMGUNUUWG6YO4phoy9kCTxvVTFJ2sau6PxVzW1NxWmJT4vHNZTBS66evHOWZ2uzF3Rea4J5zu8ynRVlpcuYg3XBLVdMViobgee/nGA9MEHAZUIMYNOQFnirCLB0u2Hdl7mdpu3qgZm/nI9pJTM25kFM02JCD1ghRaKo+VIPzOylzCf85BOnGVluV8ebJsR7psTGeKwFZv6GkW0yVBuTdgBJ/i6pbrL2LoFBheatFpj5J2y76yOY7BKSvj5J1gr8unW1wMxvxE5OATEdwfReE0NIC5+T8IFn9l+3phaY79lhwqQ35MqcCcvfIR/zc7Htu8K8TRTYyYUASYLOKyqwgT6TDJtgYn4h/90k2NnSYQoN8pk4QsJmM4HYJVWTSbLWPCvM28SNAExIhoVYITPtLoAk2EVS5fwwbRUwBaYyaS4BWJcs0QXf0MXLYT4H5PRYwnpAFZqZH+YTFS9D/3pQVDCsnAJJRMRVWWD1yLaGKTCBDSNbMGzdIRW4zKS1KwC8MpKb/02+1lCcFtjjtKWGO+Az8EEANgWG0dQmBTIr4NjLh5k/uTLARK96wOojLMCBtG02Oe5SI/Au3yrQzPwuc0gA0d2DjZuwoUyk2yUw1YxrZQRgduXDPIh8TMmcNIQ4CFi4E2+XmNZTpPaOXGLu8mFKrERnc9EhTqUVpTjVUqBvo0UyrZDTLBqmyH59ANaAN7mDmJQq0JQYUgZBYvWac5pFw3wU+JBschPhjZaYkOQZeASTbEV8F3KaRcMUWeON6eYf7iORSEKageeJPxmYu9JhvsvANPFGielILRla4CvYgOJZV+x8sDJOs2SYMo+kQd4VAjSXCRTYpq9Oemkl+vO80yxaM1spzQTe50N7C8ICErZthLat0Q1GRDMHp1kyzGcrYr6STWpJmiC9U044s7BX5I3uyoYp83yh2P6BFOXQQF9o1IvBK3L36WMlod+6kmHKuMyGKSNL2pGV5ZqJwLu6INxiRGBenGbJU2CtlfOZyPN3zlGioZ5ZNn+CU58qpJnZt3xnhSn0rEzkM9JsOXtkBdP259SnopRmvijM2yqFrC7CUjshKcSH+YA9xAYlAyBrS4YpY2V3cWiPO8Wk9RInI0Op4oppZqMwb6zh88pJ1EsEtgMIgU8PUUuXnGZ25cI8WiHNZLcSSuilc0SfdZQZWVCYC9iwHzWTaySGfyBeP2kWM1xJYgrQqfOzFTQiRcJ8ENTMMDaEwLUSaTiTNbhPXOYgKMyfRBmXOd4zgVW5QkqAtsuyAeo4Kx/uLCiXAfKlV4X57a87hs3dqTU16czQ5yQ87SeRgtmVClPIZcaNTuk4gon1TeCzJnFwAWOlBeSiWfuiMH/UTD5VGxsLqJICrBMTp6UUkNTM4DSLg/kup5mYxjbMIwLbwYbUWcvn+QSj2XJhtrIfELCMHtAtkq/2Zhkg5E86kdNMt7GxPJjYCmom0MJnimyRdRUAbyhBum96H/sg9V63ZU6BicU/FtmdkaZsTdpIwtcbTEdNhHqAXOGkyOL0Rg4mf6gQ5eow2S2CSeoWk1UWKKeZTZkw3wVhGjPpooxPvUBIK5o4nQJzsZDC/F5s5WDGVewTIwppIZrv3Ade1wSQe7OnEmHKxT87fvVg+/GQ9YiEvAJ/7iK7ZsqMUfjWkQJhHsVY7j+1hkw1E/jutWSJjI9/JR4/XTJMsU/nRHkCZIENggEzWVVqWK16EimJGdqmRJhiIQWyR/LhFx4zfRUngdJI/UFhfi3K5X8weTgfQvKMBGSztWnrCK+WXb4mlgMChfldaZqtF8FrjhMnLhWo4wtjgfpZ1GmWBROtmJmFUN/CxHr67Yi0VCa+YHgbtDPAqDC/EZ/lYFIF82p3JU4HFJJ9MmEuF8Xe8FN5MMWC2YaeXAuGDSLw/F7SbemVGA2t8BLNzjblwZRN5pl0rmuyxwm5NwU2Vo2GHjmuML8WZZN5k0fwsQfUsM4C+r7pI6hFNXMMZ8uaAmulNRPSR30lT6tBA6yIwp+KQTu65EzJtrTitFyu0/IxWkrJ8vIX2/gTVlV8KmkKwuxKgylXmQ6NGLxogsk6LjTAnkOd5H9IfQVh7kqDuZHUTIhdIsZwJzlRUnMl/xP7SASLYEPPUlEw30U1EyZdzcAHT2LzCE7yP8kFFKzC/EIU/D2/wOTLQ9h+fdo+G0duef6HTaaAzCrEcN4U5nfxBPeW010jMS0A6SNQ2XC18DvelgVTMJi9wMR0CD72zYYkz2RZDFsaTNPWIPqOi4IpGMz6De2QNEKzJ0bxLC1O7ik0LQ+SMHeoML8zs8DpGJMk32mRd0zt8Qe7+duL4DtuyoL5IKqZmCbm6PkmtMQbr/QFkT0Gkecn8KRVQTAlo4kxO8ZWzNLzTGjPE6WH4tgtJin4y5clNdMozC9hsgkTdiVhX43rm+JNFPmNZfwGSc08FWVmZ9FM9jzMgJAtLp24Uhr8c99/tKJvuSCYkjcT+0SBD/DULKVjMb5IK6GBDyf8Y+9akBu5dSCE7AGszwHgsQ8QqfYAa2fvf6ZYmiHQzZGtTYoaDi36vUpF661YnhZIoNFofLxaFMxTS1NgL4uCabTQJBsmwQ3UikJocIU+p0mLgvnUUnN6UTAP0QZxrt1oK2oMb44JD1rNpKHcRd/yviUwN8uCadSYtvmQl9IsNRm2p7//3MH85OXbok/GQPtsIIg1GAzDvDX5jhBN2yPzs5fHhY9ZvCd5iAh7nDAOL8Dm6vKR6Q31Dua1yIRZIZzxwkpE4KA1KkTPf3NZME/tgLkoNeaS9rgzSUigQsyP4qrUoOSlg/nJy0XT/DEyyaIABM++etpZhShKSPa1LJi7dsB8WTgys+0IMAxvQkvhgSkS9JFZVJx3uec7mJ+BaaCDTakrbJGC2T4cy8Veii5nNwIZeBNgbhaPzNzWh+24Qr8e38SBzaUWaDYJ5rIP5pznGy53V2TcyVoEmSIFrHXZPs/WfWcbAHPhB7Mb4HaEbcW8jU9Yym6ZFfiyb3lcDd/BvPJ1+dnKmU3sWwShiPJWk+kafR2GpW+GVJusH8ylP+Xb/e/jPtUfRhv4yLkUp78UapTn/c+37bcA8w6NtddthS8DUxFFTxh0spSw0NPQJbxVeLunVprTLzXATIbPyOYJrXujrbYxjqJL5z5TR7OD+dW5ZZneQMACUZnDi+LTFp0yAdagFTA3NZ7ODiQgUZGgsYHSLDx4r9V4u/tWwKxxB13EIyG0nFuOJGyVjaF1WcF2c2AOxypPB3a4Ae0+SkhCUMJV5qJbMGblVAfzFqlnmf0o1CcGDbJwZ7M6YL53ML/4UrKWBfc8KFcsK15UK1UmzYBZJaGIMhydu40aX+Q6aylEtc7b3bUB5mulpwPCETAWMaHNJuBpkC7NSp+9DubtdBZ10DHipYrkLU2mvPTI/OJlnYRiuzdB0x+DwTChJqbBt5Z0s7xGAa0ezEof9e0l/KZTVHkGwaAfDQXo5fff1Hm3hx6ZN3rUVJWYCm/ic2uDZLB3+f+x0kHSwbyRzprTOgbjYLEqVWDyNvU7t98IzPL9zLdKj2eXLkxYDA7LLwxHbiNgX2uBaS00p2udW+M0GHuQQrs6+tTJP3iEttYNv5UO5pcZkMHeRUdxGlGYbYmfFjNuar3bXx3Mrz/rpNIycSdEh5fchE2qkXlTvrZ+MGs9nXMGROEHjgWZFX8sIKr3bndNCLqqPh4Nm+eUsYpbmCrqf8a/+1rzo7d+MH9UezwHM+xausVIVCXZAIpWI/NaAbPeZ31ruEJq0ncZIst0kC0+/EV8Xgtg1vusb0nNHgog75/g9tvpAH7rYK4UzFM44hmctcDJ8mI+laHemz10MG9kQIrjCSPfruBfQEovq3snjBzHysF8rvp80HsUxHrwOpoqZlrxzW5bAHNT+fnAIJjihImRedcEaMU3u+9g3mJV2K97vpSGINV6bFUjYL5VBPPEw9MGCgPDS1OTk8H2ex2zxfuZNcF8EhB0Cdh2K/WsrXb/6/LVQnO64smVrAIUpbIGe22DQhgzo+cO5nrB3Gp4UGATOkA0sBmuSRlsRxl0B/NmX4kWnCjstQ0d+3j4bqt+8BoAs+oDcukINk0wuY0ZXK3ZMrm81w7mH9AqsbMP/EfAnMvDtuqVedG0dzC/zPdjREHJfwRs8xIvVEsy2w6YVhfMd8GDlUzbfSGYreLKbAHMuvfQND7knrLKxaWFwOsj7a38udt1MG9emmxKir0SWPxVuyXQwfxTksz7l6rcxQSv4PN45qaDeeNl5Y/7mWt3WwMuL4ltP/9j28G88fKl9iOKEekYVwhkLcyBKl+ZlzmwDuYfVJrC0i74A++i2HMHc+1gbg3ksZYJfwzXu22+H5il+5m1P+9eaabyhGanQ7FXu8ocz5CVN6erg7mLkUwFKVc2Pm3Vr8xL4t3BvJkBoaETKfJCRPvxL7Xf6H79YG5WE5nupU8WiGFo0CNz/WCeEDGV6IThGkbT+ndmj8z/wM6iqJ1XpGrd0cMO5n+MTEPLEeU8aHKX6cfszZdv9UsTS9O1Rs2wjNXrYN58qSsAM6a8nCswUdhUM/IKxw5mC5EJk0G8nQ9Llh6ZDYA5Mxxxd0uD/aimPTKbiMwp5zGZ7xLHAbHq71T6nXnzESlNmXgSqypCbrQdzPVHpgkO3GZfCtLLDub6I9MMJOyRw15uTxNoV2++H5il+5krSCtMaMui8L/6EFh1MNffnD6uIDLD1TLvgBnoDzqYLUSmglseJbQ4uinVZSMdzD+gr2HIhJvTRrtRpYPZAJhhW6nXElpXuXcwVw/mwdxKzXy+ZFouDvaI1iOzCTAVpFvQDIOX4yH82sFcO5g7VOK5rMDiGvUXHcwGwLysyMwrTe6djA2yDubawTyBaFbBdyQGhxKdpx3MtYP5joujoh1mkMaOpk5SvQe2fjBrc7PKZ6sKjr4LLAir3zbpYN4sM9N6BHVjfeXJIQ/PTQdz3WC+I4unsAssraZJG8TPF+qxg/n1y7of9xOsR0hjX3qtuXn5pn03ML9Vc/rJsx3LGtTjZTlp2RPPV5k36EqDL7EcwPuZHBHB3xtnT+o6MHTd7A0s3f1nLD+A8FFYTTymQ7Vjs6vzPv/6e5CY2EMl3rSphlYruHr2tYO5wlmT0wDJjcYOsECX8Z3aKGrHDubawHwHlTOlQWBloGBCEoZd1aqpDuYnja/BsLp0F0QFU0tw0BOBtFaGvyrxGx3Ma4/lfRDB3cSGZF7KhWBxguJOjA807a2DuRIwfw4m6sv4sqMU1psI2pW6LujyneHHsYO5AoOKn8Pg5yuYGYivl05lCSxOyBamnoOzApwdzOzT7VAqz+wpZrMaq4ohUlOJMoW0Lg1nj0x+HL+mH2qgEplnswoXqiPt34rMVgf7Z8mkbf1gLme39lOHkOFpbvsDi4aC4wOKT2DNeGRLS562B+lgTk9iDEoDzZ35PltLI0KK525QP2RyoMErjL+M/XPsYC4H5v7XJShTv9JwBkGBA9IIPyhCNbMfkUiexqj9CM8lSpWn9U+BvSx0vDo9N/7Pxkk+w0wH65HIbRX7Y5EJsUfQYL/v/nt0W+/t78vPS8eo8pJ3mKcN3sBikChNgZFlF9aflsar9f6358OD+ctPlQlR9Af2WiMSHbT/8SLTpdBQrAD4qY7R4fXYwbwvP6AOx+X09JBDXUFKdFK5ooo3puD8NB23KaOajuj7lp4NgHm/jUMHHbLkNN8MbirZzQj/CHGQxra+iFmN+jP8Zj5+pftVnqcHBvM0pLNVMYDwtET6J0DSMIS2WGqSXZrA/fFcw/3O2scFMzVGIOxgTk9p+Z5SskrHqMUpbLztFth3TSXriP29+p0Pe8wehnCdMOOQzB0OZ8kqOPADCZ8cvGKtZvafdHuSO/U73xsA83gXLDMeNTYPkzWMggv0tYlprkuCy0vZrEZsaqRBoi8dzJJY2lhSGnKsn3+BbmtSsCcOCJdk6LywQeLAR8fuNJj7mGAeBh4GSrRbFpgGt6exVkRwpQndr4L9MqHFC7Sp+g6xOTQA5ts9sDTMba7ecPltRwpo0F/y3iHInYSwTXxuqlDvQFM+JJiaV4sxYECBCfZNdDEqSzDhM6E8eQJnLdlHj/ze5hHBLP1Lv8e5p2QIo1ctYaDWgCFN5b22QsmtwuIwCdFCiunpCC59f+xbALOw1GAXbgSGSahZdmnmzLlBDGouOED/kRzBiZUwum6t+CKUe4BZup9ZWDdyTmQ9VfHwtCuRyf0PLDwgFA0WETlz69QtIzhreBa+Nm39zenC3emg2IzmfuZ3ZjZFEs7BZ6wwDG2sc8jkQCKGTZVPcU+Ryg5FHR4OzF2KG2p2YFmRPXJYmqBEFsBEPMktTfkcBqIWI/Nyqhc9aA/yYGDuB+9xKTS0mCdH1wJYmqCCzREDMjA1TkRxGCUoJLANgk7oWSpdMrl7agHMHyUbC94FsZwzp31QfpEaczkWt2PKaiMh8qNacWsG6vcyKcIHmiUPnRbALGh8tbcAMkWMqZJCQEMMFGMlQoujIvWBgkUl6614mWnO5cEPmm7U5w7m/w9MYns49CjxNM1oViHOwKitYjBTLeBgEfFsoM3kEYeSv1wDYJYzZNmbYafRcxkTni/A5NOyxeEGtAGuE4/18JKFamxpxEtTx59RsIp+MDB3FlhgvOGtqJnjM8koE+tjVGwYR6JxqKJQkzqh0x+V06Y9FpjofpfazO5PAAMjSKCTwJlovmDnRPK+CFGFiU5isUJqiBWrNaWJO7PUr3sw7/Yz70YJJ1YrphlGU9OD1xQrRaKl1pmkZQsZS5u8o8eDthwN9FhgnnBiREFigE2rPIkRWLCIx7L/HcsjEaM7XE2dmpBMJ1asOrEmwNyU/G0pLTWYOVCZOR0qXJuKWjyD4lK4g51gVuq6KA/jGnIIm1LZXRNgvpQ6ZcdHrMTkJebGWMJlPMkVYiFD7m9W0KBRRUYSmLO0wO6f0+uXDub/KqpdVGXKxQb2rGIkIUt8jL28CSVR7Ktl6j7TjNelBk0hgvZwjzuzeD+zlMACFZE0QaA5naOStastbc9UkhxwRRPkQFLKuoSBlvlJLvwrk60/lX7sd2lOl5o2GTnTZAiiSj0wGA/yypKYcuLblQUhsfGEhCUaRhZxd87lDIX0I6c2wLSShYnkTcw4Pl2npdzkEMhvjMU+Ntc5Q3oEexbSUawCor+pCHp5KDCP5a5MuCknx1jNtJE4SKSK/GzUjZ7bJM7dQu3svUufKWIS6IrQ6JHALKN8OikR7PNEBoa+cIKWG2TKWpFsnlrmrgfcxQ55OwiNylSa742AWVJgCRlJUloJRCC2qYxl6dFTxuXT0GBJ+zUTESQ0C8i5EpJ+ZTIgbeSYLUIBWdSO4JemeQ8Su1Q6n6E14XqGPwG5M7+6+2WeK6Egt0gGtB8aAbPIL8u0gKkSBZQJ8KI21KyQUS9lcKRI6T+A97BCL/PKjVlsvV8zYL6USWZV8oMzz0iJtEEpMwwd8HXK+oKpavVGjCMm5JWoTA2VEZM+EphP1PwfKaDISE1Z2iVZZ4tOUQOpnVypNjlYQ55yZbhMi633OzwSmDvJZqA1n7IEUtay/hdaAvFsu831XrN5sfzuRaHRSBYVI4AaALOEPu8EKKhnsppLRixLPac/MgTelNzaDeUl5v1OmempeYQFZJslhECnVsAsUVW/+6mWLdkzzQghBbrONGtAG/SYhfIdQ2owD3fN5SVYwhapTZoBs8Qv69KbVCj8y97VYLd55DAW7QEcSwdAJB/A1esBNtr732ljW98Q4Kj7mhkpu2OlfXmt679K/GZIggBIWu+3xaqeI3OFMcqe8twBu3JZ5A561FW9uf32G/Re5wcK5k51WkgqUMqGorjgOWXErQ20FY1a6LYJdvXPMx5Y1k3f/9ygnMVdgnn7eeYtvFb27YpFr4q1aVYuE4pGXjbvWRbdlwtQKofWnwJTW+fxP97mYV1hOI0bSDKetaHcuHLMsT9DxZThuhJofVMSKJVcQmks86eGGp/ShtiXa/gGvck6wZx/ck9JUvYJoxEGtreexithXMXloWNsnUDr+dVBCoVlVLQMj3QyjzcpZlH1k0ShdWwikJTSBlxYm/0HfaE4k1UZMmXTS7rkZQEW5ouCp1gmmPPXEHJezFKRFh2CDlYMJDe7/c6jPTruu/p+XWIGNblUm77pouC0TjB5i85EuvkipnUFSpo8ezvBxumh+lkKaRO90iGK9lp9LFq65fzc5HmdYE6Pp3e0FFeHXOzqlIyMrUtQQaYbfsPm1FAXKASKiQV9lH2Ducn5gYK5bwQtk0IzlJ3FK4fW+kSFc7JXFZo8M6+meLpM0OizmY9/O94gjSwTzG836UysoWcvkaUeWiZfICsfFyVatQgAABQsSURBVJWYd4VLE2C5tWhW3Cs6bjA32R0WCubX6WBSmas0RWWVX4pTiBCfpeCB5r5IK2gjoAhyJ/c2i6Zsw/cfKZjH+ZPZzpvFi35MVVt5dRcYjS/NhhBERXQBU8sbw4iuQLmBgHr/SME815qU4Z7csBsQchtDyF3wYSXVc6+5HdpiMPkGobgbtsAboAZPKwVz9ho6Q6vJjjWnGxWVyxNhIrEIFaqgh4EEw4UWv7SuFZUJBsyiBqeVgjlbzvrwScC26lApLj/aDm4HCp1Rkxgiig8iQjUmrQ5yKacA87OowfMjBXOzjRB5yRZICmwOBxbQE0sgxXDHstQ7mMnqakCE0BZMAfH9c5OoAe4UzHswDabV02KfRa9EWA6aQn7Zi+oQBVd4tgLeykUc4Qv7IlKGrYLseeps3Oltv89Pnds3sKPC29a9t2oECsE5C4SSYLNucaNLqvuFT0XpdM2o4NE8dfb761spmMfJF+teA9K9o5LsqJ9QF2iYak/IYSgXLRxhL5wDNmTwYnWCeers/pGCuac19CK8bO912seI6B0F9TOPfZiXiOKFtgS3YwMV6uwtTubrWtfsHEHvSWWu8B5CRs/GzTL3UTNodzPwSm6m1sad+WkjtTvza3I1xvNawZxrxJ7opCpq17F56yd6B8l5xtczf4kcQ2Nzn2gKltqx1gV+ziLCrHXn6ZGC+Vx2zzpS528vsqCF50UvdPFfVmiwdqy0lAkTn72/PM620Utds79NXkNVA0S1U/8oaHNjLRQ5UEPgwiiAizPRdnEKzFuYuZYr8/v/mC3WlwrmcTKYnasLiziENpciDZrLLkWGW+ikmsb3gV+m0ctW5MsOv4L5z7l5ltyqJX5WO4AJF9zCMgEdmWBB5pWM4ior8hXKGnnlO2yT6lk211LBnLqHzoXZqDRkJbIKSIAq8+lUJCh4blS/JtoU5kqrqXOa2YtnqWBOVUCnuLKu3d3xneusByd9ghu7Xa2/c7L1ofkMWz8l4BBMCiGOJe9V8Cw173GCWbo9lrvPz63zChjuCx0+uDT8vSxUFZ4BFRcqSXP+5cVywfw2FUxLmaUq2aodMcFTcy7NhPkQ2J3JiKJdQLHqUq5elzTf/vltrv5ZK5hTFVCEWxegk+tdI7cagkMdZkVdAJ/8WT2bpEESLH4mmjT/T4N5n3nmHHNkWzUiDEeld9A4e2oaQgtvYvB0qR9cJCb/kT2YYBfxRs6cCebrTd/nnzCcnmOOFIYjdC5MxLWe08y8YKJKRrEjRXiBqiVz4nx5daP3qpkZaJ7WC+YM2YBaWcoqb509UrUGbk0S7iMjc61y11a/ps6Oq3+WNnHht1/B/AGigfIK2I+5eiO9RGWNVWJAe0HRFUkXqVj74wwV23UyPgPbHRYM5nGqQmjGL2LabEieZkWEimchwzIY16fILDtKAcPu5QLNbo/P+5f/CuaP5UwtW9UoTeEfKv5DAQwSMaDZVKKwNaOUzLaSBlsKbUm21c3jwdyvGMzx+e2+1a4USlZ/yUqOdJqAzDd1qlKwOnPrptDnsze5Mnq7/G98nUuZqwVzPGnuaJwdQ2J9xRuuLk2Aif/M3CDcq51e7RgHJb+bCTa0RHv8Fcx/fjLdSMlAHacNhFhvJ4pKVwxRuQduvi9O+tH/6Qie2/cOn8wdlgzm73MnUyjpqBZa8NEWXf5DA1p13VTxai8jU1+2yWj8TMj+octDcJyrf5YL5vDrfXL7u8aD3Zg7CbYp6x0690rXEefGSukLs9b3RUWFv66Pz+Wjrw8WzN8nrlmTNFdsLXFyVminOPHTsmzGrQw2oQZ9tJPdSZMuP+FlLmUuF8zhLQpP1L17gUb3Ybf+i3pjsp1jWkXLK7sywl1lNsqmF7rybbqJ8+3vRwvm8Mxv7yMqP5l6mmhUHvqnaRtN0PR5EE8++rCbZTU5DZa1tD0cTKwZzGHBybPvmiUqWCc2a6hyPWiYy0gbspCv2G6xugezuom3HPv+417mUuZSKrD3D4/DwZRak2Gdf3HtRrjWFqbiM7oruqUJNCOg6ustOZZ1Ifn4ydx66LWG098/fBk/mTBBbNiq4hTmFUMgm0qHK4haNNSvQqlfhh+gwIlMpsN2YUzwf5YM5ihs8FyV5zS3AZa5JLDJmiNdvKk3s+Ds2ZgE/EucPeIW4MqUvzxcv4L5z6mI6ZPGK10/fXkCFLnruAZbYFlgWWUW2TDMcIfm6BZGwx28dXaxbDCPwzkTOshC25v58VaLFox1dTQpYxO/md2cm+67HrhC7KRnZ+i4ZhJ2fqBgKoPdSJTmBiQs6IsMBU5xvrq1TeBB6uoZ5Y8QSpWFcsMuQX0ZbqFXDeYgbPBsi0coRHbHVg3kkVCJs544dtHod9KVIu0KCkpo45i8Jyb2Lp7WDeZg0jxt5FhK2hMOXkl4SfII3eOus0mbirTsBx2tGMkZbk2aCFGL6CCl/bxwML9NVbMaH4SZPTcPEYdrYOzawhrwVTXiO0tHf3z2GbIrWQSfGIQMFg7mcfhkiiGageWFV8mNHKk5jaVZzA6UjGv4Q52uZcXk4J5sMx4L5v7xgvmsG0xFey49hfvdRTfI5lW8nO6Gl9KgnK0J9GC8BKg+e/hknlYO5ljSfIbfkKWF0N0GTAfKssWLdW0COlO9KKZ7+oQgV/yp2CTBhwcM5rexa9ZmxChzCzo3GVG8vc2pll7+tBNL2z+ua/hYxfUoj9HHFw2i7CsHc+iePefhgE8hUd9dKY7KHKTMtvuNXl4Gm9Ks9bEoUr78Bb+C+SMnU5UItle2LqZACB2zLETY7l9pMpXRHvCz52xOHVWz4b+XeA4F8/XewbzjPPPtr5GkeUZRF1jSpMxUrNFg2XuKun/Gti0Igk5HeEONhHynsQzO/hyq7O72Pt99OB2Dr/mU7z6uJE12KhM/xLJjCsrEQyit5NJZGsOdMEmSGkc70Xasmt3F2sEcYhucQy1I9SCVne/0e5XOxKQ4UmxWe72JG9wpXMcj5fc3I8T3mI88pVw8mMehk8mIsrZEouW2+5pDyy5ThkvCVMGrrHi3CGYotGu1r5z4kZP5uvrJHEmaJzXbNwcZ2IEL3/BdVsP7gLvywpwVTz2VqITOrcJScyiMpcy1gzlyHT1HUQbpXhFp6mmMK7Vryr2JJjOyJSXSrBQgXRwv9GKADkMPYylz8ZP5+wgCJAZM5iphIiIqB6sSps2/QhAloqgRYGcZnmyv2ya+f2pQqbh2MI+DJ9P8PeielIwr7/FFPJnubOy9u2oONPy+kEM6blBeEBgaTr+ufzIHkua+tYXQ21R2k1xaDn2T+w0zgr82kE6fClvN4IeVXcp0Uu34M7p2MAeS5s5MuJlHAiKKZmevRd1KoguNy91bi1Mo+cuVKoxylbdT/HUsZa5+MgeS5iGcatkJFPT+rc6wMOmmyKN9SIY6JC1NC/7uOh/dUnMRKq4dzJcR1CDdl6FHk/B9GGFNiqxYtAs1mwsy0yMUe+gAJaPk1aOJkWL29TOczIF79omFKaDvc1l1WYYdTsVyFmV0hZUe0RADbxr4h3o0h57Q04MG8wsT65G1eka0EoaIAnosg5BiLlHqY2EU1WNs1OftatjifPg6eMsuH8zjyD2rXs00hJ3u5wNfJGRnTVRbTFKI3aj0kbUQNRkuWdJSagD/+SnBvO888+3DP4aak8uFWj3woER2CpEO3e4h32VBW2+Kyp/t7Uc+jivSX1jGMgPP5+nu7/Pdh9NvH47csxCAvLo6OYlLiHllwuzwbVyhGlhPCpVGmzs/w2mdQ6/o/DmCOdKc7KkM8sqqsrmlOTRX5wlqF0qxfhEj4BJgcTBlmMVam3iPjIIOnySYI6/93MDUNt7KIVY4QqerTzrxvGFI0o8Y16DH82nKPwdqR/ZgvH6WYA5xRw4mJ3HsALkzL3pQQQwpjWAHvVjdZN8nbfVh0TVE35+Mw2/jvhTrB3NoKr8/FHyOFy4ybR69ndhNq9U5i7CarF91hyo1k4aaZX380CW7i09zMoc4em97mVF46TmvMrvgEjeYqKtGGLZIqAMVqodpA+Uvv3FM3L/jpwnmHyNH8/vNhCL+8UIVhaXMiN7mxTFZQcrzs4WZS+dilgWMgyvdTp/nZA46Ap0tb/oucapIvep/knql+DlsrCU51HcSR9lRrcDDaCx3//o8wRx1BHo95L6oiNrYdwWN8vf6gaQrUHix12P01t6wm1nT6rCBCj9RMEcdgfaHTSPU7lRm2wfzBAlBGWhrNOlfmFtqfBcO69yNKhd6+5JhZ6PX+ETBHHZe250P4QCPWR3qIBomK+qo0ko5MAVDFbPoRrBED98+Magd/nLHVbb/i2DGv0ffhi9/HVhaiZxnuvAPRms3gq0nV7ofdD/fjuI884Fjv/w5/CL4qYI54b6/Px8+Bs+FoOUsO5laK2RbvtqMMa3IceZWygVx6WQOh/Hn8ctf8amCGeNPtR1O6vTY7Ld0VbxKLDsCT5uD+sS6XxLf6EZvA8yXmRdw+nnv8/3nbMNWFZk5UV3y0e2zDRUdsGsiWwHF6NHbivLxP+2da3LiOhCFVR0WEKIsQLdhARh5AQx4/2u6xsaxZMgDbOvROv4zdaYmE1lftdzqh+SdLsxm3vDXnNjAyWl+uVHTWWuJR0fUEE3vm5kWevlneJG3eXF94fuGbDf82/+qWStsv7IIg2mq7ewZIbqvkpuQcm9CmMZh1aS9ffy4Oj9KNLlnlXgzc+QrXv4VCea8dXbA6ZThTOsw/ZN7vGohM71lzzjRW/WopvLrfiGe97HsV1kSB3O3nf80zJMUhvEsk5S3CxnbgFzX9VG5s3foz7hDba2ymj/qTxYHc7/AtLTWSWzGKxB8gzLkn45v3Mou91aEMRvqRPCN03t7q9hbBOU1/SMOJi8yMZ0rxN7FNZMw+YPtv5MBM15CRU2uNR4a91qQNNvt8VdZYTB324UefWr9KaMmJSReA9jX9XrePbhf1XbOicBjBNa5yKYd8v7fYsNlgTBVtV3saVdbNm4ykyYNYOS7RXTfTn07Tsa/bLP7+fa/bpYb6qoXmUSDSQvCHHi6CSwzvcPdq/sxbm2QczCpe4rX9d+/Vuf7+yorzTJ322UffeXJk6IPoya1l+QeZekGbkkpmlxOtTjJIWIgD6Zaep6uU3XiYbviXZx4y3cYN+FFnstLbl9Qn9UwzQoj/BAK87Jd47GNuyn3Skv8IK7TRE/eqd4dyM2lWmN0moTC3G3Xej47oOa+8cs4IZ+xEMiMXlA3tJVAuqusOJhqtSnrbKDpyIyHkpqxfMQv+Rp8pG5Uzb9VR3UMapnB8my82Db8RxNVtxe8v0FqrLe9xf43F736gMJMbODk9IxTvp82Ud2cbricMy9ve1Dqh9QE4NjXF4qFydU22HNFehtCV1Q5DCYUxiGrLhfm2zb0U9VN762qS1NVoX+7ZsEw98GnM+5zlAyTy4KpSTTMXVEwaxYN01SFrbKSYQbYaia0yrJwmLuCTPMgHWZBLpA+i4e5K2uVlQ2znK3mh3yYxbhAmuXDNKW4QIcIMEPmM3tZBkx9Dj6xHAFmGS6QNUXALCMKdFRFwIyQCIvh/hQCs4TdybEUmGxLSH6VAlO+C1RzMTDF706uYdliYEo3TcsFwRS+O9HHkmAK351oLgqmbNP8KAum6NyJ5sJgSg4cHEuDKThwEPB4kZhdYK6Um9Y8mLAzGTM5PUippqmDz2QCMKWaZm0KhCnUNIcKg8JgyjTN2hQJU2S4XZ8LhSkx3F5zoTAFmmbovveEYP5XyTPMYmGKc2ivSeliYUpzaGsuGKYw0+ya+MqFKcs0D1w0TFGmqalwmJJM88CxYcbKZw5STsmBPsWdyYjJ6UHKKTn4UMXDFFOopw1gSinU00cFmFJqaC0DJgmJt/c3nQOmiO1JnLavBGEKiBxoAsybzH97cmDAFNNHxIAppY+oa+EDzEHm7QPVDJhSWk/iNZckCjNnH+idAdOTlK8PZDkZmJHzmaOssvV+ok9dKsnp/LsVDgYw72WmaWoGzAcyy81mu8UEzEcyx4W2ZsB8LPNbaIPf9pUPzOwW2i6OB5gyaqJrBszvZV4LrWXA/Ena3BZZwFQibj05MGD+KDOK0VoGzF8kZbPQngHzV5lJMkwfFGD+KimPz2ZtEoSZSD7TlW+ZfDCTm7oUYWZQQ9I1vAOmiGK9VMrxcoCZfFjvnQHz7/ItaZo1A+Yz9V2XxJ0fwHxCJhw70GfAfFImG3LXRwLMZ2WikSD9bgDzeZmmS1sbBZjPS0rRpb3eCw6YL8gEXVpLCjBfk8nRrEgB5qsytZqgswLMGTKlDcpwZUm6MNNMyn3JlLab58TnSqUOMx2a+mgAc65MhGbLUgHmbJkEzStLwFxAGp0GS8BcQka3zZ4lYC4jI9M8GwWYy8mYNO058cnJDWbEWJAlA5gLy1g5FJvD5OQGMxJNy4CpZPRV6wMD5jpyr4NvSRgwV5KhG6vtmQFzPcmXgEutJs4MZuL5zDu5swE/l5lNTnYwQy213RILmKvLEHuUmhgwg8iNDbIjAcwgcmU/yOY1G5nDVLRf0TgPDJhh5VrGqa9xdcAMXe9u7Ao47YmznI3MYbbGufhaaw/93hswY8hF/VpdD2EUwIwjF8Op6xxfXxbMhXDqLKME8mCymY3T1hm/viyYrSu0mePZ6tOQYgPMFCSxudgXjVJx9q8/wMwxZfdN6lo9zVPrs5jXN/kP35PU8tR/Xm/t57i8AmaKsv1j/wcDtbbpvzGAmb40zeU7l6jnOHxqADOPT2j7F5umhdo/ldVNcxL8vqJhXiW1zxdbJlKACQmYkIAJCZiQmAnAhARMSMCEBMxSZf75TEhByWlIwARMSMCEBExIwARMTAxgQgImJGBCAiZgQgImZBz5P9GWi0LgnJo3AAAAAElFTkSuQmCC';
        }

        $db = new DB();
        $db = $db->Connect();
        $query = "INSERT INTO usuarios (email, status, foto, password, name, token) VALUES (:email, :status, :foto, :password, :name, :token)";
        $statement = $db->prepare($query);
        $statement->bindParam(":email", $email);
        $statement->bindParam(":status", $status);
        $statement->bindParam(":foto", $foto);
        $statement->bindParam(":password", $password);
        $statement->bindParam(":name", $name);
        $statement->bindParam(":token", $token);
        $result = $statement->execute();

        if ($result) {

          return json_encode([ "newUser" => $result ]);
          //return true;

        }
        else {
          return false;
        }

      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }

    }

    function ModifyUser($id, $email, $status, $foto, $password, $name, $loggedIn, $token, $ban, $encode) {

      if ($encode) {
        $password = sha1($password);
      }

      try {
        $db = new DB();
        $db = $db->Connect();
        $query = "UPDATE usuarios SET id = :id, email = :email, status = :status, foto = :foto, password = :password, name = :name, loggedin = :loggedIn, token = :token, ban = :ban  WHERE id = :id";
        $statement = $db->prepare($query);
        $statement->bindParam(":id", $id);
        $statement->bindParam(":email", $email);
        $statement->bindParam(":status", $status);
        $statement->bindParam(":foto", $foto);
        $statement->bindParam(":password", $password);
        $statement->bindParam(":name", $name);
        $statement->bindParam(":loggedIn", $loggedIn);
        $statement->bindParam(":token", $token);
        $statement->bindParam(":ban", $ban);

        $result = $statement->execute();

        if ($result) {

          return json_encode([ "modifiedUser" => $result ]);

        }
        else {
          return false;
        }
      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }
    }

    function removeUser($id) {
      try {

        $db = new DB();
        $db = $db->Connect();
        $query = "DELETE FROM usuarios WHERE id = :id";
        $statement = $db->prepare($query);
        $statement->bindParam(":id", $id);

        $result = $statement->execute();

        if ($result) {

          return json_encode([ "removedUser" => $result ]);

        }
        else {
          return false;
        }

      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }
    }
  }



?>

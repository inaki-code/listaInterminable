<?php

  header("Access-Control-Allow-Origin: *");
  header("Access-Control-Allow-Headers: access");
  header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
  header("Allow: GET, POST, OPTIONS, PUT, DELETE");
  header("Content-Type: application/json; charset=UTF-8");
  header("Access-Control-Allow-Headers: X-API-KEY, Origin, Authorization,X-Requested-With, Content-Type, Accept,Access-Control-Request-Method");

  include_once 'user.php';

  $methodHTTP = $_SERVER['REQUEST_METHOD'];

  switch ($methodHTTP) {
    case 'GET':

      $user = new User();
      $user->getUsers();
      break;

    case 'POST':

      #Recoge los datos que le pasan por el método POST
      $data = json_decode(file_get_contents('php://input'));

      $user = new User();

      if ($data == NULL) {
        http_response_code(405);
      }
      else {

        if ( $user->createUser($data->email, $data->status, $data->foto, $data->password, $data->name) ) {
          http_response_code(200);
        }
        else {
          http_response_code(400);
        }

      }

      //echo $email;

      break;

    case 'DELETE':
      $user = new User();
      $id = $_GET['id'];

      if ($id == NULL) {
        http_response_code(405);
      }
      else {

        if ( $user->removeUser($id) ) {
          http_response_code(200);
        }
        else {
          http_response_code(400);
        }

      }

      break;

    case 'PUT';

      $user = new User();
      $data = json_decode(file_get_contents('php://input'));
      $id_user = $_GET['id_user'];
      $encode = $_GET['encode'];

      if ( $data == NULL || $id_user == NULL ) {
        http_response_code(405);
      }
      else  {

        if ( $user->ModifyUser($id_user, $data->email, $data->status, $data->foto, $data->password, $data->name, $data->loggedin, $data->token, $data->ban, $encode) ) {
          http_response_code(200);
        }
        else {
          http_response_code(400);
        }

      }

      break;

    default:
      # code...
      break;
  }




?>

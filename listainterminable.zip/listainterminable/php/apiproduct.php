<?php

  header("Access-Control-Allow-Origin: *");
  header("Access-Control-Allow-Headers: access");
  header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
  header("Allow: GET, POST, OPTIONS, PUT, DELETE");
  header("Content-Type: application/json; charset=UTF-8");
  header("Access-Control-Allow-Headers: X-API-KEY, Origin, Authorization,X-Requested-With, Content-Type, Accept,Access-Control-Request-Method");

  include_once 'product.php';

  $methodHTTP = $_SERVER['REQUEST_METHOD'];

  switch ($methodHTTP) {
    case 'GET':

      $product = new Product();
      $product->get();
      break;

    case 'POST':

      #Recoge los datos que le pasan por el método POST
      $data = json_decode(file_get_contents('php://input'));

      $product = new Product();

      if ($data == NULL) {
        http_response_code(405);
      }
      else {

        if ( $product->createProduct($data->nombre, $data->precio, $data->peso_neto, $data->foto, $data->id_usuario) ) {
          http_response_code(200);
        }
        else {
          http_response_code(400);
        }

      }

      break;

    case 'DELETE':
      $product = new Product();
      $id = $_GET['id'];

      if ($id == NULL) {
        http_response_code(405);
      }
      else {

        if ( $product->removeProduct($id) ) {
          http_response_code(200);
        }
        else {
          http_response_code(400);
        }

      }

      break;

    case 'PUT';
      $product = new Product();
      $data = json_decode(file_get_contents('php://input'));
      $actualId = $_GET['id'];

      if ( $data == NULL || $actualId == NULL ) {
        http_response_code(405);
      }
      else {

        if ( $product->ModifyProduct($actualId, $actualId, $data->nombre, $data->precio, $data->peso_neto, $data->foto ) ) {
          http_response_code(200);
        }
        else {
          http_response_code(400);
        }

      }

      break;

    default:
      # code...
      break;
  }




?>

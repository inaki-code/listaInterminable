<?php

  header("Content-Type: application/json");

  include_once 'db.php';

  class ListPeticiones extends DB {

    // Función para sacar todos los productos
    function get() {

      $listPeticiones = array();
      $listPeticiones['listPeticiones'] = array();

      $db = new DB();
      $db = $db->Connect();
      $query = $db->prepare('SELECT * FROM listpeticiones');
      $query->execute();

      while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
        array_push($listPeticiones['listPeticiones'], $row);
      }

      echo json_encode($listPeticiones);

    }

    function createListPeticion($id_user, $id_list, $mensaje) {
      try {

        $db = new DB();
        $db = $db->Connect();
        $query = "INSERT INTO listpeticiones (id_user, id_list, mensaje) VALUES (:id_user, :id_list, :mensaje)";
        $statement = $db->prepare($query);
        $statement->bindParam(":id_user", $id_user);
        $statement->bindParam(":id_list", $id_list);
        $statement->bindParam(":mensaje", $mensaje);
        $result = $statement->execute();

        if ($result) {

          return json_encode([ "newListPeticion" => $result ]);

        }
        else {
          return false;
        }

      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }

    }

    function removeListPeticion($id) {

      try {

        $db = new DB();
        $db = $db->Connect();
        $query = "DELETE FROM listpeticiones WHERE id = :id";
        $statement = $db->prepare($query);
        $statement->bindParam(":id", $id);

        $result = $statement->execute();

        if ($result) {

          return json_encode([ "removedlistPeticion" => $result ]);

        }
        else {
          return false;
        }

      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }

    }



  }

?>

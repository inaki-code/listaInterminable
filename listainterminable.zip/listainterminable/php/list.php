<?php

  header("Content-Type: application/json");

  include_once 'db.php';

  class ListClass extends DB {

    // Función para sacar todas las listas
    function getlists() {

      $lists = array();
      $lists['lists'] = array();

      $db = new DB();
      $db = $db->Connect();
      $query = $db->prepare('SELECT * FROM listas');
      $query->execute();

      while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
        array_push($lists['lists'], $row);
      }

      echo json_encode($lists);

    }

    // Función para crear una lista
    function createList($nombre, $tipo, $foto, $usuarios, $propietarios, $id_usuario, $likes) {
      try {

        if ($foto == '') {
          $foto = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA4QAAAMWBAMAAABbzlVAAAAAGFBMVEXm5uYAAAD////09PSUlJS6uro4ODhkZGSZ23ugAAAgAElEQVR42uydTVfbOhCGE7u02xgSZyvshGxdG+g6aVq2xEDvFkMbtgRa8vdvvhti2ZLtkSxVM4eeUzWW4/rh1cfMSGp4ayONtXEV/Wht+8XV34LFNcs/jaM7in0b3+5+xiJs/wtYP3dl7drzgwLvSnyx0NULTv7teD5/my4scQw199r2NUUY+Y0Pbw6a4/xshJGGCG3v6DZBehv7c73oNDRDGJLbGZLba02/Wb5eCD1sQg/t6ZtWCL3/sA2ldImxRgi/Iy9qa/qsC0KCvWCmEPVAiARzrBtrgBAJ5tvIVx2hjwQZ9hwFaiMcIiOW/VozVBXhBAlxMLQCZRGGn5APN8PaEG7M2vz7+2IP6XBOLsLDVye9SP+4jz6ZAhNEJRHiUKZAW6okwi8IpghDXz2E2IwWnB8S5RBiM1rUTxMohnCATAqaGwdKIfSxGS3u8/aVQvgRiZRxtSmEsI88Sg1pAnUQom+0bHeoCkIUYUlrW4ogRBFW8NKogRBFWGF2qARCFGGVmUUoGyEtFoUxpkpNKVEg5IsirGRx/QgJUqg2KvVrR4iOmeoT/HoRone08gTfqhkhhigqW4vUi3CICCBGNDUixGk9gHVInQibCADCRxPUiBAHMzATi/oQ4mAG1lVaA0IczADJsDaE6JmBspeaENpn+O5hZSgdoTXDdw/bG0pf2YSTQkAZklpCvtiOwrpoakCI41FYF418hNiOgppVA0Kc14NaK5CPcIKvHdJcWzpCDPZCT+8D2Qgxcw3YukQ2wia+dOjpvWyE6JqBn1fIRRjgK4cf0MhFKME1M92zt6XN9+3q6ur3fPWzMNahFHdgljo0Y/EEq+d5enpaPGe1AU0oFeGkHJMlht9/3+r1KuLhcdr2fxj6i79G0ba4Ocvkb9Ff2q7SwlafLmv5nr29uGzx7519f/8MlXfWOLobzwvzbHtSEZZoJ/5sX7K/O0QmsKWvC5FTDFe/b0dXxWZesUyE5aYUP68tz/s3mVGLkecX2qn8UebKptOSzf3vzfk3qhy9IbzonRc48aHrywv5WqWjFN1r3yiEJCQFWtNYHsKwvHfN/UqMQrgYrfEfftQKpCGs4l1b73tkDsKGHR7x+kG6RBrCSrPCtmcWwkYjDHg7nhtZCMt3heuBFzEMYcPiZXgSyEJYMdBkmYawYXGe/9AlkhBWzbnoBKYhbHgk4W9JJSCsnHNxExiHkDPX6CGQgtCvHCtsE/MQ8iUbrRJKxSMESD8cGYjQ+8GbySahIa2eNtMxESFXmPxFCkKIDNLYRIQ8m9B3iAyEEBmk9yYi9DjORHKlIITIfOoaiZCnKY0lrGyyhgAInZEB8cJU0eZwLj9KeKoAJAm4QwxE2AjZCSttGQjBEtDNQ2ixR/NuKP4xzmES1L4aiZBj38FYfHsOlMe9Cm+ah5Atw0dtEHbNROhdst0ewhFCpeLfmImQKUNX+GNEUNnaj2YiZE+rY9GPcQG2DCQwEyFzx6UH0Y8Bd14oMRMhczHDJo9N3GOcgiG8MRQhy0XjErGPYU/AED4YipDpKbXFPgbgtl2LztBMhKxQz4tghIBrIomhCFnzimOxjwG5Y5BtKEJ/wh6rC3oMnr640LJW4+KFm2KPNbkXGvKFXKH9YCpCVi61JRThZ0CEbWMRTljNk0iEE0CEXVMRslrSB6EIZ4AIHctUhIzjITpCESaQCEfGImxyJIcJQgi7K/6LsQgHHENSQQhhd8+7Nxahx5EpLQgh7EayHXMRTthDUkEIYTfuapuLcMDegUYQwiYoQtdchIQ9JBWEcAiKcBtWMRBh/pvsCkQ4g0UYm4vwkjkkFYQwgUU4Mhdhn+klFYOQACN8DoxFmL8//UgQQsD0tf2Rl3HxwlUxf4HYi7Dvhd4Xv2UuQjt3dcW9sAzNASIEK/ZYTg8h32t/RIRgxYukDoTWD2CEHYMR5uYCdkU1pKxoMyIsgnDIWEErpiFFhHBF+7KOVHeYnRIQ4bo4YPithHxvMEOEcMUeYx27GITAzpnd6RpGIgwYfish3wvtnDEbYW42aUsQwj4ihEQ4Q4S6I8wbHJ4IQngOjbBrMsLcKZqglXv2J0QIiTBvwXRbDEL2nimFEdrGxgsXdpr/yy0k5PsZHGHDZIRnNSBsogohi4P87BkhCKFdpJv9EE1FmOueQYQ6FEkNCIeIUHeEM0QIWsx7NaEYhAkilIbQEoPQQYSIEBHuF5PcJYYiEPrgCB2zEc6kIySIUB7CkRCEfUQIWxxKR9hDhPIQviBCHYoT6Qi/wCMMDY4X5sd8X4V87yUihEXY/BcQWiYjbOQhfBTyvZ8RIWzxMyLUvXgqHeEpIkSEiJAb4TE2pIiQVmwiQt0RThAhIkSEiBARVisOESFs8QwRIkIFEMaIUCrCGTxCs+OFuQiFxAsFILxBhIhQ5+IAESLCoggTRCgP4QkiRISIsGaELUSICBEhIkSEiNBwhB0hCOEJLrfdRIR6I0QVykWYoAphiz1sSFGFCiAcGR0vzEUYiPheRAhcPEeE/zLCNiJEhIgQEfLZCyKUijBBFSJCVCEiRITK5ZEiwizrCkE4RIQSERIR3ztBhLojPEWEuiO8RIS6I7xAhLojhN/Y2XnFkG8WQiHxQvijRgxH2JeP8AwRSlOhKwZhHxFKU6EghPAn/qAKZSO8RIS6I+wjQt0bUvCWFFUoHeEZItRdhdCHpz2iCqUjPEMVylGhIwwhcG/4HKAKpSP0QWP39wGqUDpCj0AyfDa6Ib2oCaHnfZiiCjVtSLfBp9C7GL9NQTg+GB0vzFUhEfe923JwdzceX82X9vQ03VmSJIhQE4Se772zKFp9er38Obpb2nhtV4gwo3gEgDB8T6EYwoOibduR3YjCMPSiJeAw5GjxUYUVEfq38/n0aT7/ZgEgzCwiQnEq/DuynP62EKGGKvz+ziX3BxFqh/Bwht4OEaFeCNO+zm6ICHXqC2n5hB0fEWqjwpB+OPbXABFqokIrA3/XQoSaqDAz2HBPEKEWCMMfmdH+GBGqgjDIqWvnvNMOQYSK9IV5CMO8mO0oyP7ekpGqc4wXlonaWzl1c1Oy2+yQLyKsGyFJWIs2gRH2ECEwQsYiwS6qUI3cmWyEzGURjzJV2EIVFkfIzAN1Q1ShCgjjrLo9jiR5VKHSKuRIAnUtVKECfWGGCu0BT1pZi6AKlW1II65M7K0MJagQERZEaH/hy+7sEFShogj5RLisjipUsy+0uRcHrmWIKlROhSF/qnyMKqwb4YhS1y6wQnclQ1ShaggLiHAtw0OEAuKFx+ChuCiKln/0jxd+pdQttEy+IyfkC4/w6GrqTH/b+kftbyh1i21WEWuJkLxtbvzT0lyFtGO3Cu5V0dER4V5elxvrrcKYUrfoEvlYQ4TDd6lcOqtwMZ5M1R0UJLiQoXYIPx1kxWqswphSt/g+FbFuCPsJ75BMeYTLSd1h3cIi3HlK9UGYimaPtEUYpy8Oy2wWE+uFcEDLA9KzL6Sk89olRLiToSYI/YSWjqenCilJ9aVEuJWhJgg/UrNitVThWjvvLi4nQuqtlEVIigzJFFchRTolReg4ljYIo0meG10vhJQOrKwIN1k0OiC0MyJaro4Ib9IXR2VFuJahDgijrPTYkX59IW0y1ytNcCXD3a0UDvkOGL8jOsULY8rFVXaBtfSI2s/yVmrphbBDCv2OcshQi6h9zn9QO4Qx/eLyMnQtDVTo54RCR5plsP0i9IsryPBeAxVeMpeC66PCOOviCjIMlVdh7qLXY70QLkSYcXEFGb4qr8JLVhKQRgjjzIsrDEq7vuIqJKxVyxr1hS2SjfBLBRkGaquwmd8RaKVCO6duBQ9NO1JZhTZj5blWCNevI6OuXUGGI5VVaE3YzgltENq5dSvIcOu0U1KFzO0fLH36QsbbqCLDWJgKT6oiDCcCEAZr244j7LUJV6HLes8VZFhNK3kqPC5wZ8+nXMw+mjbOvPOOyoH5UbT6pmht29Fc5PHY5voyCJmtXQUZurYoFfIivBjPl2cx+IefskWYiTD0Fne7u7u7HY+v1oferA6+eXt7m+4dfpO2p7flRfNDW52qsjxgZXFjz4tKIMzapmKvWEGGu3kFdLzwhOdWNvm+9r9MR4efXrCf/Sbjzh/eptPEATfXmU7n4xsvKBwvbHnsF1veRdMVFfLlQriX4vuck4Gf14Kk7/zDEWpPVlAwau9aPC+2vAxHNSJ85wJ9ffcpzyHtdIRfHMG2Pm+ggApbhOfFlpdhp0aEs4Nfpr1PhxwNGy0Lz+o5wq0TFVOhxfdiS8vQFYSwxb7Vx8MAZsB1550aaAjDmXiEzktQRIWLUT/Xix1UaUnrQZiq3fazF1FwIrSajgyzi6iQdnFIqzur0JLWgzCN6d7ffMrVGrYow4pACkHqGsEshC2aZKcWpW7pXrxbE0Jau3GzocIjQuchfWemWxXKYm6Eq3FzeolBi1K3/NwwrgfhMHuwxzckGaXvTCQRXMiQty+k5VwvR+IxZZZcWoYPtSDsZScScA5JotSdqQtoxJjFqUKXsvJh9Zi0Va6lZdipA6HfzEir415l0CaQye2Fc8dCPhXSTukJko178LBuaRm6tagwwwP2i/CK8BE0ub2UV4utQpdyVtamrWhT6pb+HbRqQJhZNY4450d26s7SBjM7HzsT4T1lLW6QUFwZ609Ly3BUA8LM+Vubc3rUTS8xCRKJCB94EG5DFO867Mnuf5quW1aGDzUgzJ42zDkfOr04rS+R4CYFktEX3lNW0PVT0tn7tKwMj+UnXlQf/VvFUr/hO0ObI15Iywdo7jU4RZYB5bs55CM8r/oG25RVQjK7wt0IIg/hfZD+NDiIEsEsdGpLz2DzK0/gXilvJ5GK8CsToWszTmVqgy106kpXod+s3oylF2BIJeg8/s/euXynrSRhvI0SZ5sHSFtdycTbjpTE24jre7wNxM5ssZkh2yDfY//7Y4xNQKqW+lnqkuHknJkehnbRPz71o/rr5m072B56wtq742qKwY7RKcJXoekcfA4YvU5wETZ+wfHT6mjt3Wll+G3J6BS6UOGoEaHpMw8yen3ERThqQzgHrEzjeqbPjtEJXYWJebKnXvNfuAijFoSPc8Lqu1NokafaOCsKKjTttiZQzUe4CMOWvnAOWJnqM9cSeESdUlChYbf1mN5v6Wbcv5pVuFmYaXWJRJDRqcBDqK1CQ4Trm6U17m9ERbhZHW13iZSA0ekzARWemvVCOfMBYdz0G31aHd17F1yGh67n1ZAhugrNEN5y/xF+kHaJlIDR6bMXKnSH8Mlf7jXCGFhBFbhEhpDRqei3Cm+4HwhVTWGiRMrEhtEJXYUmw5kwFUQ19Ruh0Kq1PbVi9/+sODcMXeQLR02fNUlULERRIc8L3ymekyjOZk7MjU74CA127IaiqIJPyFN7RYTih0RkbnSK0BEODBa4RfuOgmNchEO1tmraUlAaG51G6AiVbuuriFAY1RkuwpFaWzX11BH0WaXR2Vt8FWonm+bibdRjXIQflNqqeQBXAp9VGi+8x0d4pC1CcVQcF+GNUls1ayqCPqsiwxt8hLq5vUWDpShYoSKcqLRV2yyqBD6rIsMZPkLdh17WEBWSt/D5NVBpqzZFRdBZEoVSu2Aj1Nxrt2i0177BJBgptFXQvpRRAgg/KwTTAUKtpZSw2eSOOp55q9BWg0LqF6FvdBp1gVBriW0eN0aF2hmW8m0VnMjVV5vpSs8Nb7pAqLMBCvLq7dliEDvDUKGtskLuwaxvdJp1gVDnSTqPW6JC3IY4TKTbKjiRlHV9jH0q2xV2gvBEU4RNUSFaRG8z6bYaFJIc6p+VTFiMukGoPiaFvHqV3zvaMmmYS7dVIPtjLbmu0al0c2fTqCWdFnzV7H2aooqvkRDOFdpKdnoX6RqdwszNeaRtCJXXwxYSURl7NeR/TtJtJd9jlEBVMp8exW7OI21FqGirDjOZqJBkuFBoK/k1lkjT6FSyjlSomLpfcKmoTjEIRgptpTJsK7WMTmHKOlKh2vjxIU6pqNIpAsKZQlsVij+NWlWtFXzgnakwUElX3HDJqBAepbcKbaU2dyp1nis/WGcqZPm1igglowrGrhn+T6WtCuUntKoXcxizzlTIAvnx4yKWjiof37kEuPym0FaB6gIGZHQ6kxjMOFHhUGKb5Vj+16kQVZBc3i2XlsldPx6h/+/590SlrbJC8c+ARqdV+2CmKxXKXGTw1PuozXyy9X9uLjl4vqng7u7xjoPNJQfbqw7W/+Pmzb1rDS4eXufPr3+urq6+b++yyJXaSn0VETI6nbWlUDtUoawMN8uHOkHWXun6ipEskXml6Z//nqk3jvzq6J6ooK6hQYZPF410pkLZ3r6MDYKsmIbWL6wrnHQyJzdAzGctKzNdqlBuzL05aNazi7UkihoiXD9xAKOTWIbbfU+dqVBKhrecJkK99OWNitFpK8LuVCgjwyhnJBFqiRA2OglluDW2ucgXSloOJPZ1l4pR+VLU3UNQyhudhmnl73aBsH3yO8yIIiw0ESoYnUrmAcL2x83fRBHqb+SRNjpFsRcI22RYe1ZQKRbaCEGj0wpeW/MBYVvqd8JpIjTZTQcZnU7hgY8XCJvvPm+9WsfXYmGAEDQ6rcD9Ul4gbJbhjNFEaLalFTI6nYGzDz8QNq2UrqeuJBEWRghDoOba3PBxxcMThJn46tYBo4nQdF85ZHQ6g1Y8PEHIhJslWnww3hYNRbh3MajI6LRZdvQFocj0G2aMJkJzc0fZdqNTlDOvEIoWHzhNhMYilDA6PaV6/UEI1jTMGUmEgQ2HVdl8o1OYM88Qgl61CaeJMCssIIyab3QC7jvqGiEwonnOhVFDGNixOTYancLa33WQ8pXMFz4XB7UFpK2Plk6OV9HKJJewAI1ONXuCBwjru9l+x0QR2vIaQ0an021PaAnhiUWELN4flf43ZUQRFpYQhmKj04IzD1XIBnu1RTNGFKE9w7/Q6BTVrxLyQoUsu9z5Bf6IqSIsrCEMoT+0luH6ZksfVfjAcHt8U/gtZUQR2jx1Q2B0etz+66UKH4pfNo6W8HvKqCIsLCIMoT+02lwv66cK18XxxfLXPzxnVBHaPfoGMjq92ezB91WFT1FyRhXhoLCKEDI68W+cea1C2sXA9vlTpWwYnqmQbjErLCOMXCM8qLByeoD9Q+DKDlUYvUCE1kUIG50OKmSeWZlkvJUHFeIUHYjwj5e+DWH3+cI+FN0ch1qqhGEVYfTyEBZOEIYHhGhFV2cSl10hfHkP0sIRwuigQqSiu4PBywPCxHsrk4bR6YDQetHl6fzlASFCMSscIowOCN0XA7dXZJQHhM6LTkUI3+h0QGi36PqemvKA0HFxUDhGGB4QOi66vyyqPCB0WnQuwu2FVQeEjooIN7aFWUsYDlK+Lylf6F6E7+YcP2v/ghBiiDA4ZO1dFlFEyA4qdFfEEeFBhQ6LOCI8qNBdEUmEBxW6KyKJsAcqDJJXF3fLX/9+T7hXCLFESF+FwfYyrV+z2COEAywR0lfhzmEK4Yz7gxBNhORVuJeP2zD0AiGeCKmrsHIWZxT4ghBPhMRVWLsZdH22lw8IMzwREldh/Z7DCfcBYYAhwpz1QIVB/acSpb21MlVeN3JReZ4vhC4kLvtrZaqIUCkqXxEeg5aN3lqZ9l4L3geE8OHrs/5amfaHo90hDG01luAmkre8t1am/eEofRWKRn1h3F8r096ckL4KhaO+H/21Mu3NCcmrMDgV/YH3vL9Wpt2FGfIqFF8mPYy7RYi1MENdhU1XuneKEG9hhroK+Ur8F2ZdIsQQ4YL3AGHwpmnpqUOEiKujxB+kwivVHsczHSLMplgiJK7C4LjpK25uk+kG4RgvRUEb4bhJhOsrwTuzMuGJkDbCwXHzz7Q7hBgizNSicpDyDc3zhS0NFfbayvSbK0XlJ8LWp9XgJVuZELL25ghbn1adIcRZmKGvwvYhw8yUSsp4Hjz8ey7mm9dOkXdlZcoZLRWmOfBu+5BBjDDYoZKmSf31TGtv38nV6++bfw+vq6cX78bKtOCMkAovL+7PB5vG3H1XYtwuQrhRUspeX12eX9zf3y+Xy+trvab80JGVKWd0VPifpzkeqwYtMW4X9IX5l4vltcOmxJoTklDhIN4+kx7vStvd3zfVRbh7h56DpgzQFmYoqDAY7+Yhvu1tDZVoqBBEmL1y25R4CzMUVJjujQvCv3cu75VpKHBqn9rsqeYx8LNzTzDSuDiuGxUOflYin8nV3Lw6s7IowoHOVMfa6igBFdYwDf/0ZzLj9iFU87F1EapOdWyJkIAKAUzz53elnoYjoOb42roI961MCCK85YyICk9FM70kltvVcAPUPLUvQtWpjvEvJ2VEVAhiilSGJJN6zbGLbM/OV8DoCW9iLYQd5AvH4oeIpOcrrW86tdkTLrL610eZE5okNVERToX9j+TWImAfabZy3JQow1EyCFfCDiiXE+H7es0njpsSpyekglD40Vn+We7L1j0VNnuqMJd+ctjtCTkZhEfiqYKcCKO6sylf2RRhPWak4SgVhGJO59I/12rNFpt43SfXYkaaExJBaD76r7t8bY5H13PCasxYCzNEEBoPPACvfTC1KsJazFgLM0QQfjT9ssCJF3xlVYTVmNFWR4kgPDKVCVAzt7w6KmX5d7A6SgShqWDmQM2frTXlAtgnjpei8Abhu8bPmiYUZkDNXy3OCWsxY4iw5IyOCjPDLzuCav5kcU7YiZUpZYRUaNptTSAn2ye7IkS3Mt1wRkiFr01nFBDCqV0RoluZzPxW2Clfw2lhCdZc2BIhEDNKT2ji9EBHeGo2cotdIoQuuIrdEzQ8ntNF1v6dO4Qld4jwYU5YjxlnOPpyVBilzCHCeVyvGUOEOXtBKrzlDhGuF2ZqNR+5R3jLGS0VmgxnhCfGTy2JsFYzkghpqdAEofDEeBtaedy2Vq0ZSYS0VGjwuxafGP+XrTlhpWac4Sg1FSaGeSBXCEErE4IIS848VGEjwlR7mTscCKM6tSTCSs382jnBMGXkVJhqJ5vm4qjGlkRYsTIdY4mQmAqPtEUojiq1tTq6VzOCCJ8murRUGB9ri7AhqpUdEe6bIPFESEuF8RdtETZEZToxhKxMiCIkpkLNXbvzxqgM91Q9+wn3rEwYIrRxJhX+xgs9xYB7A61tBZ4n9ZpjDBFaPK4RE+GJ9pNOHJXZhvxwANT81b0IbzlRhDozw83qqDgqs90R87hec4rSExJFqPMknbdtszRaPc+AmhFEWHKyCE/0esLGqEwsopCVCUeEZBGqz+LmcVtUBsaY9ZywVjOOCOkiPNYTYWNUYxMR1mpGEiFdhGM9ETZGpT2gCSFXGJII6SJU3CixnXg3RjW+1hdhtWYsERJGqJYcmktFlen1hpCVKcASIWGESgOacCAXld6gdA5YmWw695tXRwkj/KgkQsmodB6l0HQFT4SUESosQK5TFJJRaTCEpisZXoqCMEKFrWELhai+rPREuD/F/IgmQtIIpecVYabyldLLOyUJLYDpCoYIrd4khZ7yVfSvz5W2WQZ5zh++1NXl+f393XLZPicEqkIRoUmCsPOs/VNRcqF0k6JQCXL3ApgMumtk9wU1JUpP6AHCE1OEktP7hcE2S853FRwwvv63V4Q+e4rSE/ZBhXL5ijA3/oaqRZw5YS9UKNVWC46NEEeE/VChTGNpnRhvVkRamOmHCiVa65ZjI0QSYU9U2N4bWtlmqVbEWh3tCcLWQWkZIyMMsETYG4QnbWsY2AgHWCLsS1/YJsMJNkI8EfZGhc0rpcMEGyGeCPuDsHFL6QQbIaII+/MgbZLhMMFGKHlVjQ0R9kiFDTKcYCMMEC5bdjHG7ipf+FwUpu9Hsd2MqEQRQ4TuvkJnCEW7sMMZw0aIIULeQ4QDwXoItLHMcRGlJ+wlQrCmKGDYCFFE2E+E4IjmlqMjxBmO9hMhMKIZpgwb4RhFhD1FmJzVKphxdIRIc8KeIqw13xxpFpGgXqxl28rkFcLKozRK8BFOcUTYW4SV2mb4CLFE2F+EyZvd75qgI0QTYY8RJj+3H/6d4CPEECHrO8Lk1Wb3fPg7wUeIJ8I+I2RZenm/XP47SzpAiNYT9hshC7IdrwMqwsFP9yJ0+RU6zhf6UEQ4MG/C3X2FjrP2XhSPnBMcpsw/hD1SIcJNBhPODip0WPyKIcKDCl0WMXpCRk2FMSWE/2fvXL7a1oE4bOwL3RKaOFtjJ7B17UK3TaC3W2Iu7ZZA4W4b2l7+/UsCCXmMHtZIQZbGC87RiWNl/PHTa2ako+3MCRumwkYh3IIIg4BUaLC4BREmAamw2dlow4BU2OxstHYSkAoNFrcQgz/MSYUmix+3MickFRpMKBxtS4SkQkNF89uttc1vF+C3Cs23o0PzFtnjL3yL4qF5EW7NIk8RDszPCQmh2eIW5oT2Iuy7gLBnXoSkQrPFQ/MiJIRmixPzIqSG1GxxG6ujpEKTRdNd4WxhhlRosnhoek4YkAoNFwdbEGFTVVg0AqHh49HaWdBgFTYDYW8bIlytt0y8VWFUTq9cr/1H2xDhSr3RUeKtCvN/Hh/PL8tCq/0D43PC9XqLsa8qTP5+CQX7rNV+o11hG6g3PG0ZQajoqTrZWjR3lLzK5S7MtT25Z1iEm/U+jZ9scvluD2G5nP3XnjHU8eTok+GFGTB5w0uE4buVR/8INT3ZbHL2EKh3OonxEWG0fjLodItELSqcGB6ObtQ7zaDyEeFmoKemXD2j+fUVkMo0W0nwEGG4GW3dLrU8+ZPpOeF6vbM0Rg8RQi69Xzry1rMdwyLcqHfcKISRrl+ZQRm47VLHkw12hR3gVKaXM579QwjvRXGmAyGQRKZrjFpByRtjTxHCrd2+hicDGU03mjYv6QCR0POD1r1D2Of6I1H2A+7eKjrVKMLVeuered4hZC1EP+Dt33x092kGM9EnwpV6w/k/h8EhMyUAAA66SURBVG8ImauY+3j7gYfmehJGK6DehXfZN4RMTcRo+4H/julukxpk2AHqXYjQN4QcSYRY+4GucHrys4Zjm0Kg3tcQD5sym7jrU6EOlxhv5jZEOttCoCucfYpO3L6DPIKvw6TGuHx1IAx5w8MbLMIxo3+NkEunccWPs7IJ4YlphCVvkraPjO8D2sub50+RPqi7hB+k45MK+XO0541A1A0GIp+ql3r72OEoN8LDJxVyRfiyoZKywZDUFg04Rob7UCrT8v+LRyqM+I4ELMIJEK40/xQjwwiqd+wnwlwwasAhBH78wWucmboM96E8mJVG2yOEAm9ejBvOADPOIRew5HA0AupdjXX0B2Eu02IpGwzpLOT3lFLXNfCPtTY38geh8CVeohCyJva4Yyti6OTTtdwb1xBG6eu18qn4HaIQAhrvLN9cjBAiXFtDWJsbOYYw7Z8/Pv6+AD4dmUXYY7qv5kc4qfh+4xCodz0BzimEUfr12bx/q/VPxSKMMQihc9iHqx2YigyvE2D2sr5A0RiElcSjkv8WPIZrn0q8QAxCAFC8erPKEs1chCv1bixQuKTCFT/EcOVTmfeHGZHmY9bEfnGzQm94C3X2Gwt5jclsuhQ+as2pUy2Fhsq0YjHG2dZnN4KL+LbaMozBAOWNfxZ3XL7ri9hxsZRE0TKMEFjjfkAnzdxCaQKbNTUGoUiF0QmrJUvkdstGIdyRcbX3a4tQ6hwaZ1RYjoCu5CXhSCr0oY2xfwJM7DdurinDm1xO7q6oMPrIHMUmpVTkQwdhfwY9bvPmfl0RwqlMjiIMB0xhZXJbLR8g7IfiuKEfOaopQjiVydGGtM+J75ULP3pA2P8BagGAm2vIsFsCFYE7EzmiwhD2JM1GpZJBgBXC/gk0OILGXPIy/JVvVgSHbzmCsGREF15LixAVCgy24VLDZr4I1yqCtwdzBGGPrS3JgPj3CIN7YM8K3SzdG/4CUmIZ4VtuIAx32FOFSZ12VM3gI3CNG1x/kOwNu9CRPoxDTNxAGLEby6+SaQsIg6HRMOvmUHJslQP4GRu8uYEQf4A1JssXiOPusm6WW2boQkf6sE4ScgMh+pCdLibXvg/3rAzeMg37AzQUYu2y6ARC/FYTqB0vjuFJJnyzTL5hF/ou8zivxmQ28Vy+ERZhrDuwKmJ/VyLf8CEHvsvc6tQNr/0EifAWZTCwxp1zokOOJXpCbiqTiwgLrAhD1NamwPiWg1Cc9vs0HN38Ljulxw0VIhHuowzuMWIH1RKsnrfq2vguZ992JxCeIBFWKIOB4LWqbqDNyqpADnyXg90JhMg5RQdn8IARg82OWPwmEiE/lclFhJ/wIlQ3GGjiBNmm/FW2oTCVyUWEx3gRqhvcZ4XR18uhWRHhxnfHriM8xYtQ3WBojVv03Z5AhBuvsuU6QtQBH22kwTuslSTOd9mb68FH+uTOI0T1hUOkwcDEPhEkYBR7bDPhV0kIxSJUNhia2PMRRtk7dr+cBKRCRREqGwwFr/HTr5LvLZEI/VMhYmrfLZAGH7JGM8z0q++8wXHgqQpLhJcJixCY2Cfc9Ku/uUbaosJt+wvVz0DuYr1rIbt3BWNnEh7BTsKoiH9ErhMu37Eqwgeswcyd1+AgxNckVshhUjErch/hSFmEWIMP2QMkIPEj4fqZpsNRb1W4oyxCpMFQeHbFvFmwZQLn9C8nEJ4ZCH+K0QZDi5eseMZSQHCWFuyrCpNcDeEN2uA+2KXBTYUoCjgKHEfIVaFkgC0gQqTBx5yw4rWbRQGkt7kDCAP1aO49VRHiDGZ4jaAkqb9E/09l4ADCXFmFSlucPe+ngEM44XggV25+15ISob8qDFRa0lu8wawomGr95u8tORF6rEKFg5BfNjVBGdzjBQIs3fxd/P+UBM6rkI8wqH9C2TXe4GyPt6K7uJm7LDpfbQ/cV6Fou4S6CzTzLdIwBrMTiDtLSRQSBME8GN9UGPSUekKkCic8x8pLNloyEf8Y0Wq7D31hENQ8Vmdpey/139znhsW9pPVKEBSutm8foaKnKhd71zmPOq4pQg3eNd4Y6uWUHqmdZNuloKKTprh8ExTCtM6AJtZhIbf/7czerNxewGc5IUxTXgIe3BPiLYy4bXcVyhIE82BWirueIKzh+J32hHgL+Yvrd2kq6UCphPX6osJ0r9ZwFG8hP+oqrv6S+zHTQ5kE9X70BaH09H42HEVbKMoT/FcyciAMCOGiKDu9v9ZiIfJYwoVYE0L4WpT0VzwvzOARjnUQPEsCQvhalNyE/lqPhblGgoRwXuxL94QaLNRwYH18KVevRwiluqdbPRZGH3QQJITrSUMSMow1WYje7KbGNg0eIZTZdvdGF0ItBB1DmOERipOc5qcKoi3sYVvRKiWEkkdBrvl1Ck0WHiEJDlObESp6qiKMv3Be7OGcq/LFEZJgXqPeXlNcvloQCnZTf9Bm8BjXitaqtzEISy0Ie4KeUJPBCbIfdBOhHhVyW7gHbQgxE/tulRJC3qM4c8N2qg3hKY5gSg0p71Ej7rBWk8EDdYJh6izCUBPChCdCXQYrj2baYUoIheGdOy3JVAf1Yl+ZYKFQ70fvVMjIVumk+hCqjmbaSqcpHHuHkHGkQ6URoeLEvpMpnabgX18I72C+n2pEqDaaucvygFQo9SjoIAEdeTCLYjJWI6hYrxsq/FVvfjJghFtoQqg0mrlLVev1UIXAFi/dQidCFTfFzyzwG2E9FQbh3kbegk6EO/WXRf9kQYMQqnqqNPgLX4uD9fB4je60qHbQRfwZ42o+borLN+V7iWr+jmSZ4V2h1cLau2fGF5mpLDiHES7t3Rp/LvRaWHcP2+5FFhDCYf3fkQXfp4Oa+y9hptnCmm6K7mUWEEIFFaZBUWo2aV6sF0LajfKAEKohfJofPl0GLKy1NtMuc2y9xx4jNFSsMyBtZzm63k+E8A0R/kjzgBA2GaGe+SghfLu+8I+eeqkv1F6U9BbGPzXVSyp8o0nFy6IaIbQR4aFs9iAhtBWhzIYy3UpfvdQXai9KpNm3o1RfvUdNyWzS6S80XBTGXbSLQmO9Xrp8DRdFs4qO3nqPCKH2omBIep0SQtsR8hNRf6aE0HqEvCDE+FdKCO1HyOkM47OUEDYB4RF7OpgRwkYgZCXA/aiSgBA2AiGjJf0dJgEhbAhCcLb9pcgDQtgUhMACTXyRGqqXEBopbgQidoMyIIRNQrguwzuD9bqB8ME6hMfrKzKEsGkIlw9VqL+VjOUInfcXPpeKb4vEs1mkobl6t+8v9ARhkL6b9ofx7zAzXBEhNFfMrq4uCh3BvvziKSE0WCy2URGpsPHFQycQ3hBChnOLVEgqJBWSCkmFviAkFTYC4ZhUSCokhBarkBASQkJICL1CqOovHDfLX7i9IhehVS5frgoJISEkhITQToRdQkgqJISkQkJICAkhISSE+hBOCCEhJIRvizAihKRCQkgqJISkQlcQqnqqJuQvrO8vbOc2uXwJoQLCLiEkFRJCQkgICSEhJISEUB/CASEkFXqIsEMqbEAx+kAIm14khI1X4Q4hbHqREDqtwn1C2HQVmkGo6vIdkL8QLnIRWuW1J4SM4sgJhAeEkFToKML3pMKmIzywCuGIVOgyQlIhqZAQkgrfsDggFRJCUiEhlCzuEMKmq5AQMooTUiEhJBV6h1DVU/WB+0v99Rdys/YODP4MQqgNIW8rkFurEB4SQkJICAmhnQj5J+QSQkJICAkhIRQVcx7CM0LYhGJzEB4RQrD4kYfwkhA2oHhMCJte5B7lG1mF8Ji7T5W/CLmHiJZWIezxfurQW4QhL5qhlVuFMGlxA8+9RchbX4vNIFT1VHHnP3Hmq7+wz3stbSP1qiMcc1tSXxGe8t5Kxy6E3D1lW53EU4Tct/LeMoTcfjsu/UTIbUenky2rEO60BC2pjwi57ej0mGqrEO61BC2pjwgH3JdS2YWQvxjYikMfEXIny61WaBlCfrPfuks9RMgXYVxYhjDnI2z98Q/hN/4baaeWIQwmAoY/Lj1CWKbp7n+CF9KxDWE4aImu+y8zimXpNMJs+mf3673wdVxbh3DUkrnuH8+vgiJdXFk5u6IGMsuXTHi1Z/ef88ex1KsYWteQfmrVueL7+8fH3+fnX66uroKL2QOWwDbherZ6d/fJgPPz88fHx/v7Wm9gOqewDGG/RVetf+LCOoT5mLDUudqGWntlf6FoSZeuzc1Ijbotlb48Iix1rofAPoRHhKXWaMZChD3CUmc0k1iIMKXxTJ2u0EqEAwIjf90ENiKkzrDGNbQSIXWGdbtC6xCGRKZmV2gfQpoZ1uwKrUMYUGcofUWWIswJjeTVzS1FGNEyqeR1YC3CDwSnxuqajQiDE4Ij146azKhCOq6oJZW69nNz0SHYZ+0QHrl21F6EFH0h1Y5mFiOkllTmus5tRrhHgKTGoxYjpJZUfLUTqxH+394Z7DQIBGF4Qk18A86b3TReyXLwbq1eSW30BdReq8bl9S1QS7dhgURYd+D/28umzQD5MjAzu+xg0rBbn0nYCG+AqEPFK89BI8Tyi+6kMHSECGj6FNeCRijghq2qJnuDRqhQoelR4Q4aYfteXsgoBAOEWJnfpjvi4IVI71ucUI2OcJCJK7ih2wl9bcj4R1sISp3hqGSCELmhMxyNuCBUcMNGvQk2CFEpba6ORsQHISYsHFMUjBAucSttTCgYIZS3QHZ5G90QL4TyAdBsrQQ3hOID1KxoVBE3hFhGYz8INfFDqK8Brn4QPiUMEVKKIk1dGx39VaZREFKKevdvRui979BAthYaGX6pL5+9ooaex0JqcdBeedz3dnjTz4hk9l67jo1g+mXmpbZ4pYg5Qnk16xx/t1HEHaHQy/k+EOPvSBB/hBSprZknwdfM/zb+I5mWyRwh7jItJ4OQFjLp031jSvzW5ImZJ4QFxGKxfkrZqa9Dnhtj3kuxDVrj6vyNKa8nP1xY0XejlJJTQ3jqh1O1h9H2MK2H1S+KkvJTqejncab1/fbs69DjpVx/tK3ZRzoe/7hjmnadc8Mwkf+E8AewXJu1lojXDQAAAABJRU5ErkJggg==';
        }

        $db = new DB();
        $db = $db->Connect();
        $query = "INSERT INTO listas (nombre, tipo, foto, usuarios, propietarios, id_usuario, likes) VALUES (:nombre, :tipo, :foto, :usuarios, :propietarios, :id_usuario, :likes)";
        $statement = $db->prepare($query);
        $statement->bindParam(":nombre", $nombre);
        $statement->bindParam(":tipo", $tipo);
        $statement->bindParam(":foto", $foto);
        $statement->bindParam(":usuarios", $usuarios);
        $statement->bindParam(":propietarios", $propietarios);
        $statement->bindParam(":id_usuario", $id_usuario);
        $statement->bindParam(":likes", $likes);
        $result = $statement->execute();

        if ($result) {

          return json_encode([ "newList" => $result ]);

        }
        else {
          return false;
        }

      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }

    }

    // Función para borrar una lista
    function removeList($id) {

      try {

        $db = new DB();
        $db = $db->Connect();
        $query = "DELETE FROM listas WHERE id = :id";
        $statement = $db->prepare($query);
        $statement->bindParam(":id", $id);

        $result = $statement->execute();

        if ($result) {

          return json_encode([ "removedList" => $result ]);

        }
        else {
          return false;
        }

      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }

    }

    function ModifyList($actualId, $new_id, $nombre, $tipo, $foto, $usuarios, $propietarios, $id_usuario, $likes) {

      try {
        $db = new DB();
        $db = $db->Connect();
        $query = "UPDATE listas SET id = :new_id, nombre = :nombre, tipo = :tipo, foto = :foto, usuarios = :usuarios, propietarios = :propietarios, id_usuario = :id_usuario, likes = :likes WHERE id = :actualId";
        $statement = $db->prepare($query);
        $statement->bindParam(":actualId", $actualId);
        $statement->bindParam(":new_id", $new_id);
        $statement->bindParam(":nombre", $nombre);
        $statement->bindParam(":tipo", $tipo);
        $statement->bindParam(":foto", $foto);
        $statement->bindParam(":usuarios", $usuarios);
        $statement->bindParam(":propietarios", $propietarios);
        $statement->bindParam(":id_usuario", $id_usuario);
        $statement->bindParam(":likes", $likes);
        $result = $statement->execute();

        if ($result) {

          return json_encode([ "modifiedList" => $result ]);

        }
        else {
          return false;
        }
      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }
    }

  }

?>

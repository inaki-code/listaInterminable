<?php

  header("Access-Control-Allow-Origin: *");
  header("Access-Control-Allow-Headers: access");
  header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
  header("Allow: GET, POST, OPTIONS, PUT, DELETE");
  header("Content-Type: application/json; charset=UTF-8");
  header("Access-Control-Allow-Headers: X-API-KEY, Origin, Authorization,X-Requested-With, Content-Type, Accept,Access-Control-Request-Method");

  include_once 'banpeticiones.php';

  $methodHTTP = $_SERVER['REQUEST_METHOD'];

  switch ($methodHTTP) {
    case 'GET':

      $banpeticiones = new Banpeticiones();
      $banpeticiones->getBanPeticiones();
      break;

    case 'POST':

      #Recoge los datos que le pasan por el método POST
      $data = json_decode(file_get_contents('php://input'));

      $banpeticiones = new Banpeticiones();

      if ($data == NULL) {
        http_response_code(405);
      }
      else {

        if ( $banpeticiones->createBanPeticion($data->mensaje, $data->id_userban, $data->id_usuario) ) {
          http_response_code(200);
        }
        else {
          http_response_code(400);


        }

      }

      break;

    case 'DELETE':

      $banpeticion = new Banpeticiones();
      $id = $_GET['id'];
      $removeOne = $_GET['removeOne'];

      if ($id == NULL) {
        http_response_code(405);
      }
      else {

        if ($removeOne) {
          if ( $banpeticion->removeBanPeticion($id) ) {
            http_response_code(200);
          }
          else {
            http_response_code(400);
          }
        }
        else {
          if ( $banpeticion->removeBanPeticiones($id) ) {
            http_response_code(200);
          }
          else {
            http_response_code(400);
          }
        }

      }

      break;

    case 'PUT';

      break;

    default:
      # code...
      break;
  }




?>

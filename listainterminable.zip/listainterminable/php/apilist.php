<?php

  header("Access-Control-Allow-Origin: *");
  header("Access-Control-Allow-Headers: access");
  header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
  header("Allow: GET, POST, OPTIONS, PUT, DELETE");
  header("Content-Type: application/json; charset=UTF-8");
  header("Access-Control-Allow-Headers: X-API-KEY, Origin, Authorization,X-Requested-With, Content-Type, Accept,Access-Control-Request-Method");

  include_once 'list.php';

  $methodHTTP = $_SERVER['REQUEST_METHOD'];

  switch ($methodHTTP) {
    case 'GET':

      $list = new ListClass();
      $list->getlists();
      break;

    case 'POST':

      #Recoge los datos que le pasan por el método POST
      $data = json_decode(file_get_contents('php://input'));

      $list = new ListClass();

      if ($data == NULL) {
        http_response_code(405);
      }
      else {

        if ( $list->createList($data->nombre, $data->tipo, $data->foto, $data->usuarios, $data->propietarios, $data->id_usuario, $data->likes) ) {
          http_response_code(200);
        }
        else {
          http_response_code(400);
        }

      }

      break;

    case 'DELETE':

      $list = new ListClass();
      $id = $_GET['id'];

      if ($id == NULL) {
        http_response_code(405);
      }
      else {

        if ( $list->removeList($id) ) {
          http_response_code(200);
        }
        else {
          http_response_code(400);
        }

      }

      break;

    case 'PUT':

      $list = new ListClass();
      $data = json_decode(file_get_contents('php://input'));
      $actualId = $_GET['id'];

      if ( $data == NULL || $actualId == NULL ) {
        http_response_code(405);
      }
      else  {

        if ( $list->ModifyList($actualId, $actualId, $data->nombre, $data->tipo, $data->foto, $data->usuarios, $data->propietarios, $data->id_usuario, $data->likes) ) {
          http_response_code(200);
        }
        else {
          http_response_code(400);
        }

      }

      break;

    default:
      # code...
      break;
  }

?>

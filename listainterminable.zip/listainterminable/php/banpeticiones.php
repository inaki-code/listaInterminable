<?php

  header("Content-Type: application/json");

  include_once 'db.php';

  class Banpeticiones extends DB {

    // Función para sacar todas las listas
    function getBanPeticiones() {

      $banPeticiones = array();
      $banPeticiones['banPeticiones'] = array();

      $db = new DB();
      $db = $db->Connect();
      $query = $db->prepare('SELECT * FROM banpeticiones');
      $query->execute();

      while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
        array_push($banPeticiones['banPeticiones'], $row);
      }

      echo json_encode($banPeticiones);

    }

    // Función para crear una petición de baneo
    function createBanPeticion ($mensaje, $id_userban, $id_usuario) {
      try {
        $db = new DB();
        $db = $db->Connect();
        $query = "INSERT INTO banpeticiones (mensaje, id_userban, id_usuario) VALUES (:mensaje, :id_userban, :id_usuario)";
        $statement = $db->prepare($query);
        $statement->bindParam(":mensaje", $mensaje);
        $statement->bindParam(":id_userban", $id_userban);
        $statement->bindParam(":id_usuario", $id_usuario);
        $result = $statement->execute();

        if ($result) {

          return json_encode([ "newBanPeticion" => $result ]);

        }
        else {
          return false;
        }

      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }

    }

    // Función para borrar una petición de baneo
    function removeBanPeticion($id) {

      try {

        $db = new DB();
        $db = $db->Connect();
        $query = "DELETE FROM banpeticiones WHERE id = :id";
        $statement = $db->prepare($query);
        $statement->bindParam(":id", $id);

        $result = $statement->execute();

        if ($result) {

          return json_encode([ "removedbanPeticion" => $result ]);

        }
        else {
          return false;
        }

      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }

    }

    function removeBanPeticiones($id) {

      try {

        $db = new DB();
        $db = $db->Connect();
        $query = "DELETE FROM banpeticiones WHERE id_userban = :id OR id_usuario = :id";
        $statement = $db->prepare($query);
        $statement->bindParam(":id", $id);

        $result = $statement->execute();

        if ($result) {

          return json_encode([ "removedbanPeticiones" => $result ]);

        }
        else {
          return false;
        }

      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }

    }



  }


?>

<?php

  header("Access-Control-Allow-Origin: *");
  header("Access-Control-Allow-Headers: access");
  header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
  header("Allow: GET, POST, OPTIONS, PUT, DELETE");
  header("Content-Type: application/json; charset=UTF-8");
  header("Access-Control-Allow-Headers: X-API-KEY, Origin, Authorization,X-Requested-With, Content-Type, Accept,Access-Control-Request-Method");

  include_once 'agregar.php';

  $methodHTTP = $_SERVER['REQUEST_METHOD'];

  switch ($methodHTTP) {
    case 'GET':

      $agregar = new Agregar();
      $agregar->getAgregar();
      break;

    case 'POST':

      #Recoge los datos que le pasan por el método POST
      $data = json_decode(file_get_contents('php://input'));

      $agregar = new Agregar();

      if ($data == NULL) {
        http_response_code(405);
      }
      else {

        if ( $agregar->createAgregar($data->id_user, $data->id_userAgregado) ) {
          http_response_code(200);
        }
        else {

          http_response_code(400);

        }

      }

      break;

    case 'DELETE':
      $agregar = new Agregar();
      $id_user = $_GET['id_user'];
      $id_userAgregado = $_GET['id_userAgregado'];

      if ($id_user == NULL || $id_userAgregado == NULL) {
        http_response_code(405);
      }
      else {

        if ( $agregar->removeAgregar($id_user, $id_userAgregado) ) {
          http_response_code(200);
        }
        else {
          http_response_code(400);
        }

      }

      break;

    case 'PUT';

      $agreagar = new Agregar();
      $data = json_decode(file_get_contents('php://input'));
      $id_user = $_GET['id_user'];
      $id_userAgregado = $_GET['id_userAgregado'];

      if ($data == NULL || $id_user == NULL || $id_userAgregado == NULL) {
        http_response_code(405);
      }
      else {

        if ($agreagar->modifyAgregar($id_user, $id_userAgregado, $data->agregado)) {
          http_response_code(200);
        }
        else {
          http_response_code(400);
        }

      }

      break;

    default:
      # code...
      break;
  }




?>

<?php

  header("Content-Type: application/json");

  include_once 'db.php';

  class Incluir extends DB {

    // Función para sacar todos los agregar
    function getIncluir() {

      $incluir = array();
      $incluir['incluir'] = array();

      $db = new DB();
      $db = $db->Connect();
      $query = $db->prepare('SELECT * FROM incluir');
      $query->execute();

      while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
        array_push($incluir['incluir'], $row);
      }

      echo json_encode($incluir);

    }

    // Función para crear un vínculo de amistad entre los dos usuarios
    function createIncluir($id_list, $id_product, $aceptado) {
      try {

        $db = new DB();
        $db = $db->Connect();
        $query = "INSERT INTO incluir (id_lista, id_producto, aceptado) VALUES (:id_lista, :id_producto, :aceptado)";
        $statement = $db->prepare($query);
        $statement->bindParam(":id_lista", $id_list);
        $statement->bindParam(":id_producto", $id_product);
        $statement->bindParam(":aceptado", $aceptado);
        $result = $statement->execute();

        if ($result) {

          return json_encode([ "newIncluir" => $result ]);
          //return true;

        }
        else {
          return false;
        }

      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }

    }

    function removeIncluir($id_list, $id_product) {

      if ($id_list < 0) {
        $query = "DELETE FROM incluir WHERE id_producto = :id_product";
        $db = new DB();
        $db = $db->Connect();
        $statement = $db->prepare($query);
        $statement->bindParam(":id_product", $id_product);
      }
      else {
        $query = "DELETE FROM incluir WHERE id_lista = :id_list AND id_producto = :id_product";
        $db = new DB();
        $db = $db->Connect();
        $statement = $db->prepare($query);
        $statement->bindParam(":id_list", $id_list);
        $statement->bindParam(":id_product", $id_product);
      }

      try {
        $result = $statement->execute();

        if ($result) {

          return json_encode([ "removedList" => $result ]);

        }
        else {
          return false;
        }

      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }

    }

    function ModifyIncluir($actual_id_lista, $actual_id_product, $id_list, $id_product, $aceptado) {

      try {
        $db = new DB();
        $db = $db->Connect();
        $query = "UPDATE incluir SET id_lista = :id_list, id_producto = :id_product, aceptado = :aceptado  WHERE id_lista = :actual_id_lista AND id_producto = :actual_id_product";
        $statement = $db->prepare($query);
        $statement->bindParam(":actual_id_product", $actual_id_product);
        $statement->bindParam(":actual_id_lista", $actual_id_lista);
        $statement->bindParam(":id_product", $id_product);
        $statement->bindParam(":id_list", $id_list);
        $statement->bindParam(":aceptado", $aceptado);

        $result = $statement->execute();

        if ($result) {

          return json_encode([ "modifiedIncluir" => $result ]);

        }
        else {
          return false;
        }
      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }
    }

  }

?>

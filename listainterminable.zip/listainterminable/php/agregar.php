<?php

  header("Content-Type: application/json");

  include_once 'db.php';

  class Agregar extends DB {

    // Función para sacar todos los agregar
    function getAgregar() {

      $agregar = array();
      $agregar['agregar'] = array();

      $db = new DB();
      $db = $db->Connect();
      $query = $db->prepare('SELECT * FROM agregar');
      $query->execute();

      while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
        array_push($agregar['agregar'], $row);
      }

      echo json_encode($agregar);

    }

    // Función para crear un vínculo de amistad entre los dos usuarios
    function createAgregar($id_user, $id_userAgregado) {
      try {

        $db = new DB();
        $db = $db->Connect();
        $query = "INSERT INTO agregar (id_user, id_useragregado) VALUES (:id_user, :id_userAgregado)";
        $statement = $db->prepare($query);
        $statement->bindParam(":id_user", $id_user);
        $statement->bindParam(":id_userAgregado", $id_userAgregado);
        $result = $statement->execute();

        if ($result) {

          return json_encode([ "newAgregar" => $result ]);
          //return true;

        }
        else {
          return false;
        }

      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }
    }

    function removeAgregar($id_user, $id_userAgregado) {

      try {

        $db = new DB();
        $db = $db->Connect();

        if ($id_userAgregado < 0) {
          $query = "DELETE FROM agregar WHERE id_user = :id_user OR id_useragregado = :id_user";
        }
        else {
          $query = "DELETE FROM agregar WHERE id_user = :id_user AND id_useragregado = :id_useragregado";
        }

        $statement = $db->prepare($query);
        $statement->bindParam(":id_user", $id_user);
        $statement->bindParam(":id_useragregado", $id_userAgregado);
        $result = $statement->execute();

        if ($result) {

          return json_encode([ "removedList" => $result ]);

        }
        else {
          return false;
        }

      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }

    }


    function modifyAgregar($id_user, $id_userAgregado, $agregado) {

      try {
        $db = new DB();
        $db = $db->Connect();
        $query = "UPDATE agregar SET id_user = :id_user, id_useragregado = :id_useragregado, agregado = :agregado WHERE id_user = :id_user AND id_useragregado = :id_useragregado";
        $statement = $db->prepare($query);
        $statement->bindParam(":id_user", $id_user);
        $statement->bindParam(":id_useragregado", $id_userAgregado);
        $statement->bindParam(":agregado", $agregado);
        $result = $statement->execute();

        if ($result) {

          return json_encode([ "modifiedAgregar" => $result ]);

        }
        else {
          return false;
        }

      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }
    }
  }


?>

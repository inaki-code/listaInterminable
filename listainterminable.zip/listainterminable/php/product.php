<?php

  header("Content-Type: application/json");

  include_once 'db.php';

  class Product extends DB {

    // Función para sacar todos los productos
    function get() {

      $products = array();
      $products['products'] = array();

      $db = new DB();
      $db = $db->Connect();
      $query = $db->prepare('SELECT * FROM productos');
      $query->execute();

      while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
        array_push($products['products'], $row);
      }

      echo json_encode($products);

    }

    // Función para crear un producto
    function createProduct($nombre, $precio, $pesoNeto, $foto, $idUsuario) {
      try {

        $db = new DB();
        $db = $db->Connect();
        $query = "INSERT INTO productos (nombre, precio, peso_neto, foto, id_usuario) VALUES (:nombre, :precio, :pesoNeto, :foto, :idUsuario)";
        $statement = $db->prepare($query);
        $statement->bindParam(":nombre", $nombre);
        $statement->bindParam(":precio", $precio);
        $statement->bindParam(":pesoNeto", $pesoNeto);
        $statement->bindParam(":foto", $foto);
        $statement->bindParam(":idUsuario", $idUsuario);
        $result = $statement->execute();

        if ($result) {

          return json_encode([ "newProduct" => $result ]);
          //return true;

        }
        else {
          return false;
        }

      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }

    }

    function removeProduct($id) {

      try {

        $db = new DB();
        $db = $db->Connect();
        $query = "DELETE FROM productos WHERE id = :id";
        $statement = $db->prepare($query);
        $statement->bindParam(":id", $id);

        $result = $statement->execute();

        if ($result) {

          return json_encode([ "removedProduct" => $result ]);

        }
        else {
          return false;
        }

      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }

    }

    function modifyProduct($actualId, $new_id, $nombre, $precio, $peso_neto, $foto) {

      try {
        $db = new DB();
        $db = $db->Connect();
        $query = "UPDATE productos SET id = :new_id, nombre = :nombre, precio = :precio, peso_neto = :peso_neto, foto = :foto  WHERE id = :actualId";
        $statement = $db->prepare($query);
        $statement->bindParam(":actualId", $actualId);
        $statement->bindParam(":new_id", $new_id);
        $statement->bindParam(":nombre", $nombre);
        $statement->bindParam(":precio", $precio);
        $statement->bindParam(":foto", $foto);
        $statement->bindParam(":peso_neto", $peso_neto);
        $result = $statement->execute();

        if ($result) {

          return json_encode([ "modifiedProduct" => $result ]);

        }
        else {
          return false;
        }
      }
      catch (PDOException $e) {
        echo "¡Error!: " . $e->getMessage() . "<br/>";
      }

    }

  }

?>

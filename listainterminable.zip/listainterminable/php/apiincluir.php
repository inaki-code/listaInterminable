<?php

  header("Access-Control-Allow-Origin: *");
  header("Access-Control-Allow-Headers: access");
  header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
  header("Allow: GET, POST, OPTIONS, PUT, DELETE");
  header("Content-Type: application/json; charset=UTF-8");
  header("Access-Control-Allow-Headers: X-API-KEY, Origin, Authorization,X-Requested-With, Content-Type, Accept,Access-Control-Request-Method");

  include_once 'incluir.php';

  $methodHTTP = $_SERVER['REQUEST_METHOD'];

  switch ($methodHTTP) {
    case 'GET':

      $inclcuir = new Incluir();
      $inclcuir->getIncluir();
      break;

    case 'POST':

      #Recoge los datos que le pasan por el método POST
      $data = json_decode(file_get_contents('php://input'));

      $incluir = new Incluir();

      if ($data == NULL) {
        http_response_code(405);
      }
      else {

        if ( $incluir->createIncluir($data->id_list, $data->id_product, $data->aceptado) ) {
          http_response_code(200);
        }
        else {

          http_response_code(400);

        }

      }

      break;

    case 'DELETE':
      $incluir = new Incluir();
      $id_list = $_GET['id_list'];
      $id_product = $_GET['id_product'];

      if ($id_list == NULL || $id_product == NULL) {
        http_response_code(405);
      }
      else {

        if ( $incluir->removeIncluir($id_list, $id_product) ) {
          http_response_code(200);
        }
        else {
          http_response_code(400);
        }

      }

      break;

    case 'PUT';

      $incluir = new Incluir();
      $data = json_decode(file_get_contents('php://input'));
      $id_lista = $_GET['id_list'];
      $id_producto = $_GET['id_product'];

      if ( $data == NULL || $id_lista == NULL || $id_producto == NULL ) {
        http_response_code(405);
      }
      else  {

        if ( $incluir->ModifyIncluir($id_lista, $id_producto, $data->id_lista, $data->id_producto, $data->aceptado) ) {
          http_response_code(200);
        }
        else {
          http_response_code(400);
        }

      }

      break;

    default:
      # code...
      break;
  }




?>

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Base de datos: `listainterminabledb`;
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (

    `id` int(11) AUTO_INCREMENT PRIMARY KEY,
    `nombre` varchar(30) NOT NULL UNIQUE KEY,
    `email` varchar(75) NOT NULL UNIQUE KEY,
    `status` varchar(15) NOT NULL,
    `foto` longblob
    
);

--
-- Estructura de tabla para la tabla `listas`
--

CREATE TABLE `listas` (

  `id` int(11) AUTO_INCREMENT PRIMARY KEY,
  `nombre` varchar(50) NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `foto` longblob,
  `usuarios` varchar(5000),
  `propietarios` varchar(5000),
  `id_usuario` int(11) NOT NULL

);

ALTER TABLE listas ADD CONSTRAINT FK_UsuarioLista
FOREIGN KEY (id_usuario) REFERENCES usuarios(id);

--
-- Estructura de tabla para la tabla `banpeticiones`
--

CREATE TABLE `banpeticiones` (

  `id` int(11) AUTO_INCREMENT PRIMARY KEY,
  `mensaje` varchar(250) NOT NULL,
  `id_userban` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL

);

ALTER TABLE banpeticiones ADD CONSTRAINT FK_UsuarioBanpeticiones
FOREIGN KEY (id_usuario) REFERENCES usuarios(id);

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (

  `id` int(11) AUTO_INCREMENT PRIMARY KEY,
  `nombre` varchar(50),
  `precio` float,
  `peso_neto` float,
  `foto` longblob,
  `id_usuario` int(11) NOT NULL

);

ALTER TABLE productos ADD CONSTRAINT FK_UsuarioProducto
FOREIGN KEY (id_usuario) REFERENCES usuarios(id);

--
-- Estructura de tabla para la tabla `incluir`
--

CREATE TABLE `incluir` (

  PRIMARY KEY (id_lista, id_producto),
  `id_lista` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL

);

ALTER TABLE incluir ADD CONSTRAINT FK_ListaIncluir
FOREIGN KEY (id_lista) REFERENCES listas(id);

ALTER TABLE incluir ADD CONSTRAINT FK_ProductoIncluir
FOREIGN KEY (id_producto) REFERENCES productos(id);


--
-- Estructura de tabla para la tabla `agregar`
--

CREATE TABLE `agregar` (

  PRIMARY KEY (id_user, id_useragregado),
  `id_user` int(11) NOT NULL,
  `id_useragregado` int(11) NOT NULL

);

ALTER TABLE agregar ADD CONSTRAINT FK_UsuarioAgregar
FOREIGN KEY (id_user) REFERENCES usuarios(id);

ALTER TABLE agregar ADD CONSTRAINT FK_UsuarioAgregado
FOREIGN KEY (id_useragregado) REFERENCES usuarios(id);








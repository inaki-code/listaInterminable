import { Injectable } from '@angular/core';
import { ApiService } from '../api/api.service';
import { Product } from '../../interfaces/product';
import { CallComponentsService } from '../call-components/call-components.service';
import { BehaviorSubject, finalize } from 'rxjs';
import { Incluir } from '../../interfaces/incluir';
import { ProductService } from '../product/product.service';
import { SessionService } from '../session/session.service';
import { List } from '../../interfaces/list';

@Injectable({
  providedIn: 'root'
})
export class IncluirService {

  reload: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public listedProducts:BehaviorSubject<Product[]> = new BehaviorSubject(Array());
  public products:BehaviorSubject<Product[]> = new BehaviorSubject(Array());
  public idProducts: BehaviorSubject<number[]> = new BehaviorSubject(Array());
  public incluir: BehaviorSubject<Incluir[]> = new BehaviorSubject(Array());
  public visibleProducts: BehaviorSubject<Product[]> = new BehaviorSubject(Array());

  //id lista clickada
  public idList: BehaviorSubject<number> = new BehaviorSubject(-1);
  public list: BehaviorSubject<List> = new BehaviorSubject<List>({
    'id': -1,
    'nombre': '',
    'tipo': '',
    'foto': '',
    'usuarios': '',
    'propietarios': '',
    'id_usuario': -1,
    'likes': '',
    'ban': 0
  });

  constructor(private api: ApiService, private call: CallComponentsService, private product: ProductService, private session: SessionService) {

    this.call.List.subscribe(res => {
      this.idList.next(res.id);
      this.list.next(res);
      this.Incluir();
    });

    /*this.reload.subscribe(() => {

      setTimeout( ()=>{
        this.Incluir();
      }, 20 * 1000 );

    });*/

  }

  Incluir() {
    // Get productos del usuario
    this.product.visibleProducts.subscribe(res => {
      this.visibleProducts.next(res);
    });
    // Filtrar productos incluidos en la lista
    this.api.getIncluir().pipe(finalize( () => {

        let ids: number[] = [];
        let listed: Product[] = [];
        let noListed: Product[] = [];

        for (let i of this.incluir.value) {
          // Metemos en un array los ID's de los productos incluidos
          if (this.idList.value == i.id_lista) {
            ids.push(i.id_producto);
          }
        }
        // ID's Productos incluidos
        this.idProducts.next(ids);
        //console.log(ids);

        for (let p of this.product.products.value) {
          if ( this.idProducts.value.includes(p.id) ) {
            listed.push(p);
          }
          /*else {
            noListed.push(p);
          }*/
        }
        for (let p of this.visibleProducts.value) {
          if ( !this.idProducts.value.includes(p.id) ) {
            noListed.push(p);
          }
        }
        // Aplicar filtro
        this.listedProducts.next(listed);
        this.products.next(noListed);

        this.reload.next(true);

    })).subscribe(( res: any ) => {

      this.incluir.next(res.incluir);

    });
  }
}

import { Pipe, PipeTransform } from '@angular/core';
import { List } from '../../interfaces/list';

@Pipe({
  name: 'hopper'
})
export class HopperPipe implements PipeTransform {

  transform(array: List[], texto: string): List[] {

    if (!texto) {
      return array;
    }
    else {
      let filter = array.filter( item => item.nombre.toUpperCase().includes(texto.toUpperCase()) );
      return filter;
    }

  }

}

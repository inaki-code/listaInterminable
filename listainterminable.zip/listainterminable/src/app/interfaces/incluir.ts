export interface Incluir {

  id_lista: number;
  id_producto: number;
  aceptado: number;

}

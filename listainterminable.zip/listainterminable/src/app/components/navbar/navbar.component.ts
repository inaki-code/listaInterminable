import { Component, OnInit } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { ApiService } from '../../services/api/api.service';
import { CallComponentsService } from '../../services/call-components/call-components.service';
import { ListService } from '../../services/list/list.service';
import { SessionService } from '../../services/session/session.service';


@Component({
  selector: 'navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  token: any = sessionStorage.getItem('token');
  callLogin: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  callSingUp: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  userPressLists: boolean = true;
  userPressProducts: boolean = false;
  userPressList: boolean = false;
  userPressProfile: boolean = false;
  userPressBans: boolean = false;
  userPressListBans: boolean = false;
  userPressUsers: boolean = false;
  fotoUser: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  id: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  status: BehaviorSubject<string> = new BehaviorSubject<string>('');


  constructor(public session: SessionService, private call: CallComponentsService) {
  }

  ngOnInit(): void {

    this.session.isLogedIn.subscribe(res => {
      this.loggedIn.next(res);
      this.token = sessionStorage.getItem('token');
    });

    this.session.foto.subscribe(res => {
      this.fotoUser.next(res);
    });

    this.session.id.subscribe(res => {
      this.id.next(res);
    });

    this.call.goToProfile.subscribe(res => {

      if (res > 0) {
        this.goToProfile(res);
      }

    });

    this.session.status.subscribe(res => {
      this.status.next(res);
    });

  }

  sessionLogOut() {
    this.session.logout();

    this.userPressProducts = false;
    this.userPressLists = false;
    this.userPressList = false;
    this.userPressProfile = false;
    this.userPressBans = false;
    this.userPressUsers = false;
    this.userPressListBans = false;

    this.call.callLists.next(false);
    this.call.callProducts.next(false);
    this.call.callProfile.next(-1);
    this.call.callBanContainer.next(false);
    this.call.callUserContainer.next(false);
    this.call.callListBanContainer.next(false);
  }

  sessionLogIn() {
    // Log in
    this.userPressProducts = false;
    this.userPressLists = true;
    this.userPressList = false;
    this.userPressProfile = false;
    this.userPressBans = false;
    this.userPressUsers = false;
    this.userPressListBans = false;

    this.callLogin.next(true);
    this.call.callLists.next(true);
    this.call.callProducts.next(false);
    this.call.callProfile.next(-1);
    this.call.callBanContainer.next(false);
    this.call.callUserContainer.next(false);
    this.call.callListBanContainer.next(false);
  }

  singinModalClose() {
    this.callLogin.next(false);
  }

  listsOpen() {
    this.userPressProducts = false;
    this.userPressLists = true;
    this.userPressList = false;
    this.userPressProfile = false;
    this.userPressBans = false;
    this.userPressUsers = false;
    this.userPressListBans = false;

    this.call.callLists.next(true);
    this.call.callProducts.next(false);
    this.call.callBanContainer.next(false);
    this.call.callList.next(-1);
    this.call.callProfile.next(-1);
    this.call.List.next({
      id: -1,
      nombre: '',
      tipo: '',
      usuarios: '',
      propietarios: '',
      id_usuario: -1,
      likes: '',
      ban: 0
    });
    this.call.callUserContainer.next(false);
    this.call.callListBanContainer.next(false);
  }

  productsOpen() {
    this.userPressProducts = true;
    this.userPressLists = false;
    this.userPressList = false;
    this.userPressProfile = false;
    this.userPressBans = false;
    this.userPressUsers = false;
    this.userPressListBans = false;

    this.call.callProducts.next(true);
    this.call.callLists.next(false);
    this.call.callProfile.next(-1);
    this.call.callList.next(-1);
    this.call.callBanContainer.next(false);
    this.call.callUserContainer.next(false);
    this.call.callListBanContainer.next(false);
  }

  sessionSingUp() {
    this.callSingUp.next(true);
  }

  singupModalClose() {
    this.callSingUp.next(false);
  }

  goToProfile(id: number) {
    this.userPressProducts = false;
    this.userPressLists = false;
    this.userPressList = false;
    this.userPressProfile = true;
    this.userPressBans = false;
    this.userPressUsers = false;
    this.userPressListBans = false;

    this.call.callProducts.next(false);
    this.call.callLists.next(false);
    this.call.callList.next(-1);
    this.call.callProfile.next(id);
    this.call.callBanContainer.next(false);
    this.call.callUserContainer.next(false);
    this.call.callListBanContainer.next(false);
  }

  bansOpen() {
    this.userPressProducts = false;
    this.userPressLists = false;
    this.userPressList = false;
    this.userPressProfile = false;
    this.userPressBans = true;
    this.userPressUsers = false;
    this.userPressListBans = false;

    this.call.callProducts.next(false);
    this.call.callLists.next(false);
    this.call.callProfile.next(-1);
    this.call.callList.next(-1);
    this.call.callBanContainer.next(true);
    this.call.callUserContainer.next(false);
    this.call.callListBanContainer.next(false);
  }

  usersOpen() {
    this.userPressProducts = false;
    this.userPressLists = false;
    this.userPressList = false;
    this.userPressProfile = false;
    this.userPressBans = false;
    this.userPressUsers = true;
    this.userPressListBans = false;

    this.call.callProducts.next(false);
    this.call.callLists.next(false);
    this.call.callProfile.next(-1);
    this.call.callList.next(-1);
    this.call.callBanContainer.next(false);
    this.call.callUserContainer.next(true);
    this.call.callListBanContainer.next(false);
  }

  listBansOpen() {
    this.userPressProducts = false;
    this.userPressLists = false;
    this.userPressList = false;
    this.userPressProfile = false;
    this.userPressBans = false;
    this.userPressUsers = false;
    this.userPressListBans = true;

    this.call.callProducts.next(false);
    this.call.callLists.next(false);
    this.call.callProfile.next(-1);
    this.call.callList.next(-1);
    this.call.callBanContainer.next(false);
    this.call.callUserContainer.next(false);
    this.call.callListBanContainer.next(true);
  }









}

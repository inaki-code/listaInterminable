import { Component, OnInit, AfterViewChecked } from '@angular/core';
import { User } from '../../interfaces/user';
import { BehaviorSubject, finalize } from 'rxjs';
import { ApiService } from '../../services/api/api.service';
import { SessionService } from '../../services/session/session.service';
import { CallComponentsService } from '../../services/call-components/call-components.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ListService } from '../../services/list/list.service';
import { List } from '../../interfaces/list';
import { AgregarService } from '../../services/agregar/agregar.service';

// JQUERY
declare var $:any;

@Component({
  selector: 'profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit, AfterViewChecked {

  // id usuario logeado
  public id: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  // Usuario propietario del perfil
  public user: BehaviorSubject<User> = new BehaviorSubject<User>({
    'id': -1,
    'email': '',
    'token': '',
    'status': '',
    'name': '',
    'foto': '',
    'password': '',
    'loggedin': 0,
    'ban': 0
  });
  public seeProfile: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  public seeBanModal: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  // Formulario del perfil
  public profileForm: FormGroup;
  // status
  public status: BehaviorSubject<string> = new BehaviorSubject<string>('');
  public url: string = '';
  public lists: BehaviorSubject<List[]> = new BehaviorSubject<List[]>(new Array());

  constructor(private api: ApiService, private session: SessionService, private call: CallComponentsService, private fb: FormBuilder, private list: ListService, public agregar: AgregarService) {
    this.profileForm = this.fb.group({
      email: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(50), Validators.email]],
      password: ['', [Validators.minLength(8), Validators.maxLength(25)]],
      repeatPassword: ['', [Validators.minLength(8), Validators.maxLength(25)]],
      completeName: ['', [Validators.minLength(2), Validators.maxLength(25)]],
      image: [''],
      status: ['']
    });

  }

  ngOnInit(): void {

    this.session.id.subscribe(res => {
      this.id.next(res);
    });

    this.call.callProfile.subscribe(res => {
      this.seeProfile.next(res);
    });

    this.call.callBanModal.subscribe(res => {
      this.seeBanModal.next(res);
    });

    this.call.callUserProfile.subscribe(res => {
      this.user.next(res);

      // Infomación del perfil
      if (res.id > 0) {
        this.profileForm.controls['email'].setValue(res.email);
        this.profileForm.controls['completeName'].setValue(res.name);
        this.url = res.foto;

        if (this.status.value == 'admin') {
          this.profileForm.controls['status'].setValue('admin');
        }
        else {
          this.profileForm.controls['status'].setValue('user');
        }

      }
      console.log(res);

      // Listas que le gustan al usuario
      let lists: List[] = [];
      //console.log(this.user.value);

      for (let l of this.list.lists.value) {
        let stringLikes: string = l.likes.slice(1);
        stringLikes = stringLikes.slice(0, -1);

        let likes: string[] = stringLikes.split(',');

        console.log(likes);

        if ( likes.includes( this.call.callUserProfile.value.id.toString() ) ) {
          lists.push(l);
        }
      }

      this.lists.next(lists);
      //console.log(lists);
    });

    this.session.status.subscribe(res => {
      this.status.next(res);
    });

  }

  ngAfterViewChecked(): void {
    $('[data-toggle="tooltip"]').tooltip();
  }

  solicitudAmistad(userAgregado: number) {

    alert('has enviado tu petición de amistad');
    this.api.createAgregar(this.id.value, userAgregado).pipe(finalize( () => {

      // Ponemos la petición en las peticiones pendientes
      let peticionesHechas: number[] = this.agregar.peticionesHechas.value;
      peticionesHechas.push(userAgregado);
      this.agregar.peticionesHechas.next(peticionesHechas);

      // Incluir al usuario que hacemos la petición en usuarios no agregables
      let noAgregables: number[] = this.agregar.usersNoAgregables.value;
      noAgregables.push(userAgregado);
      this.agregar.usersNoAgregables.next(noAgregables);

    })).subscribe();

  }

  selectFile(event: any) {
    if (event.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event:any) => {

        this.user.value.foto = event.target.result;
        this.url = event.target.result
        console.log(this.user.value);

      }
    }
  }

  profileSubmit() {

    let user: User = {
      'id': this.user.value.id,
      'email': this.profileForm.controls['email'].value,
      'token': this.user.value.token,
      'status': this.profileForm.controls['status'].value,
      'name': this.profileForm.controls['completeName'].value,
      'foto': this.url,
      'password': this.user.value.password,
      'loggedin': this.user.value.loggedin,
      'ban': 0
    };

    this.session.foto.next(this.url);

    if (this.profileForm.controls['password'].value == '' && this.profileForm.controls['repeatPassword'].value == '') {

      console.log(user);

      this.api.modifyUser(this.user.value.id, user, 0).subscribe(res => {
        if (res != null) {
          console.log(res);
        }
      });

    }
    else {

      if (this.profileForm.controls['password'].value == this.profileForm.controls['repeatPassword'].value) {

        user.password = this.profileForm.controls['password'].value;

        this.api.modifyUser(this.user.value.id, user, 1).subscribe(res => {
          if (res != null) {
          console.log(res);
        }
        });

      }
      else {
        alert('Las contraseñas no coinciden');
      }

    }

  }

  goToList(list: List) {
    this.call.callLists.next(false);
    this.call.callProducts.next(false);
    this.call.callProfile.next(-1);

    this.call.List.next(list);
    this.call.callList.next(list.id);
  }

  openBanModal() {
    this.call.callBanModal.emit(true);
  }

  solicitudBan(idUser: number, idUserBan: number, mensaje: string) {

  }

}

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BehaviorSubject } from 'rxjs'
import { ApiService } from '../../../services/api/api.service';
import { CallComponentsService } from '../../../services/call-components/call-components.service';
import { List } from '../../../interfaces/list';
import { User } from '../../../interfaces/user';
import { AgregarService } from '../../../services/agregar/agregar.service';
import { ListService } from '../../../services/list/list.service';
import { SessionService } from '../../../services/session/session.service';

// JQUERY
declare var $:any;

@Component({
  selector: 'list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})

export class ListComponent implements OnInit {

  public users: BehaviorSubject<any> = new BehaviorSubject(Array());
  //
  public agregados: BehaviorSubject<any> = new BehaviorSubject(Array());
  //
  public propietarios: BehaviorSubject<any> = new BehaviorSubject(Array());
  // Formulario de registro
  public editListForm: FormGroup;
  // URL de la foto
  url: string = '';
  // lista
  list: BehaviorSubject<List> = new BehaviorSubject(
  {
    id: -1,
    nombre: '',
    tipo: '',
    usuarios: '',
    propietarios: '',
    id_usuario: -1,
    likes: '',
    ban: 0
  });
  // Ver lista usuarios
  ver_mas: boolean = false;
  public seeBanModal: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);


  constructor(private fb: FormBuilder, private call: CallComponentsService, private api: ApiService, private session: SessionService) {

    this.editListForm = this.fb.group({
      nombre: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(25)]],
      image: [''],
      tipo: [''],
    });
  }

  ngOnInit(): void {

    this.call.List.subscribe(res => {
      this.list.next(res);
    });

    this.call.callBanModal.subscribe(res => {
      this.seeBanModal.next(res);
    });

    let list: any = this.call.List.value;

    //console.log(this.call.List);
    this.editListForm.controls['nombre'].setValue(list.nombre);
    this.editListForm.controls['tipo'].setValue(list.tipo);

    $("#img").attr("src", list.foto);

    //console.log(this.lists.visibleLists.value);

  }

  editListSubmit(id: number) {
    let list: List = this.list.value;

    list.nombre = this.editListForm.controls['nombre'].value;
    list.tipo = this.editListForm.controls['tipo'].value;
    list.foto = $("#img").attr("src");

    this.list.next(list);

    this.api.modifyList(id, list).subscribe(res => {
      console.log(res);
    });
  }

  selectFile(event: any) {
    if (event.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event:any) => {
        this.url = event.target.result;
        $("#img").attr("src", this.url);
      }
    }
  }

  ver() {
    this.ver_mas = !this.ver_mas;
  }

  addUsers(users: BehaviorSubject<any>, userstipo: string) {

    switch (userstipo) {
      case 'users':
        this.users = users;
        //console.log(users);
        break;
      case 'propietarios':
        this.propietarios = users;
        //console.log(users);
        break;
      case 'agregados':
        this.agregados = users;
        //console.log(users);
        break;
    }

  }

  openBanModal() {
    this.call.callBanModal.emit(true);
  }



}

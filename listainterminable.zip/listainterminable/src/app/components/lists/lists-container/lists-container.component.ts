import { Component, OnInit } from '@angular/core';
import { BehaviorSubject, finalize } from 'rxjs';
import { User } from '../../../interfaces/user';
import { List } from '../../../interfaces/list';
import { ApiService } from '../../../services/api/api.service';
import { CallComponentsService } from '../../../services/call-components/call-components.service';
import { SessionService } from '../../../services/session/session.service';
import { ListService } from '../../../services/list/list.service';
import { IncluirService } from '../../../services/inlcluir/incluir.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { debounceTime } from 'rxjs/operators';

// JQUERY
declare var $:any;

@Component({
  selector: 'lists-container',
  templateUrl: './lists-container.component.html',
  styleUrls: ['./lists-container.component.css']
})
export class ListsContainerComponent implements OnInit {

  // Listas de la BDD
  public lists: List[] = [];
  // id usuario logeado
  public id: BehaviorSubject<number> = new BehaviorSubject<number>(-1);
  public status: BehaviorSubject<string> = new BehaviorSubject<string>('');
  // Listas visibles
  public visibleLists: BehaviorSubject<List[]> = new BehaviorSubject<List[]>(Array());

  public seeLists: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);
  public seeListsModal: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public seeIListModal: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public seeCListModal: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public seeAListModal: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public seeTListModal: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public seeList: BehaviorSubject<number> = new BehaviorSubject<number>(-1);

  // Formulario de búsqueda
  public searchForm: FormGroup;
  public listsFilter: BehaviorSubject<string> = new BehaviorSubject('');


  constructor(private api: ApiService, private call: CallComponentsService, private session: SessionService, private list: ListService, private incluir: IncluirService, private fb: FormBuilder) {
    this.searchForm = this.fb.group({
      search: []
    });
  }

  ngOnInit(): void {

    this.searchForm.controls['search'].valueChanges
    .pipe(
      debounceTime(500)
    )
    .subscribe(res => this.listsFilter.next(res));

    this.session.id.subscribe(res => {
      this.id.next(res);
    });

    this.session.status.subscribe(res => {
      this.status.next(res);

      switch (res) {
        case 'admin':
          this.list.lists.subscribe(res => {
            this.visibleLists.next(res);
          });
          break;
        case 'user':
          this.list.visibleLists.subscribe(res => {
            this.visibleLists.next(res);
            console.log(res);
          });
          break;
      }


      console.log(res);
    });

    // Estamos pendientes de las Listas
    this.call.callLists.subscribe(data => {
      this.seeLists.next(data);
    });
    // Estamos pendientes de la modal de las Listas
    this.call.callListsModal.subscribe(data => {
      this.seeListsModal.next(data);
    });
    // Estamos pendientes de IlistModal
    this.call.callIListModal.subscribe(data => {
      this.seeIListModal.next(data);
    });
    // Estamos pendientes de ClistModal
    this.call.callCListModal.subscribe(data => {
      this.seeCListModal.next(data);
    });
    // Estamos pendientes de AlistModal
    this.call.callAListModal.subscribe(data => {
      this.seeAListModal.next(data);
    });
    // Estamos pendientes de TlistModal
    this.call.callTListModal.subscribe(data => {
      this.seeTListModal.next(data);
    });
    // Estamos pendientes de La lista clickable
    this.call.callList.subscribe(data => {
      this.seeList.next(data);

      if (data > -1) {
        for (let l of this.lists) {
          if (l.id == data) {
            this.call.List.next(l);

            break;
          }
        }
      }

    });

  }

  borrarLista(list: List) {
    this.call.List.next(list);

    alert('se borrará la lista');

    if (this.incluir.idProducts.value.length > 0) {
      for (let i of this.incluir.idProducts.value) {
        // Eliminar productos incluidos de la lista
        this.api.removeIncluir(list.id, i).subscribe();
      }

      // Eliminar lista
      this.api.removeList(list.id).pipe(finalize(() => {
        // Borramos la lista de las listas visibles del usuario
        let listas: List[] = this.list.visibleLists.value;

        for (let i = 0; i < listas.length; i++) {
          if (listas[i].id == list.id) {
            listas.splice(i, 1);
            break;
          }
        }

        this.list.visibleLists.next(listas);

      })).subscribe();
    }
    else {
      // Eliminar lista
      this.api.removeList(list.id).pipe(finalize(() => {
        // Borramos la lista de las listas visibles del usuario
        let listas: List[] = this.list.visibleLists.value;

        for (let i = 0; i < listas.length; i++) {
          if (listas[i].id == list.id) {
            listas.splice(i, 1);
            break;
          }
        }

        this.list.visibleLists.next(listas);

      })).subscribe();
    }
  }

  callListsModal() {
    this.call.callListsModal.next(true);
  }

  getList(id: number) {

    this.call.callLists.next(false);
    this.call.callList.next(id);

    for (let l of this.visibleLists.value) {
      if (l.id == id) {
        this.call.List.next(l);
        break;
      }
    }

  }

  like(list: List, iduser: number, event: any) {

    event.stopPropagation();

    let users: string[] = list.likes.split(',');
    users[0] = users[0].replace('[','');
    users[users.length - 1] = users[users.length - 1].replace(']','');
    console.log(users);

    let listaFinal: List = list;
    let cadenaLikes: string = listaFinal.likes;
    let likesFinal: string = cadenaLikes.replace(']', '');
    let likes: string[] = likesFinal.split(',');

    if (list.likes == '[]') {
      likesFinal += iduser + ']';
    }
    else {
      likesFinal += ',' + iduser + ']';
    }

    likes[0] = likes[0].replace('[','');
    likes[likes.length - 1] = likes[likes.length - 1].replace(']','');

    console.log(likesFinal);
    console.log(likes);

    listaFinal.likes = likesFinal;

    if ( !users.includes(iduser.toString()) ) {
      this.api.modifyList(list.id, listaFinal).subscribe(res => {
        if (res != null) {
          console.log(res);
        }
      });
    }

  }

  quitarLike(list: List, iduser: number, event: any) {

    event.stopPropagation();

    let listaFinal: List = list;
    let likes: string = list.likes;
    let arrayLikes: string[] = likes.split(',');
    arrayLikes[0] = arrayLikes[0].replace('[','');
    arrayLikes[arrayLikes.length - 1] = arrayLikes[arrayLikes.length - 1].replace(']','');

    if ( arrayLikes.includes( iduser.toString() ) ) {

      for (let i = 0; i < arrayLikes.length; i++) {
        if ( arrayLikes[i] == iduser.toString() ) {
          arrayLikes.splice(i, 1);
          break;
        }
      }

    }

    listaFinal.likes = "[" + arrayLikes.toString() + "]";
    console.log(listaFinal.likes);

    this.api.modifyList(list.id, listaFinal).subscribe(res => {
      if (res != null) {
        console.log(res);
      }
    });

  }





}

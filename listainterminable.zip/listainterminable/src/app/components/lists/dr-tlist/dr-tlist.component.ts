import { Component, Input, OnInit, Output, AfterViewChecked } from '@angular/core';
import { FormGroup, FormBuilder} from '@angular/forms';
import { BehaviorSubject, debounceTime, finalize } from 'rxjs';
import { User } from '../../../interfaces/user';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { AgregarService } from '../../../services/agregar/agregar.service';
import { SessionService } from '../../../services/session/session.service';
import { CallComponentsService } from '../../../services/call-components/call-components.service';
import { List } from '../../../interfaces/list';
import { ApiService } from '../../../services/api/api.service';

// JQUERY
declare var $:any;

@Component({
  selector: 'dr-tlist',
  templateUrl: './dr-tlist.component.html',
  styleUrls: ['./dr-tlist.component.css']
})
export class DrTlistComponent implements OnInit, AfterViewChecked {

  @Input()
  public newList: boolean = true;
  // Formulario
  public searchUser: FormGroup;
  // Lista
  public list: BehaviorSubject<List> = new BehaviorSubject({
    id: -1,
    nombre: '',
    tipo: '',
    usuarios: '',
    propietarios: '',
    id_usuario: -1,
    likes: '',
    ban: 0
  });
  // propietarios de la lista
  @Output()
  public propietarios: BehaviorSubject<any> = new BehaviorSubject(Array());
  // usuarios sin privilegios de la lista
  @Output()
  public usuarios: BehaviorSubject<any> = new BehaviorSubject(Array());
  //
  @Output()
  public agregados: BehaviorSubject<any> = new BehaviorSubject(Array());
  //
  public idUsuarios: BehaviorSubject<number[]> = new BehaviorSubject(Array());
  public idPropietarios: BehaviorSubject<number[]> = new BehaviorSubject(Array());
  public idAgregados: BehaviorSubject<number[]> = new BehaviorSubject(Array());
  //
  public usersSearch: BehaviorSubject<string> = new BehaviorSubject('');
  //
  public propietariosSearch: BehaviorSubject<string> = new BehaviorSubject('');
  //
  public agregadosSearch: BehaviorSubject<string> = new BehaviorSubject('');

  public foto: any = '';

  public email: string = '';

  public id: BehaviorSubject<number> = new BehaviorSubject(-1);

  public usuarioPropietario: BehaviorSubject<User> = new BehaviorSubject({
    'id': -1,
    'email': '',
    'foto' : '',
    'token': '',
    'status': '',
    'name': '',
    'loggedin': 0,
    'ban': 0
  });

  public rol: BehaviorSubject<string> = new BehaviorSubject('');

  constructor(private fb: FormBuilder, private agregar: AgregarService, private session: SessionService, private call: CallComponentsService, private api: ApiService) {
    this.searchUser = this.fb.group({
      searchUser: [],
      searchPropietario: [],
      searchAgregado: []
    });
  }

  ngOnInit(): void {

    this.subscriptions();

    console.log(this.agregados.value);
    console.log(this.propietarios.value);
    console.log(this.usuarios.value);

    console.log(this.call.List.value);
    console.log(this.rol.value);

  }

  ngAfterViewChecked(): void {
    $('[data-toggle="tooltip"]').tooltip();
  }

  dropped_user($event: CdkDragDrop<BehaviorSubject<User[]>>) {

    if ($event.previousContainer === $event.container) {
      moveItemInArray(
        $event.container.data.value,
        $event.previousIndex,
        $event.currentIndex
      );
    }
    else {
      transferArrayItem(
        $event.previousContainer.data.value,
        $event.container.data.value,
        $event.previousIndex,
        $event.currentIndex
      );

      this.searchUser.reset();

      //let user: User = $event.container.data.value[$event.currentIndex];

      //console.log(user.email);

      console.log(this.agregados.value);
      console.log(this.propietarios.value);
      console.log(this.usuarios.value);

      if (!this.newList) {
        this.editListSubmit(this.list.value.id);
      }

    }

  }

  getUsers() {

    // Si vamos a crear una nueva lista solo llenamos la columna de amigos
    if (this.newList) {
      this.rol.next('propietario');

      let friends: User[] = new Array();

      for (let id of this.agregar.amigos.value) {

        for (let u of this.session.users.value) {

          if ( u.id == id ) {
            friends.push(u);
          }

        }

      }

      this.agregados.next(friends);
      console.log(friends);

    }
    // Si la lista ya está creada llenamos todas las columnas, propietarios, usuarios y amigos
    else {
      // Agregados
      this.call.idagregados.subscribe(res => {

        this.idAgregados.next(res);

        let agregados: User[] = [];

        for (let u of this.session.users.value) {

          if ( this.idAgregados.value.includes( parseInt(u.id.toString()) ) && parseInt(u.id.toString()) != this.call.List.value.id_usuario ) {

            agregados.push(u);
            //console.log(u);

          }
        }

        console.log(agregados);
        this.agregados.next(agregados);

      });

      // Usuarios de la lista
      this.call.idusuarios.subscribe(res => {

        this.idUsuarios.next(res);
        console.log(res);

        let users: User[] = [];

        for (let u of this.session.users.value) {

          if ( this.idUsuarios.value.includes( parseInt(u.id.toString()) ) ) {

            users.push(u);
            //console.log(u);

          }
        }

        console.log(users);
        this.usuarios.next(users);
      });

      // Propietarios
      this.call.idpropietarios.subscribe(res => {

        this.idPropietarios.next(res);

        console.log(res);

        let propietarios: User[] = [];

        for (let u of this.session.users.value) {

          if ( this.idPropietarios.value.includes( parseInt(u.id.toString()) ) ) {

            propietarios.push(u);
            //console.log(u);

          }
        }

        // Usuario dueño de la lista
        for (let u of this.session.users.value) {
          if (u.id == this.call.List.value.id_usuario) {
            this.usuarioPropietario.next(u);
            break;
          }
        }

        console.log(propietarios);
        this.propietarios.next(propietarios);
      });


    }
  }

  subscriptions() {
    this.searchUser.controls['searchUser'].valueChanges
    .pipe(
      debounceTime(500)
    )
    .subscribe(res => this.usersSearch.next(res));

    this.searchUser.controls['searchPropietario'].valueChanges
    .pipe(
      debounceTime(500)
    )
    .subscribe(res => this.propietariosSearch.next(res));

    this.searchUser.controls['searchAgregado'].valueChanges
    .pipe(
      debounceTime(500)
    )
    .subscribe(res => this.agregadosSearch.next(res));

    this.session.email.subscribe(res => {
      this.email = res;
    });

    this.session.foto.subscribe(res => {
      this.foto = res;
    });

    this.call.List.subscribe(res => {
      this.list.next(res);
    });

    this.session.id.subscribe(res => {
      this.id.next(res);
    });

    this.call.rol.subscribe(res => {
      this.rol.next(res);
    });

    this.getUsers();

  }

  editListSubmit(id: number) {
    let list: List = this.list.value;
    let p: number[] = new Array();
    let u: number[] = new Array();

    for (let x of this.propietarios.value) {
      p.push(x.id);
    }

    for (let x of this.usuarios.value) {
      u.push(x.id);
    }

    list.propietarios = '[' + p.toString() + ']';
    list.usuarios = '[' + u.toString() + ']';

    console.log(list);

    /*console.log(list.propietarios);
    console.log(list.usuarios);*/

    //this.list.next(list);

    this.api.modifyList(id, list).subscribe(res => {
      if (res != null) {
        console.log(res);
      }
    });




  }

}

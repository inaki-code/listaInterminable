import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DrTlistComponent } from './dr-tlist.component';

describe('DrTlistComponent', () => {
  let component: DrTlistComponent;
  let fixture: ComponentFixture<DrTlistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DrTlistComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DrTlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

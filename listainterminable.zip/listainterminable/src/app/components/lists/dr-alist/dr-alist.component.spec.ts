import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DrAlistComponent } from './dr-alist.component';

describe('DrAlistComponent', () => {
  let component: DrAlistComponent;
  let fixture: ComponentFixture<DrAlistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DrAlistComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DrAlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

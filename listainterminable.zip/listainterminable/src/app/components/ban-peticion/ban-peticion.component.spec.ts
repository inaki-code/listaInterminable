import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BanPeticionComponent } from './ban-peticion.component';

describe('BanPeticionComponent', () => {
  let component: BanPeticionComponent;
  let fixture: ComponentFixture<BanPeticionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BanPeticionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BanPeticionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
